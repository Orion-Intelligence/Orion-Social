const DEFAULT_SETTINGS = {
  backendUrl: "ws://127.0.0.1:8020/extensions/ws",
  authApiBaseUrl: "https://127.0.0.1:8443/api",
  authToken: "",
  sessionToken: "",
  refreshToken: "",
  autoConnect: true,
  closeTabsAfterScrape: true
};

const AUTH_EXPIRY_SKEW_SECONDS = 30;
const RESULT_ACK_TIMEOUT_MS = 15000;
const RESULT_ACK_RETRY_COUNT = 2;

const AUTH_API_BASE_URL_CANDIDATES = [
  DEFAULT_SETTINGS.authApiBaseUrl,
  "https://localhost:8443/api",
  "http://127.0.0.1:8080/api",
  "http://localhost:8080/api",
  "http://127.0.0.1:4200/api",
  "http://localhost:4200/api"
];

const AUTH_PROXY_BASE_URL_CANDIDATES = [
  "http://127.0.0.1:8020",
  "http://localhost:8020"
];

const SUPPORTED_PLATFORMS = ["reddit", "linkedin", "x", "twitter", "instagram", "facebook", "github", "youtube", "tiktok"];
const SCRAPER_FILES = {
  reddit: ["scrapers/common/dom.js", "scrapers/reddit.js", "content.js"],
  linkedin: ["scrapers/common/dom.js", "scrapers/linkedin.js", "content.js"],
  x: ["scrapers/common/dom.js", "scrapers/x.js", "content.js"],
  twitter: ["scrapers/common/dom.js", "scrapers/x.js", "content.js"],
  instagram: ["scrapers/common/dom.js", "scrapers/instagram.js", "content.js"],
  facebook: ["scrapers/common/dom.js", "scrapers/facebook.js", "content.js"],
  github: ["scrapers/common/dom.js", "scrapers/github.js", "content.js"],
  youtube: ["scrapers/common/dom.js", "scrapers/youtube.js", "content.js"],
  tiktok: ["scrapers/common/dom.js", "scrapers/tiktok.js", "content.js"]
};

let socket = null;
let reconnectTimer = null;
let heartbeatTimer = null;
let authExpiryTimer = null;
let intentionalDisconnect = false;
let activeJobId = null;
let activeJob = null;
const authExpiredJobIds = new Set();
const pendingResultAcks = new Map();
let statusSnapshot = {
  connected: false,
  state: "disconnected",
  extensionId: "",
  backendUrl: DEFAULT_SETTINGS.backendUrl,
  activeJobId: null,
  lastError: "",
  lastSeenAt: null
};

chrome.runtime.onInstalled.addListener(async () => {
  const existing = await storageGet(Object.keys(DEFAULT_SETTINGS));
  await storageSet({ ...DEFAULT_SETTINGS, ...compactSettings(existing) });
  await setStatus({ state: "installed" });
  connectIfEnabled();
});

chrome.runtime.onStartup.addListener(() => {
  connectIfEnabled();
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  handleRuntimeMessage(message).then(sendResponse).catch((error) => {
    sendResponse({ ok: false, error: error.message || String(error) });
  });
  return true;
});

connectIfEnabled();

async function handleRuntimeMessage(message) {
  if (!message || typeof message !== "object") {
    return { ok: false, error: "invalid_message" };
  }

  if (message.type === "orion:getStatus") {
    return { ok: true, status: await getStatus() };
  }

  if (message.type === "orion:updateSettings") {
    const nextSettings = sanitizeSettings(message.settings || {});
    await storageSet(nextSettings);
    await setStatus({ backendUrl: nextSettings.backendUrl || statusSnapshot.backendUrl, lastError: "" });
    reconnectNow();
    return { ok: true, status: await getStatus() };
  }

  if (message.type === "orion:login") {
    const settings = await getSettings();
    const username = typeof message.username === "string" ? message.username.trim() : "";
    const password = typeof message.password === "string" ? message.password : "";
    const authApiBaseUrl = typeof message.authApiBaseUrl === "string" ? normalizeApiBaseUrl(message.authApiBaseUrl) : DEFAULT_SETTINGS.authApiBaseUrl;
    if (!username || !password) {
      return { ok: false, error: "missing_credentials" };
    }

    let loginResult;
    try {
      loginResult = await loginWithOrion(username, password, authApiBaseUrl, settings.backendUrl);
    } catch (error) {
      const message = error.message || String(error);
      await setStatus({ authState: "login_failed", lastError: message });
      return { ok: false, error: message, status: await getStatus() };
    }

    if (loginResult.twofa_required) {
      await setStatus({ authState: "twofa_required", lastError: "twofa_required" });
      return { ok: false, error: "twofa_required", status: await getStatus() };
    }
    if (!loginResult.access_token) {
      await setStatus({ authState: "login_failed", lastError: "login_failed" });
      return { ok: false, error: "login_failed", status: await getStatus() };
    }

    await storageSet({
      sessionToken: loginResult.access_token,
      refreshToken: String(loginResult.refresh_token || ""),
      authApiBaseUrl: loginResult.authApiBaseUrl || authApiBaseUrl,
      autoConnect: true
    });
    await setStatus({ authState: "authenticated", lastError: "" });
    await reconnectNow(true);
    return { ok: true, status: await getStatus() };
  }

  if (message.type === "orion:clearAuthSession") {
    const authApiBaseUrl = typeof message.authApiBaseUrl === "string" ? normalizeApiBaseUrl(message.authApiBaseUrl) : "";
    await storageSet({
      sessionToken: "",
      refreshToken: "",
      ...(authApiBaseUrl ? { authApiBaseUrl } : {})
    });
    await setStatus({ authState: "unauthenticated", connected: false, extensionId: "" });
    clearAuthExpiryTimer();
    disconnect("auth_session_cleared");
    return { ok: true, status: await getStatus() };
  }

  if (message.type === "orion:connect") {
    await reconnectNow(true);
    return { ok: true, status: await getStatus() };
  }

  if (message.type === "orion:disconnect") {
    disconnect("manual_disconnect");
    return { ok: true, status: await getStatus() };
  }

  if (message.type === "orion:runJob") {
    runJob(message.job).catch((error) => {
      const failedJob = normalizeJob(message.job);
      sendJobResult(failedJob, { success: false, ...normalizeJobError(error, failedJob) });
    });
    return { ok: true };
  }

  return { ok: false, error: "unknown_message_type" };
}

async function connectIfEnabled() {
  const settings = await getSettings();
  if (settings.autoConnect) {
    connect(settings);
  } else {
    await setStatus({ state: "idle", backendUrl: settings.backendUrl });
  }
}

async function reconnectNow(force = false) {
  const settings = await getSettings();
  disconnect("reconnect");
  if (force || settings.autoConnect) {
    await storageSet({ autoConnect: true });
    await connect({ ...settings, autoConnect: true });
  } else {
    await setStatus({ state: "idle", backendUrl: settings.backendUrl });
  }
}

async function connect(settings) {
  clearReconnect();
  clearHeartbeat();

  if (socket && (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CONNECTING)) {
    return;
  }

  const preparedAuth = await prepareAuth(settings);
  if (!preparedAuth.token) {
    const authState = preparedAuth.authState || "missing";
    const lastError = authState === "expired"
      ? "Session expired. Log in again."
      : authState === "refresh_failed"
        ? statusSnapshot.lastError || "Authentication refresh failed. Log in again."
        : "Open Orion Intelligence while logged in to authenticate the extension.";
    await setStatus({ connected: false, state: "auth_required", backendUrl: settings.backendUrl || DEFAULT_SETTINGS.backendUrl, authState, lastError });
    return;
  }

  const backendUrl = settings.backendUrl || DEFAULT_SETTINGS.backendUrl;
  scheduleAuthExpiryLogout(preparedAuth.token);
  await setStatus({ connected: false, state: "connecting", backendUrl, lastError: "", authState: preparedAuth.authState });

  try {
    intentionalDisconnect = false;
    socket = new WebSocket(backendUrl);
  } catch (error) {
    scheduleReconnect(error.message || String(error));
    return;
  }

  socket.addEventListener("open", () => {
    setStatus({ connected: false, state: "registering", extensionId: "", backendUrl, lastError: "", lastSeenAt: new Date().toISOString() });
    sendSocketMessage({
      type: "extension_online",
      auth_token: preparedAuth.token,
      auth_type: preparedAuth.authType,
      capabilities: {
        platforms: SUPPORTED_PLATFORMS,
        commands: ["profile", "posts", "videos", "shorts", "images", "friends", "followers", "following"]
      }
    });
  });

  socket.addEventListener("message", (event) => {
    handleSocketMessage(event.data).catch((error) => {
      sendSocketMessage({ type: "extension_error", error: error.message || String(error) });
    });
  });

  socket.addEventListener("close", (event) => {
    rejectAllPendingResultAcks(new Error(formatSocketCloseError(event)));
    if (intentionalDisconnect) {
      intentionalDisconnect = false;
      return;
    }
    if (isAuthCloseEvent(event)) {
      logoutExpiredSession("auth_session_expired").catch((error) => {
        setStatus({ authState: "expired", lastError: error.message || String(error) });
      });
      return;
    }
    scheduleReconnect(formatSocketCloseError(event), event.code, event.reason || "");
  });

  socket.addEventListener("error", () => {
    scheduleReconnect(`socket_error: cannot reach Orion Social at ${backendUrl}`);
  });
}

function disconnect(reason) {
  clearReconnect();
  clearHeartbeat();
  rejectAllPendingResultAcks(new Error(reason || "disconnect"));
  intentionalDisconnect = true;
  if (socket) {
    try {
      socket.close(1000, reason || "disconnect");
    } catch (_error) {
      // Ignore close errors from already-closed sockets.
    }
  }
  socket = null;
  activeJobId = null;
  setStatus({ connected: false, state: "disconnected", extensionId: "", activeJobId: null });
}

async function logoutExpiredSession(reason = "auth_session_expired") {
  clearReconnect();
  clearHeartbeat();
  clearAuthExpiryTimer();
  try {
    await failActiveJobForAuthExpiry(reason);
  } catch (error) {
    await setStatus({ lastError: error.message || String(error) });
  }
  intentionalDisconnect = true;
  const settings = await getSettings();
  const updates = {
    sessionToken: "",
    refreshToken: ""
  };
  if (looksLikeJwt(settings.authToken)) {
    updates.authToken = "";
  }
  await storageSet(updates);
  if (socket) {
    try {
      socket.close(1000, reason);
    } catch (_error) {
      // Ignore close errors from already-closed sockets.
    }
  }
  socket = null;
  activeJobId = null;
  activeJob = null;
  await setStatus({
    connected: false,
    state: "auth_required",
    extensionId: "",
    activeJobId: null,
    authState: "expired",
    lastError: "Session expired. Log in again."
  });
}

function scheduleReconnect(error, closeCode = null, closeReason = "") {
  clearHeartbeat();
  rejectAllPendingResultAcks(new Error(error || "socket_disconnected"));
  if (socket) {
    try {
      socket.close();
    } catch (_error) {
      // Ignore close errors from already-closed sockets.
    }
  }
  socket = null;
  setStatus({
    connected: false,
    state: "disconnected",
    extensionId: "",
    lastError: error || "disconnected",
    lastCloseCode: closeCode,
    lastCloseReason: closeReason,
    activeJobId: activeJobId || null
  });
  clearReconnect();
  reconnectTimer = setTimeout(() => {
    reconnectTimer = null;
    connectIfEnabled();
  }, 5000);
}

function isAuthCloseEvent(event) {
  const reason = String(event?.reason || "").toLowerCase();
  return event?.code === 1008 && /invalid_orion_session|missing_extension_auth|invalid_extension_token|auth|token|session/.test(reason);
}

function formatSocketCloseError(event) {
  const code = event?.code || 0;
  const reason = String(event?.reason || "").trim();
  if (reason) {
    return `ws_closed_${code}: ${reason}`;
  }
  if (code === 1006) {
    return "ws_closed_1006: Orion Social websocket is unreachable";
  }
  return `ws_closed_${code || "unknown"}`;
}

async function handleSocketMessage(rawData) {
  const message = parseJson(rawData);
  if (!message || typeof message !== "object") {
    return;
  }

  if (message.type === "job" || message.type === "scrape_job") {
    await runJob(message.job || message);
  }

  if (message.type === "extension_registered") {
    await setStatus({
      connected: true,
      state: "online",
      extensionId: String(message.extension_id || ""),
      lastError: "",
      lastSeenAt: new Date().toISOString()
    });
    clearHeartbeat();
    heartbeatTimer = setInterval(() => {
      sendSocketMessage({ type: "heartbeat", active_job_id: activeJobId, at: new Date().toISOString() });
    }, 25000);
  }

  if (message.type === "ping") {
    sendSocketMessage({ type: "pong", at: new Date().toISOString() });
  }

  if (message.type === "job_result_ack") {
    resolveResultAck(message);
    if (message.accepted === false) {
      await setStatus({ lastError: String(message.error || "job_result_not_accepted") });
    }
  }
}

async function runJob(job) {
  const normalizedJob = normalizeJob(job);
  if (!normalizedJob.job_id) {
    throw new Error("job_id_required");
  }
  if (normalizedJob.platform === "facebook" && !isSafeHttpUrl(normalizedJob.url)) {
    throw new Error("missing_facebook_username_or_profile_url");
  }

  activeJobId = normalizedJob.job_id;
  activeJob = normalizedJob;
  await setStatus({ state: "running", activeJobId });
  sendProgress(normalizedJob, "job_received", 20);

  let tabId = null;
  try {
    sendProgress(normalizedJob, "opening_tab", 25);
    const tab = await createTab({ url: normalizedJob.url, active: false });
    tabId = tab.id;
    if (normalizedJob.platform === "linkedin") {
      await waitForLinkedInDocument(tabId, normalizedJob.url, 45000);
    } else {
      await waitForTabComplete(tabId, 45000);
    }

    sendProgress(normalizedJob, "waiting_for_dom", 35);
    const result = await executeScraper(tabId, normalizedJob);
    if (authExpiredJobIds.has(normalizedJob.job_id)) {
      throw createAuthExpiredError();
    }
    sendProgress(normalizedJob, scraperStep(normalizedJob), 85);
    sendProgress(normalizedJob, "complete", 100);
    await sendJobResult(normalizedJob, { success: true, data: result });
  } catch (error) {
    const normalizedError = normalizeJobError(error, normalizedJob);
    if (normalizedError.error_code === "AUTH_REQUIRED") {
      sendProgress(normalizedJob, "auth_required", 45);
    }
    await setStatus({ lastError: normalizedError.message || normalizedError.error });
    if (!authExpiredJobIds.has(normalizedJob.job_id)) {
      await sendJobResult(normalizedJob, { success: false, ...normalizedError });
    }
  } finally {
    if (tabId !== null) {
      try {
        await removeTab(tabId);
      } catch (_error) {
        // The user may have closed the tab manually.
      }
    }
    if (activeJob?.job_id === normalizedJob.job_id) {
      activeJob = null;
    }
    activeJobId = null;
    const expired = authExpiredJobIds.has(normalizedJob.job_id) || statusSnapshot.authState === "expired";
    authExpiredJobIds.delete(normalizedJob.job_id);
    await setStatus({ state: expired ? "auth_required" : socket?.readyState === WebSocket.OPEN ? "online" : "disconnected", activeJobId: null });
  }
}

async function failActiveJobForAuthExpiry(reason = "auth_session_expired") {
  if (!activeJob?.job_id || authExpiredJobIds.has(activeJob.job_id)) {
    return false;
  }
  authExpiredJobIds.add(activeJob.job_id);
  sendProgress(activeJob, "auth_expired", 90);
  await sendJobResult(activeJob, {
    success: false,
    error: "Extension session expired. Log in again and retry.",
    message: "Extension session expired while scraping. Log in again and retry.",
    error_code: "AUTH_EXPIRED",
    platform: activeJob.platform,
    details: { reason }
  });
  return true;
}

function createAuthExpiredError() {
  const error = new Error("Extension session expired while scraping. Log in again and retry.");
  error.code = "AUTH_EXPIRED";
  error.error_code = "AUTH_EXPIRED";
  return error;
}

async function executeScraper(tabId, job) {
  const files = SCRAPER_FILES[job.platform];
  if (!files) {
    throw new Error(`unsupported_platform:${job.platform}`);
  }

  const world = job.platform === "youtube" ? "MAIN" : "ISOLATED";
  if (job.platform === "linkedin") {
    return executeLinkedInScraper(tabId, job, files, world);
  }
  if (job.platform === "facebook") {
    return executeFacebookScraper(tabId, job, files, world);
  }
  if (job.platform === "tiktok") {
    return executeTikTokScraper(tabId, job, files, world);
  }
  return executeScraperPass(tabId, job, files, world);
}

async function executeLinkedInScraper(tabId, job, files, world) {
  const command = String(job.social_data_type || job.command || "profile").toLowerCase();
  const profileResult = await executeScraperPass(tabId, {
    ...job,
    linkedin_mode: "profile"
  }, files, world);

  if (command === "followers" || command === "following") {
    await appendLinkedInConnections(tabId, job, files, world, profileResult, command);
    return cleanLinkedInResult(profileResult);
  }

  const activityUrl = profileResult.activity_url || linkedinActivityUrl(profileResult.url || job.url);
  if (!activityUrl) {
    return cleanLinkedInResult(profileResult);
  }

  await navigateLinkedInTab(tabId, activityUrl);
  const queueResult = await executeScraperPass(tabId, {
    ...job,
    url: activityUrl,
    linkedin_mode: "queue",
    skip_details: true
  }, files, world);

  const result = {
    ...profileResult,
    posts: Array.isArray(queueResult.posts) ? queueResult.posts : [],
    images: Array.isArray(queueResult.images) ? queueResult.images : []
  };

  if (command !== "images") {
    for (const post of result.posts) {
      if (!isSafeHttpUrl(post?.url || post?.post_url)) continue;
      try {
        const detailUrl = post.url || post.post_url;
        await navigateLinkedInTab(tabId, detailUrl);
        const detailResult = await executeScraperPass(tabId, {
          ...job,
          url: detailUrl,
          linkedin_mode: "detail",
          skip_settle: true,
          detail_post: post,
          cursor: { ...(job.cursor || {}), hash_id: post.id || post.hash_id || "" },
          limits: { ...(job.limits || {}), max_posts: 1 }
        }, files, world, true);
        const enriched = detailResult?.posts?.[0];
        if (enriched) mergeLinkedInPost(post, enriched);
      } catch (error) {
        if (error?.error_code === "AUTH_REQUIRED" || error?.code === "AUTH_REQUIRED") throw error;
        // Keep the activity-card data if an individual post is unavailable.
      }
    }
  }

  result.images = linkedinImages(result.posts, job);
  if (command === "profile" || command === "profile_info") {
    for (const type of ["followers", "following"]) {
      await appendLinkedInConnections(tabId, job, files, world, result, type);
    }
  }
  return cleanLinkedInResult(result);
}

async function appendLinkedInConnections(tabId, job, files, world, result, type) {
  const url = result?.connection_urls?.[type];
  result[type] = [];
  if (!isSafeHttpUrl(url)) return;

  try {
    await navigateLinkedInTab(tabId, url);
    const connectionResult = await executeScraperPass(tabId, {
      ...job,
      command: type,
      social_data_type: type,
      connection_type: type,
      linkedin_mode: "connection",
      url
    }, files, world);
    result[type] = Array.isArray(connectionResult?.[type]) ? connectionResult[type] : [];
  } catch (error) {
    if (error?.error_code === "AUTH_REQUIRED" || error?.code === "AUTH_REQUIRED") throw error;
    result[type] = [];
  }
}

function linkedinActivityUrl(value) {
  try {
    const url = new URL(String(value || ""));
    const path = url.pathname.match(/^\/(in|company|showcase)\/[^/?#]+/)?.[0];
    if (!path) return "";
    return url.origin + path + (path.startsWith("/in/") ? "/recent-activity/all/" : "/posts/");
  } catch (_error) {
    return "";
  }
}

function mergeLinkedInPost(target, source) {
  const preservedMedia = {
    media_type: target.media_type || "",
    media_url: target.media_url || "",
    image_url: target.image_url || "",
    thumbnail: target.thumbnail || ""
  };
  Object.assign(target, source);
  for (const [key, value] of Object.entries(preservedMedia)) {
    if (!target[key] && value) target[key] = value;
  }
}

function linkedinImages(posts, job) {
  const limit = Math.min(Math.max(Number(job?.limits?.max_images) || 25, 0), 100);
  return (Array.isArray(posts) ? posts : []).filter((post) => isSafeHttpUrl(post?.image_url)).map((post) => ({
    image_url: post.image_url,
    thumbnail: post.thumbnail || post.image_url,
    source_url: post.url || post.post_url || "",
    title: post.title || "LinkedIn post",
    source: "linkedin"
  })).slice(0, limit);
}

function cleanLinkedInResult(result) {
  delete result.activity_url;
  delete result.connection_urls;
  return result;
}

async function navigateLinkedInTab(tabId, url) {
  const current = await getTab(tabId);
  const currentDocument = await linkedInDocumentState(tabId);
  await updateTab(tabId, { url });
  await waitForLinkedInDocument(tabId, url, 45000, current?.url || "", currentDocument?.token || "");
}

async function waitForLinkedInDocument(tabId, expectedUrl, timeoutMs, previousUrl = "", previousToken = "") {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    const tab = await getTab(tabId);
    const documentState = await linkedInDocumentState(tabId);
    const documentChanged = Boolean(
      previousToken
      && documentState?.token
      && documentState.token !== previousToken
    );
    const routeReady = linkedinRouteReady(
      tab?.url,
      expectedUrl,
      previousUrl,
      Date.now() - started,
      documentChanged,
      Boolean(previousToken)
    );
    if (routeReady && (tab?.status === "complete" || documentState?.ready)) {
      return;
    }
    await waitMilliseconds(300);
  }
  throw new Error("tab_load_timeout");
}

function linkedinRouteReady(currentValue, expectedValue, previousValue, elapsedMs, documentChanged, hadPreviousToken) {
  try {
    const current = new URL(String(currentValue || ""));
    const expected = new URL(String(expectedValue || ""));
    if (!isLinkedInHost(current.hostname) || !isLinkedInHost(expected.hostname)) return false;
    if (hadPreviousToken && !documentChanged) return false;

    const currentPath = current.pathname.replace(/\/+$/, "").toLowerCase();
    const expectedPath = expected.pathname.replace(/\/+$/, "").toLowerCase();
    if (currentPath === expectedPath) return true;
    if (/\/(?:uas\/login|login|authwall|checkpoint)\b/.test(currentPath)) return true;
    if (documentChanged) return true;
    if (previousValue && normalizeNavigationUrl(current.href) !== normalizeNavigationUrl(previousValue)) return true;
    return !hadPreviousToken && elapsedMs >= 2500;
  } catch (_error) {
    return false;
  }
}

function isLinkedInHost(hostname) {
  const value = String(hostname || "").toLowerCase();
  return value === "linkedin.com" || value.endsWith(".linkedin.com");
}

function normalizeNavigationUrl(value) {
  try {
    const url = new URL(String(value || ""));
    return `${url.hostname.toLowerCase()}${url.pathname.replace(/\/+$/, "").toLowerCase()}${url.search}`;
  } catch (_error) {
    return "";
  }
}

async function linkedInDocumentState(tabId) {
  try {
    const execution = await executeFunction(tabId, () => ({
      readyState: document.readyState,
      hasBody: Boolean(document.body),
      hasContent: Boolean(document.querySelector("main, h1, [role='main'], form")),
      token: String(performance.timeOrigin || "")
    }), [], "ISOLATED");
    const state = execution?.result;
    return {
      ready: Boolean(
        state?.hasBody
        && state?.hasContent
        && (state.readyState === "interactive" || state.readyState === "complete")
      ),
      token: String(state?.token || "")
    };
  } catch (_error) {
    return { ready: false, token: "" };
  }
}

function waitMilliseconds(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

async function executeFacebookScraper(tabId, job, files, world) {
  const command = String(job.social_data_type || job.command || "profile").toLowerCase();
  if (command === "friends" || command === "followers" || command === "following") {
    return executeFacebookConnectionPass(tabId, job, files, world, command);
  }

  const profileUrl = facebookProfileUrl(job);
  if (!isSafeHttpUrl(profileUrl)) {
    throw new Error("missing_facebook_username_or_profile_url");
  }
  const postsUrl = facebookPostsUrl(job);
  if (isSafeHttpUrl(postsUrl) && command !== "friends" && command !== "followers" && command !== "following") {
    await updateTab(tabId, { url: postsUrl });
    await waitForTabComplete(tabId, 45000);
  }

  // Single pass: the in-page scraper collects posts AND comments inline on the feed page.
  // No per-post tab navigation needed — comments are collected by clicking on each card.
  const result = await executeScraperPass(tabId, {
    ...job,
    url: postsUrl || profileUrl,
    profile_url: profileUrl,
    skip_connections: true,
    skip_details: false
  }, files, world);

  if (!Array.isArray(result.images) || result.images.length === 0) {
    result.images = facebookImages(Array.isArray(result.posts) ? result.posts : [], job);
  }
  if (!Array.isArray(result.shorts) || result.shorts.length === 0) {
    result.shorts = Array.isArray(result.reels) ? result.reels : [];
  }
  const dedupeItems = (items, keyFn) => {
    const seen = new Set();
    return (Array.isArray(items) ? items : []).filter((item) => {
      const k = keyFn(item);
      if (!k || seen.has(k)) return false;
      seen.add(k);
      return true;
    });
  };
  result.posts = dedupeItems(result.posts, (p) => p.id || p.url || p.text);
  result.shorts = dedupeItems(result.shorts, (s) => s.id || s.url);
  result.videos = dedupeItems(result.videos, (v) => v.id || v.url);
  result.images = dedupeItems(result.images, (i) => i.image_url || i.url || i.source_url);

  if (!["profile", "profile_info"].includes(command)) {
    return result;
  }

  result.friends = [];
  try {
    const friendsResult = await executeFacebookConnectionPass(tabId, {
      ...job,
      profile_url: profileUrl || job.url
    }, files, world, "friends");
    result.friends = Array.isArray(friendsResult?.friends) ? friendsResult.friends : [];
  } catch (_error) {
    result.friends = [];
  }
  if (result.friends.length) {
    result.followers = Array.isArray(result.followers) ? result.followers : [];
    result.following = Array.isArray(result.following) ? result.following : [];
  }

  for (const type of ["followers", "following"]) {
    try {
      const connectionResult = await executeFacebookConnectionPass(tabId, {
        ...job,
        profile_url: profileUrl || job.url
      }, files, world, type);
      result[type] = Array.isArray(connectionResult?.[type]) ? connectionResult[type] : [];
    } catch (_error) {
      result[type] = [];
    }
  }
  return result;
}

function mergeFacebookPost(target, source) {
  const preserved = {
    title: target.title || "",
    text: target.text || "",
    caption: target.caption || "",
    media_type: target.media_type || "",
    media_url: target.media_url || "",
    image_url: target.image_url || "",
    thumbnail: target.thumbnail || ""
  };
  Object.assign(target, source);
  for (const [key, value] of Object.entries(preserved)) {
    if (!target[key] && value) target[key] = value;
  }
}

function facebookImages(posts, job) {
  const limit = Math.min(Math.max(Number(job?.limits?.max_images) || 25, 0), 100);
  const images = [];
  const seen = new Set();
  for (const post of Array.isArray(posts) ? posts : []) {
    const values = Array.isArray(post?.images) && post.images.length
      ? post.images
      : [post?.image_url].filter(Boolean);
    for (const imageUrl of values) {
      if (!isSafeHttpUrl(imageUrl)) continue;
      let key = imageUrl;
      try {
        const parsed = new URL(imageUrl);
        key = `${parsed.hostname.toLowerCase()}${parsed.pathname}`;
      } catch (_error) {
        // Keep the full URL as its identity.
      }
      if (seen.has(key)) continue;
      seen.add(key);
      images.push({
        image_url: imageUrl,
        source_url: post.url || post.post_url || "",
        title: post.title || "Facebook post",
        source: "facebook"
      });
      if (images.length >= limit) return images;
    }
  }
  return images;
}

async function executeFacebookConnectionPass(tabId, job, files, world, type) {
  const url = facebookConnectionUrl(job, type);
  await updateTab(tabId, { url });
  await waitForTabComplete(tabId, 45000);
  return executeScraperPass(tabId, {
    ...job,
    command: type,
    social_data_type: type,
    connection_only: type,
    skip_connections: false,
    url
  }, files, world);
}

function facebookConnectionUrl(job, type) {
  try {
    const profileUrl = new URL(facebookProfileUrl(job));
    if (/\/profile\.php$/i.test(profileUrl.pathname)) {
      profileUrl.searchParams.set("sk", type);
      return profileUrl.toString();
    }
    const parts = profileUrl.pathname.split("/").filter(Boolean);
    if (parts[0]) return `https://www.facebook.com/${encodeURIComponent(decodeURIComponent(parts[0]))}/${type}`;
  } catch (_error) {
    // Fall back to the username route.
  }
  const username = encodeURIComponent(facebookUsernameSlug(facebookJobUsername(job)));
  if (!username) return "";
  return `https://www.facebook.com/${username}/${type}`;
}

function facebookProfileUrl(job) {
  const username = facebookJobUsername(job);
  if (username) {
    try {
      const direct = new URL(username);
      if (direct.hostname.includes("facebook.com")) {
        return normalizeFacebookProfileRoute(direct);
      }
    } catch (_error) {
      // Username is normally a slug, not a URL.
    }
    return `https://www.facebook.com/${encodeURIComponent(facebookUsernameSlug(username))}`;
  }

  try {
    const url = new URL(String(job.profile_url || job.url || ""));
    if (url.hostname.includes("facebook.com") && isFacebookProfileRoute(url)) {
      return normalizeFacebookProfileRoute(url);
    }
  } catch (_error) {
    // Fall back to the username route.
  }
  return "";
}

function facebookJobUsername(job) {
  return String(
    job?.username
    || job?.requested_username
    || job?.requestedUsername
    || job?.profile_username
    || job?.profileUsername
    || job?.handle
    || ""
  ).trim().replace(/^@+/, "");
}

function facebookUsernameSlug(value) {
  return String(value || "")
    .trim()
    .replace(/^@+/, "")
    .replace(/^https?:\/\/(?:www\.)?facebook\.com\//i, "")
    .split(/[/?#]/)[0];
}

function facebookPostsUrl(job) {
  try {
    const url = new URL(facebookProfileUrl(job));
    if (/\/profile\.php$/i.test(url.pathname)) {
      url.searchParams.set("sk", "posts");
      return url.toString();
    }
    // Facebook frequently redirects /{page}/posts to home for some sessions/pages.
    // Open the canonical profile/page URL and let the scraper read the visible timeline.
    return url.toString();
  } catch (_error) {
    return "";
  }
}

function isFacebookProfileRoute(url) {
  if (!url || !url.hostname?.includes("facebook.com")) return false;
  if (/\/profile\.php$/i.test(url.pathname) && url.searchParams.get("id")) return true;
  const parts = url.pathname.split("/").filter(Boolean);
  if (parts.length !== 1) return false;
  const blocked = new Set([
    "", "home", "home.php", "watch", "reel", "reels", "story.php", "photo.php",
    "photos", "videos", "posts", "groups", "pages", "marketplace", "messages",
    "notifications", "friends", "followers", "following", "login", "search"
  ]);
  return !blocked.has(parts[0].toLowerCase());
}

function normalizeFacebookProfileRoute(url) {
  const normalized = new URL(url.toString());
  normalized.protocol = "https:";
  normalized.hostname = "www.facebook.com";
  normalized.hash = "";
  if (/\/profile\.php$/i.test(normalized.pathname) && normalized.searchParams.get("id")) {
    const id = normalized.searchParams.get("id");
    normalized.search = "";
    normalized.searchParams.set("id", id);
    return normalized.toString();
  }
  const slug = normalized.pathname.split("/").filter(Boolean)[0] || "";
  normalized.pathname = `/${encodeURIComponent(decodeURIComponent(slug))}`;
  normalized.search = "";
  return normalized.toString().replace(/\/$/, "");
}

async function executeTikTokScraper(tabId, job, files, world) {
  const queueJob = { ...job, skip_details: true };
  let result;
  try {
    result = await executeScraperPass(tabId, queueJob, files, world);
  } catch (error) {
    if (error?.message !== "empty_scraper_result") throw error;
    await updateTab(tabId, { url: job.url });
    await waitForTabComplete(tabId, 45000);
    result = await executeScraperPass(tabId, queueJob, files, world);
  }
  const shorts = Array.isArray(result.shorts) ? result.shorts : [];
  if (job.command === "images" || job.skip_details || shorts.length === 0) {
    return result;
  }

  for (const short of shorts) {
    if (!short?.url) continue;
    try {
      await updateTab(tabId, { url: short.url });
      await waitForTabComplete(tabId, 45000);
      const detail = await executeScraperPass(tabId, {
        ...job,
        detail_only: true,
        skip_details: true,
        cursor: { ...(job.cursor || {}), hash_id: short.id || short.hash_id || "" },
        limits: { ...(job.limits || {}), max_shorts: 1 }
      }, files, world, true);
      const enriched = detail?.shorts?.[0];
      if (enriched) {
        const thumbnail = short.media_url || short.image_url || short.thumbnail || "";
        Object.assign(short, enriched);
        if (thumbnail) {
          if (!short.media_url) short.media_url = thumbnail;
          if (!short.image_url) short.image_url = thumbnail;
          if (!short.thumbnail) short.thumbnail = thumbnail;
        }
      }
    } catch (error) {
      if (error?.error_code === "AUTH_REQUIRED" || error?.code === "AUTH_REQUIRED") throw error;
      // Keep the profile-card data when a detail page cannot be read.
    }
  }
  return result;
}

async function executeScraperPass(tabId, job, files, world, allowEmpty = false) {
  await executeFiles(tabId, files, world);
  const execution = await executeFunction(tabId, (scrapeJob) => window.__orionRunScraper(scrapeJob), [job], world);

  if (execution?.result === undefined || execution.result === null) {
    if (allowEmpty) return null;
    throw new Error("empty_scraper_result");
  }
  if (execution.result.success === false) {
    const scraperError = new Error(execution.result.message || execution.result.error || "scraper_failed");
    Object.assign(scraperError, normalizeJobError(execution.result, job));
    throw scraperError;
  }
  return execution.result.data || execution.result;
}

async function executeFiles(tabId, files, world = "ISOLATED") {
  if (chrome.scripting?.executeScript) {
    await executeScriptingScript({ target: { tabId }, files, world });
    return;
  }
  for (const file of files) {
    await new Promise((resolve, reject) => {
      chrome.tabs.executeScript(tabId, { file }, () => {
        const error = chrome.runtime.lastError;
        if (error) {
          reject(new Error(error.message));
          return;
        }
        resolve();
      });
    });
  }
}

async function executeFunction(tabId, func, args, world = "ISOLATED") {
  if (chrome.scripting?.executeScript) {
    const [execution] = await executeScriptingScript({ target: { tabId }, func, args, world });
    if (execution && Object.prototype.hasOwnProperty.call(execution, "result")) {
      return execution;
    }
    if (!chrome.tabs?.executeScript) {
      return execution;
    }
  }
  return executeTabsFunction(tabId, func, args);
}

function executeTabsFunction(tabId, func, args) {
  return new Promise((resolve, reject) => {
    const requestId = `orion-exec-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    const timeout = setTimeout(() => {
      cleanup();
      reject(new Error("script_result_timeout"));
    }, 60000);

    const cleanup = () => {
      clearTimeout(timeout);
      chrome.runtime.onMessage.removeListener(listener);
    };

    const listener = (message, sender) => {
      if (
        message?.type !== "orion:executeFunctionResult"
        || message.requestId !== requestId
        || sender?.tab?.id !== tabId
      ) {
        return;
      }
      cleanup();
      if (message.success === false) {
        const error = new Error(message.message || message.error || "script_execution_failed");
        if (message.error_code) {
          error.error_code = message.error_code;
          error.code = message.error_code;
        }
        reject(error);
        return;
      }
      resolve({ result: message.result });
    };

    chrome.runtime.onMessage.addListener(listener);
    const code = `
      (async function () {
        try {
          const result = await (${func.toString()})(${args.map((value) => JSON.stringify(value)).join(",")});
          chrome.runtime.sendMessage({ type: "orion:executeFunctionResult", requestId: ${JSON.stringify(requestId)}, success: true, result });
        } catch (error) {
          chrome.runtime.sendMessage({
            type: "orion:executeFunctionResult",
            requestId: ${JSON.stringify(requestId)},
            success: false,
            error: error && (error.message || error.error) || String(error || "script_execution_failed"),
            message: error && (error.message || error.error) || String(error || "script_execution_failed"),
            error_code: error && (error.error_code || error.code) || null
          });
        }
      })();
    `;
    chrome.tabs.executeScript(tabId, { code }, (values) => {
      const error = chrome.runtime.lastError;
      if (error) {
        cleanup();
        reject(new Error(error.message));
        return;
      }
    });
  });
}

function executeScriptingScript(details) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const finish = (error, value) => {
      if (settled) {
        return;
      }
      settled = true;
      if (error) {
        reject(error);
        return;
      }
      resolve(Array.isArray(value) ? value : []);
    };

    try {
      const maybePromise = chrome.scripting.executeScript(details, (results) => {
        const error = chrome.runtime.lastError;
        finish(error ? new Error(error.message || String(error)) : null, results);
      });
      if (maybePromise && typeof maybePromise.then === "function") {
        maybePromise.then((results) => finish(null, results)).catch((error) => finish(error));
      }
    } catch (error) {
      finish(error);
    }
  });
}

function waitForTabComplete(tabId, timeoutMs = 45000) {
  return new Promise((resolve, reject) => {
    const started = Date.now();
    let settled = false;
    let timer = null;
    let pollInterval = null;

    const cleanup = () => {
      settled = true;
      if (timer) clearTimeout(timer);
      if (pollInterval) clearInterval(pollInterval);
      chrome.tabs.onUpdated.removeListener(listener);
    };

    const done = (err) => {
      if (settled) return;
      cleanup();
      if (err) reject(err);
      else resolve();
    };

    timer = setTimeout(() => {
      done(new Error("tab_load_timeout"));
    }, timeoutMs);

    const listener = (updatedTabId, changeInfo) => {
      if (updatedTabId === tabId && changeInfo.status === "complete") {
        done();
      }
    };

    chrome.tabs.onUpdated.addListener(listener);

    const checkTab = async () => {
      try {
        const tab = await getTab(tabId);
        if (tab && tab.status === "complete") {
          done();
          return;
        }
        if (Date.now() - started > 2500 && tab?.url) {
          try {
            const execution = await executeFunction(tabId, () => document.readyState, [], "ISOLATED");
            if (execution?.result === "complete" || execution?.result === "interactive") {
              done();
              return;
            }
          } catch (_err) {
            // Ignore script errors while tab is transitioning
          }
        }
      } catch (_error) {
        // Ignore transient getTab errors during navigation
      }
    };

    pollInterval = setInterval(checkTab, 500);
    checkTab();
  });
}

function createTab(options) {
  return new Promise((resolve, reject) => {
    try {
      const result = chrome.tabs.create(options, (tab) => {
        const error = chrome.runtime.lastError;
        if (error) {
          reject(new Error(error.message));
          return;
        }
        if (!tab?.id) {
          reject(new Error("tab_create_failed"));
          return;
        }
        resolve(tab);
      });
      if (result && typeof result.then === "function") {
        result.then(resolve).catch(reject);
      }
    } catch (error) {
      reject(error);
    }
  });
}

function getTab(tabId) {
  return new Promise((resolve, reject) => {
    try {
      const result = chrome.tabs.get(tabId, (tab) => {
        const error = chrome.runtime.lastError;
        if (error) {
          reject(new Error(error.message));
          return;
        }
        resolve(tab);
      });
      if (result && typeof result.then === "function") {
        result.then(resolve).catch(reject);
      }
    } catch (error) {
      reject(error);
    }
  });
}

function updateTab(tabId, options) {
  return new Promise((resolve, reject) => {
    try {
      const result = chrome.tabs.update(tabId, options, (tab) => {
        const error = chrome.runtime.lastError;
        if (error) {
          reject(new Error(error.message));
          return;
        }
        resolve(tab);
      });
      if (result && typeof result.then === "function") {
        result.then(resolve).catch(reject);
      }
    } catch (error) {
      reject(error);
    }
  });
}

function removeTab(tabId) {
  return new Promise((resolve, reject) => {
    try {
      const result = chrome.tabs.remove(tabId, () => {
        const error = chrome.runtime.lastError;
        if (error) {
          reject(new Error(error.message));
          return;
        }
        resolve();
      });
      if (result && typeof result.then === "function") {
        result.then(resolve).catch(reject);
      }
    } catch (error) {
      reject(error);
    }
  });
}

function sendProgress(job, step, progress) {
  return sendSocketMessage({
    type: "job_progress",
    job_id: job.job_id,
    status: "pending",
    step,
    progress
  });
}

async function sendJobResult(job, outcome) {
  const normalizedError = outcome.success ? {} : normalizeJobError(outcome, job);
  const payload = {
    type: "job_result",
    job_id: job.job_id,
    status: outcome.success ? "done" : "error",
    success: Boolean(outcome.success),
    data: outcome.data || null,
    error: normalizedError.error || outcome.error || null,
    message: normalizedError.message || outcome.message || outcome.error || null,
    error_code: normalizedError.error_code || null,
    platform: normalizedError.platform || job.platform || null,
    login_url: normalizedError.login_url || null
  };
  await sendSocketMessageWithResultAck(payload);
  return payload;
}

async function sendSocketMessageWithResultAck(payload) {
  let lastError = null;
  for (let attempt = 0; attempt <= RESULT_ACK_RETRY_COUNT; attempt += 1) {
    const ackId = createAckId(payload.job_id);
    const payloadWithAck = { ...payload, ack_id: ackId };
    const ackPromise = waitForResultAck(ackId, payload.job_id);
    if (!sendSocketMessage(payloadWithAck)) {
      clearPendingResultAck(ackId);
      throw new Error("job_result_socket_closed");
    }
    try {
      return await ackPromise;
    } catch (error) {
      lastError = error;
    }
  }
  throw lastError || new Error("job_result_ack_timeout");
}

function waitForResultAck(ackId, jobId) {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      pendingResultAcks.delete(ackId);
      reject(new Error(`job_result_ack_timeout:${jobId || ""}`));
    }, RESULT_ACK_TIMEOUT_MS);
    pendingResultAcks.set(ackId, { jobId, resolve, reject, timeout });
  });
}

function resolveResultAck(message) {
  const ackId = String(message?.ack_id || "");
  const pending = pendingResultAcks.get(ackId);
  if (!pending) {
    return false;
  }
  clearTimeout(pending.timeout);
  pendingResultAcks.delete(ackId);
  pending.resolve(message);
  return true;
}

function clearPendingResultAck(ackId) {
  const pending = pendingResultAcks.get(ackId);
  if (!pending) {
    return;
  }
  clearTimeout(pending.timeout);
  pendingResultAcks.delete(ackId);
}

function rejectAllPendingResultAcks(error) {
  for (const [ackId, pending] of pendingResultAcks.entries()) {
    clearTimeout(pending.timeout);
    pending.reject(error);
    pendingResultAcks.delete(ackId);
  }
}

function createAckId(jobId) {
  return `${jobId || "job"}:${Date.now()}:${Math.random().toString(36).slice(2)}`;
}

function normalizeJobError(error, job) {
  const details = error?.details && typeof error.details === "object" ? error.details : {};
  const message = error?.message || error?.error || details.message || details.error || String(error || "extension_job_failed");
  return {
    error: message,
    message,
    error_code: String(error?.error_code || error?.code || details.error_code || details.code || "").trim() || null,
    platform: String(error?.platform || details.platform || job?.platform || "").trim().toLowerCase() || null,
    login_url: isSafeHttpUrl(error?.login_url || details.login_url) ? String(error?.login_url || details.login_url) : null
  };
}

function isSafeHttpUrl(value) {
  try {
    const parsed = new URL(String(value || ""));
    return parsed.protocol === "http:" || parsed.protocol === "https:";
  } catch (_error) {
    return false;
  }
}

function sendSocketMessage(payload) {
  if (!socket || socket.readyState !== WebSocket.OPEN) {
    return false;
  }
  socket.send(JSON.stringify(payload));
  return true;
}

function normalizeJob(job) {
  const source = job && typeof job === "object" ? job : {};
  const platform = normalizePlatform(source.platform);
  const username = normalizeJobUsername(source);
  const url = normalizeJobUrl(source, platform, username);
  return {
    ...source,
    job_id: String(source.job_id || source.jobId || source.id || ""),
    command: String(source.command || source.social_data_type || "profile").toLowerCase(),
    platform,
    username,
    url,
    social_data_type: String(source.social_data_type || source.command || "profile_info"),
    limits: source.limits || {},
    cursor: source.cursor || { hash_id: source.hash_id || "" }
  };
}

function normalizeJobUrl(source, platform, username) {
  if (platform === "facebook") {
    const fromUsername = username ? facebookProfileUrl({ username }) : "";
    if (fromUsername) return fromUsername;
    const rawUrl = String(source.profile_url || source.url || "");
    try {
      const url = new URL(rawUrl);
      if (url.hostname.includes("facebook.com") && isFacebookProfileRoute(url)) {
        return normalizeFacebookProfileRoute(url);
      }
    } catch (_error) {
      // Fall through to empty URL for invalid Facebook targets.
    }
    return "";
  }
  return String(source.url || buildProfileUrl(platform, username));
}

function normalizeJobUsername(source) {
  const raw = String(
    source.username
    || source.requested_username
    || source.requestedUsername
    || source.profile_username
    || source.profileUsername
    || source.handle
    || ""
  ).trim();
  if (!raw) return "";
  try {
    const url = new URL(raw);
    if (url.hostname.includes("facebook.com")) {
      if (/\/profile\.php$/i.test(url.pathname) && url.searchParams.get("id")) {
        return url.searchParams.get("id") || "";
      }
      return decodeURIComponent(url.pathname.split("/").filter(Boolean)[0] || "").replace(/^@+/, "");
    }
  } catch (_error) {
    // Keep treating it as a username/handle.
  }
  return raw.replace(/^@+/, "").split(/[/?#]/)[0];
}

function normalizePlatform(platform) {
  const value = String(platform || "").trim().toLowerCase();
  return value === "twitter" ? "x" : value;
}

function buildProfileUrl(platform, username) {
  if (platform === "linkedin") {
    return buildLinkedInProfileUrl(username);
  }
  if (platform === "facebook" && !String(username || "").trim()) {
    return "";
  }
  const encoded = encodeURIComponent(username || "");
  const urls = {
    reddit: `https://www.reddit.com/user/${encoded}/`,
    x: `https://x.com/${encoded}`,
    twitter: `https://x.com/${encoded}`,
    instagram: `https://www.instagram.com/${encoded}/`,
    facebook: `https://www.facebook.com/${encoded}`,
    github: `https://github.com/${encoded}`,
    youtube: `https://www.youtube.com/@${encoded}`,
    tiktok: `https://www.tiktok.com/@${encoded}`
  };
  return urls[platform] || "";
}

function buildLinkedInProfileUrl(username) {
  const value = String(username || "").trim();
  try {
    const url = new URL(value);
    const match = url.pathname.match(/^\/(in|company|showcase)\/([^/?#]+)/i);
    if (/linkedin\.com$/i.test(url.hostname) && match) {
      return `https://www.linkedin.com/${match[1].toLowerCase()}/${encodeURIComponent(decodeURIComponent(match[2]))}/`;
    }
  } catch (_error) {
    // Treat non-URL values as LinkedIn identifiers.
  }
  const match = value.match(/^(in|profile|company|showcase)[:/]([^/?#]+)/i);
  const kind = !match || match[1].toLowerCase() === "profile" ? "in" : match[1].toLowerCase();
  const slug = match ? match[2] : value.replace(/^@/, "");
  return `https://www.linkedin.com/${kind}/${encodeURIComponent(slug)}/`;
}

function scraperStep(job) {
  if (job.command.includes("image")) {
    return "collecting_images";
  }
  if (["posts", "videos", "shorts"].some((value) => job.command.includes(value))) {
    return "collecting_posts";
  }
  return "collecting_profile";
}

async function getSettings() {
  const values = await storageGet(Object.keys(DEFAULT_SETTINGS));
  return { ...DEFAULT_SETTINGS, ...compactSettings(values) };
}

function sanitizeSettings(settings) {
  const next = {};
  if (typeof settings.backendUrl === "string" && settings.backendUrl.trim()) {
    next.backendUrl = settings.backendUrl.trim();
  }
  if (typeof settings.authApiBaseUrl === "string" && settings.authApiBaseUrl.trim()) {
    next.authApiBaseUrl = normalizeApiBaseUrl(settings.authApiBaseUrl);
  }
  if (typeof settings.authToken === "string") {
    next.authToken = settings.authToken.trim();
  }
  if (typeof settings.autoConnect === "boolean") {
    next.autoConnect = settings.autoConnect;
  }
  if (typeof settings.closeTabsAfterScrape === "boolean") {
    next.closeTabsAfterScrape = settings.closeTabsAfterScrape;
  }
  return next;
}

async function prepareAuth(settings) {
  const manualToken = String(settings.authToken || "").trim();
  const sessionToken = String(settings.sessionToken || "").trim();
  if (manualToken && !looksLikeJwt(manualToken)) {
    return { token: manualToken, authType: "static", authState: "static_token" };
  }
  const token = sessionToken || manualToken;
  if (!token) {
    return { token: "", authType: "", authState: "missing" };
  }
  if (looksLikeJwt(token) && isJwtExpired(token, AUTH_EXPIRY_SKEW_SECONDS)) {
    await logoutExpiredSession("auth_token_expired");
    return { token: "", authType: "orion_jwt", authState: "expired" };
  }
  const refreshResult = await refreshOrionToken(token, settings.authApiBaseUrl, settings.backendUrl);
  if (!refreshResult.token) {
    if (refreshResult.shouldLogout) {
      await logoutExpiredSession(refreshResult.reason || "auth_session_expired");
      return { token: "", authType: "orion_jwt", authState: "expired" };
    }
    if (looksLikeJwt(token) && refreshResult.networkError && !isJwtExpired(token, AUTH_EXPIRY_SKEW_SECONDS)) {
      await setStatus({ authState: "refresh_failed", lastError: refreshResult.reason || "auth_refresh_unreachable" });
      return { token, authType: "orion_jwt", authState: "refresh_failed" };
    }
    return { token: "", authType: "orion_jwt", authState: "refresh_failed" };
  }
  await storageSet({
    sessionToken: refreshResult.token,
    ...(refreshResult.authApiBaseUrl ? { authApiBaseUrl: refreshResult.authApiBaseUrl } : {})
  });
  return { token: refreshResult.token, authType: "orion_jwt", authState: "authenticated" };
}

async function refreshOrionToken(token, authApiBaseUrl, backendUrl) {
  let lastNetworkError = "";
  for (const proxyBaseUrl of getAuthProxyBaseUrlCandidates(backendUrl)) {
    try {
      const response = await fetch(`${proxyBaseUrl}/extensions/auth/refresh`, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ token })
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) {
        const reason = authRefreshFailureReason(response.status, payload);
        await setStatus({ authState: shouldLogoutForRefreshStatus(response.status) ? "expired" : "refresh_failed", lastError: reason });
        return { token: "", shouldLogout: shouldLogoutForRefreshStatus(response.status), reason };
      }
      const accessToken = String(payload?.access_token || "").trim();
      if (!accessToken) {
        await setStatus({ authState: "refresh_failed", lastError: "auth_refresh_empty_token" });
        return { token: "", shouldLogout: true, reason: "auth_refresh_empty_token" };
      }
      await setStatus({ authState: "authenticated", lastError: "" });
      return { token: accessToken };
    } catch (error) {
      lastNetworkError = error.message || String(error);
    }
  }

  for (const apiBaseUrl of getAuthApiBaseUrlCandidates(authApiBaseUrl)) {
    try {
      const response = await fetch(`${apiBaseUrl}/token/refresh`, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ token })
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) {
        const reason = authRefreshFailureReason(response.status, payload);
        await setStatus({ authState: shouldLogoutForRefreshStatus(response.status) ? "expired" : "refresh_failed", lastError: reason });
        return { token: "", shouldLogout: shouldLogoutForRefreshStatus(response.status), reason };
      }
      const accessToken = String(payload?.access_token || "").trim();
      if (!accessToken) {
        await setStatus({ authState: "refresh_failed", lastError: "auth_refresh_empty_token" });
        return { token: "", shouldLogout: true, reason: "auth_refresh_empty_token" };
      }
      await setStatus({ authState: "authenticated", lastError: "" });
      return { token: accessToken, authApiBaseUrl: apiBaseUrl };
    } catch (error) {
      lastNetworkError = error.message || String(error);
    }
  }
  const reason = formatAuthNetworkError(lastNetworkError);
  await setStatus({ authState: "refresh_failed", lastError: reason });
  return { token: "", networkError: true, reason };
}

async function loginWithOrion(username, password, authApiBaseUrl, backendUrl) {
  const form = new URLSearchParams();
  form.set("username", username);
  form.set("password", password);
  form.set("scope", "orion_extension");

  let lastNetworkError = "";
  for (const proxyBaseUrl of getAuthProxyBaseUrlCandidates(backendUrl)) {
    try {
      const response = await fetch(`${proxyBaseUrl}/extensions/auth/login`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ username, password })
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) {
        if (isAuthCandidateMiss(response.status)) {
          lastNetworkError = payload?.detail || `login_${response.status}`;
          continue;
        }
        throw new Error(payload?.detail || `login_${response.status}`);
      }
      return { ...(payload || {}), authApiBaseUrl };
    } catch (error) {
      const message = error.message || String(error);
      if (!isNetworkFetchError(message)) {
        throw error;
      }
      lastNetworkError = message;
    }
  }

  for (const apiBaseUrl of getAuthApiBaseUrlCandidates(authApiBaseUrl)) {
    try {
      const response = await fetch(`${apiBaseUrl}/token`, {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        },
        body: form.toString()
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) {
        if (isAuthCandidateMiss(response.status)) {
          lastNetworkError = payload?.detail || `login_${response.status}`;
          continue;
        }
        throw new Error(payload?.detail || `login_${response.status}`);
      }
      return { ...(payload || {}), authApiBaseUrl: apiBaseUrl };
    } catch (error) {
      const message = error.message || String(error);
      if (!isNetworkFetchError(message)) {
        throw error;
      }
      lastNetworkError = message;
    }
  }
  throw new Error(formatAuthNetworkError(lastNetworkError));
}

function normalizeApiBaseUrl(value) {
  return String(value || DEFAULT_SETTINGS.authApiBaseUrl).trim().replace(/\/+$/, "");
}

function getAuthApiBaseUrlCandidates(preferred) {
  const values = [preferred, ...AUTH_API_BASE_URL_CANDIDATES]
    .filter((value) => typeof value === "string" && value.trim())
    .map(normalizeApiBaseUrl);
  return [...new Set(values)];
}

function getAuthProxyBaseUrlCandidates(backendUrl) {
  const values = [backendUrlToHttpBaseUrl(backendUrl), ...AUTH_PROXY_BASE_URL_CANDIDATES]
    .filter((value) => typeof value === "string" && value.trim())
    .map((value) => String(value).trim().replace(/\/+$/, ""));
  return [...new Set(values)];
}

function backendUrlToHttpBaseUrl(backendUrl) {
  try {
    const url = new URL(backendUrl || DEFAULT_SETTINGS.backendUrl);
    url.protocol = url.protocol === "wss:" ? "https:" : "http:";
    url.pathname = "";
    url.search = "";
    url.hash = "";
    return url.toString().replace(/\/+$/, "");
  } catch (_error) {
    return "";
  }
}

function isNetworkFetchError(message) {
  const value = String(message || "").toLowerCase();
  return value.includes("failed to fetch")
    || value.includes("networkerror")
    || value.includes("load failed")
    || value.includes("could not connect")
    || value.includes("unreachable")
    || value.includes("fetch");
}

function isAuthCandidateMiss(status) {
  return [404, 405].includes(Number(status));
}

function formatAuthNetworkError(detail) {
  const suffix = detail ? ` (${detail})` : "";
  return `Orion Intelligence API not reachable. Start Orion Intelligence or open its HTTPS URL once to trust the local certificate.${suffix}`;
}

function authRefreshFailureReason(status, payload) {
  const detail = payload?.detail || payload?.message || "";
  return detail ? `auth_refresh_${status}: ${detail}` : `auth_refresh_${status}`;
}

function shouldLogoutForRefreshStatus(status) {
  return [401, 403, 419, 440].includes(Number(status));
}

function looksLikeJwt(value) {
  return /^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(String(value || ""));
}

function isJwtExpired(token, skewSeconds = 0) {
  const exp = jwtExpirySeconds(token);
  return exp !== null && Date.now() / 1000 >= exp - Number(skewSeconds || 0);
}

function jwtExpirySeconds(token) {
  const payload = decodeJwtPayload(token);
  const exp = Number(payload?.exp);
  return Number.isFinite(exp) && exp > 0 ? exp : null;
}

function decodeJwtPayload(token) {
  try {
    const payload = String(token || "").split(".")[1] || "";
    const normalized = payload.replace(/-/g, "+").replace(/_/g, "/");
    const padded = normalized + "=".repeat((4 - normalized.length % 4) % 4);
    return JSON.parse(globalThis.atob(padded));
  } catch (_error) {
    return null;
  }
}

function scheduleAuthExpiryLogout(token) {
  clearAuthExpiryTimer();
  if (!looksLikeJwt(token)) {
    return;
  }
  const exp = jwtExpirySeconds(token);
  if (exp === null) {
    return;
  }
  const delayMs = Math.max(0, Math.floor((exp - Date.now() / 1000 - AUTH_EXPIRY_SKEW_SECONDS) * 1000));
  authExpiryTimer = setTimeout(() => {
    authExpiryTimer = null;
    logoutExpiredSession("auth_token_expired").catch((error) => {
      setStatus({ authState: "expired", lastError: error.message || String(error) });
    });
  }, Math.min(delayMs, 2147483647));
}

function clearAuthExpiryTimer() {
  if (authExpiryTimer) {
    clearTimeout(authExpiryTimer);
    authExpiryTimer = null;
  }
}

function compactSettings(values) {
  return Object.fromEntries(Object.entries(values || {}).filter(([, value]) => value !== undefined && value !== null));
}

async function getStatus() {
  const values = await storageGet([...Object.keys(DEFAULT_SETTINGS), "statusSnapshot"]);
  const settings = { ...DEFAULT_SETTINGS, ...compactSettings(values) };
  const storedToken = settings.sessionToken || (looksLikeJwt(settings.authToken) ? settings.authToken : "");
  if (storedToken && isJwtExpired(storedToken, AUTH_EXPIRY_SKEW_SECONDS)) {
    await logoutExpiredSession("auth_token_expired");
    return getStatus();
  }
  const storedStatus = values.statusSnapshot && typeof values.statusSnapshot === "object" ? values.statusSnapshot : {};
  return {
    ...storedStatus,
    ...statusSnapshot,
    backendUrl: settings.backendUrl,
    authApiBaseUrl: settings.authApiBaseUrl,
    autoConnect: settings.autoConnect,
    closeTabsAfterScrape: settings.closeTabsAfterScrape,
    hasAuthToken: Boolean(settings.authToken),
    hasSessionToken: Boolean(settings.sessionToken),
    hasRefreshToken: Boolean(settings.refreshToken)
  };
}

async function setStatus(patch) {
  statusSnapshot = { ...statusSnapshot, ...patch };
  await storageSet({ statusSnapshot });
  safeRuntimeSendMessage({ type: "orion:statusChanged", status: statusSnapshot });
}

function storageGet(keys) {
  return new Promise((resolve) => {
    let settled = false;
    const finish = (value) => {
      if (settled) {
        return;
      }
      settled = true;
      resolve(value && typeof value === "object" ? value : {});
    };
    try {
      const result = chrome.storage.local.get(keys, (value) => {
        const error = chrome.runtime.lastError;
        finish(error ? {} : value);
      });
      if (result && typeof result.then === "function") {
        result.then(finish).catch(() => finish({}));
      }
    } catch (_error) {
      finish({});
    }
  });
}

function storageSet(values) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const finish = (error) => {
      if (settled) {
        return;
      }
      settled = true;
      if (error) {
        reject(new Error(error.message || String(error)));
        return;
      }
      resolve();
    };
    try {
      const result = chrome.storage.local.set(values, () => {
        finish(chrome.runtime.lastError || null);
      });
      if (result && typeof result.then === "function") {
        result.then(() => finish(null)).catch(finish);
      }
    } catch (error) {
      finish(error);
    }
  });
}

function safeRuntimeSendMessage(message) {
  try {
    const result = chrome.runtime.sendMessage(message, () => {
      void chrome.runtime.lastError;
    });
    if (result && typeof result.catch === "function") {
      result.catch(() => undefined);
    }
  } catch (_error) {
    // No popup/listener is open. Status is still persisted in storage.
  }
}

function clearReconnect() {
  if (reconnectTimer) {
    clearTimeout(reconnectTimer);
    reconnectTimer = null;
  }
}

function clearHeartbeat() {
  if (heartbeatTimer) {
    clearInterval(heartbeatTimer);
    heartbeatTimer = null;
  }
}

function parseJson(rawData) {
  try {
    return JSON.parse(rawData);
  } catch (_error) {
    return null;
  }
}

(function () {
  const helpers = window.OrionScraperHelpers;

  const POST_URL_SELECTORS = [
    "a[href*='/groups/'][href*='/posts/']",
    "a[href*='/posts/']",
    "a[href*='/permalink/']",
    "a[href*='/reel/']",
    "a[href*='/videos/']",
    "a[href*='/watch/']",
    "a[href*='/photo.php']",
    "a[href*='/photos/']",
    "a[href*='/events/']",
    "a[href*='/marketplace/item/']",
    "a[href*='story_fbid=']"
  ];

  const POST_CONTAINER_SELECTOR = "[data-virtualized='false']:has([data-ad-rendering-role='story_message'])";
  const COMMENT_SELECTORS = "[role='article'][aria-label^='Comment by'], [role='article'][aria-label^='Reply by']";

  const POST_MARKER_SELECTORS = [
    "[aria-label='Actions for this post']",
    "[data-ad-rendering-role='profile_name']",
    "[data-ad-rendering-role='story_message']",
    "[data-ad-rendering-role='like_button']",
    "[data-ad-rendering-role='comment_button']",
    "[data-ad-rendering-role='share_button']",
    "[data-ad-rendering-role='meta']",
    "[data-ad-rendering-role='title']",
    "[data-ad-rendering-role='description']",
    "img[data-imgperflogname='feedImage']",
    "video",
    ...POST_URL_SELECTORS
  ];

  const CONTENT_SELECTORS = [
    "[data-ad-rendering-role='story_message']",
    "[data-ad-comet-preview='message']",
    "[data-ad-preview='message']",
    "[data-testid='post_message']",
    "div[dir='auto'][style*='text-align']"
  ];

  const ATTACHMENT_TEXT_SELECTORS = [
    "[data-ad-rendering-role='title']",
    "[data-ad-rendering-role='description']",
    "[data-ad-rendering-role='meta']"
  ];

  window.OrionScrapers = window.OrionScrapers || {};
  window.OrionScrapers.facebook = {
    selectors: [
      "h1",
      "[role='article']",
      "[data-pagelet*='FeedUnit']",
      ...POST_MARKER_SELECTORS,
      "[role='main']"
    ],
    async run(job) {
      const username = job.username || usernameFromUrl();
      assertCanScrape(username);
      expandVisibleTruncations();

      const profile = collectProfile(username);
      const posts = shouldCollectPosts(job) ? await collectPosts(job, profile) : [];

      return {
        platform: "facebook",
        username,
        url: window.location.href,
        profile,
        posts,
        images: collectImages(posts, profile),
        followers: [],
        following: []
      };
    }
  };

  function usernameFromUrl() {
    if (/\/profile\.php$/i.test(window.location.pathname)) {
      return new URLSearchParams(window.location.search).get("id") || "";
    }
    const parts = window.location.pathname.split("/").filter(Boolean);
    const reserved = new Set(["groups", "events", "watch", "marketplace", "pages", "people", "login", "recover", "checkpoint"]);
    return parts.find((part) => !reserved.has(part.toLowerCase())) || "";
  }

  function shouldCollectPosts(job) {
    const command = String(job?.command || job?.social_data_type || "profile").toLowerCase();
    return !["followers", "following"].includes(command);
  }

  function collectProfile(username) {
    const metaTitle = usefulTitle(helpers.meta("og:title") || helpers.meta("twitter:title") || "");
    const headingTitle = usefulTitle(firstText(["[role='main'] h1", "h1"]));
    const fallbackTitle = splitUsername(username);
    const displayName = headingTitle || metaTitle || fallbackTitle || username;
    const stats = parseProfileStats();
    const description = cleanDescription(helpers.meta("description") || helpers.meta("og:description"));
    const bio = collectBio(description);

    const profile = {
      username,
      display_name: displayName,
      bio,
      description,
      avatar_url: findAvatar(),
      cover_url: findCover(),
      followers_count: stats.followers,
      following_count: stats.following,
      likes_count: stats.likes,
      total_followers: stats.followers,
      total_following: stats.following
    };

    if (!profile.bio && isUsefulProfileText(description)) {
      profile.bio = description;
    }
    return profile;
  }

  function usefulTitle(value) {
    const title = cleanFacebookTitle(value);
    if (!title || /^facebook$/i.test(title) || /^log in/i.test(title)) {
      return "";
    }
    return title;
  }

  function splitUsername(username) {
    return String(username || "")
      .replace(/[_\-.]+/g, " ")
      .replace(/([a-z])([A-Z])/g, "$1 $2")
      .replace(/\s+/g, " ")
      .trim();
  }

  function collectBio(description) {
    const roots = [
      document.querySelector("[data-pagelet='ProfileTilesFeed']"),
      document.querySelector("[data-pagelet*='ProfileTilesFeed']"),
      ...Array.from(document.querySelectorAll("[role='main'] [aria-label*='Intro' i], [role='main'] [aria-label*='About' i]"))
    ].filter(Boolean);

    for (const root of roots) {
      const text = cleanContentText(root.innerText || root.textContent || "");
      if (isUsefulProfileText(text)) {
        return text.slice(0, 800);
      }
    }

    return isUsefulProfileText(description) ? description.slice(0, 800) : "";
  }

  function isUsefulProfileText(text) {
    if (!text || text.length < 3) {
      return false;
    }
    if (/\b(log in|sign up|create new account|forgot password|like\s*reply|reply|comment)\b/i.test(text)) {
      return false;
    }
    return !/^facebook$/i.test(text);
  }

  function cleanDescription(value) {
    const text = helpers.cleanText(value)
      .replace(/\s*\|\s*Facebook\s*$/i, "")
      .replace(/\s*is on Facebook\..*$/i, "")
      .trim();
    return /^facebook$/i.test(text) ? "" : text;
  }

  function cleanFacebookTitle(value) {
    return helpers.cleanText(value)
      .replace(/\s*\|\s*Facebook\s*$/i, "")
      .replace(/\s*\(\d+\)\s*$/i, "")
      .trim();
  }

  function firstText(selectors, root = document) {
    for (const selector of selectors) {
      const value = helpers.cleanText(root.querySelector(selector)?.innerText || root.querySelector(selector)?.textContent || "");
      if (value) {
        return value;
      }
    }
    return "";
  }

  function parseProfileStats() {
    const text = helpers.cleanText((document.querySelector("[role='main']") || document.body)?.innerText || "");
    return {
      followers: findCount(text, "followers"),
      following: findCount(text, "following"),
      likes: findCount(text, "likes")
    };
  }

  function findCount(text, label) {
    const match = text.match(new RegExp(`([\\d.,]+\\s*[KMB]?)\\s+${label}\\b`, "i"));
    return match ? countToInt(match[1]) : "";
  }

  function findAvatar() {
    const metaImage = cleanImageUrl(helpers.meta("og:image") || helpers.meta("twitter:image"));
    if (metaImage && !isDefaultAvatar(metaImage)) {
      return metaImage;
    }

    const candidates = [
      "[role='main'] a[href*='/photo'] img[src]",
      "[role='main'] image[href]",
      "svg image[href]",
      "[role='main'] img[alt*='profile picture' i]",
      "[role='main'] img[src*='scontent']"
    ];

    for (const selector of candidates) {
      const node = document.querySelector(selector);
      const value = cleanImageUrl(node?.getAttribute("href") || node?.getAttribute("xlink:href") || node?.getAttribute("src") || "");
      if (value && !isLikelyCover(value) && !isDefaultAvatar(value) && !isSmallImage(node)) {
        return value;
      }
    }
    return "";
  }

  function findCover() {
    const selectors = [
      "img[data-imgperflogname='profileCoverPhoto']",
      "[data-pagelet*='Cover'] img[src]",
      "[role='main'] img[alt*='cover photo' i]",
      "[role='main'] img[alt*='cover' i]"
    ];
    for (const selector of selectors) {
      const value = cleanImageUrl(document.querySelector(selector)?.getAttribute("src") || "");
      if (value && !isDefaultAvatar(value)) {
        return value;
      }
    }
    return "";
  }

  function cleanImageUrl(value) {
    const absolute = helpers.absoluteUrl(value);
    if (!absolute || absolute.startsWith("data:") || /static\.xx\.fbcdn\.net/i.test(absolute)) {
      return "";
    }
    return absolute;
  }

  function isLikelyCover(value) {
    return /cover|profileCoverPhoto/i.test(String(value || ""));
  }

  function isDefaultAvatar(value) {
    return /\/v\/t1\.30497-1\//i.test(String(value || ""));
  }

  function isSmallImage(node) {
    if (!node) {
      return false;
    }
    const rect = node.getBoundingClientRect?.() || {};
    const width = rect.width || node.naturalWidth || node.width || 0;
    const height = rect.height || node.naturalHeight || node.height || 0;
    return width > 0 && height > 0 && (width < 80 || height < 80);
  }

  async function collectPosts(job, profile) {
    const limit = Number(job?.limits?.max_posts || job?.max_posts || 10);
    const maxScrolls = Number(job?.limits?.max_scrolls || job?.max_scrolls || 12);
    const posts = [];
    const seen = new Set();
    let idleScrolls = 0;

    for (let scrollIndex = 0; posts.length < limit && scrollIndex <= maxScrolls; scrollIndex += 1) {
      const postsBeforeScroll = posts.length;
      const visiblePostsBeforeScroll = postContainerSignature();
      expandVisibleTruncations();
      await helpers.delay?.(250);

      for (const node of getPostContainers()) {
        if (posts.length >= limit) {
          break;
        }
        try {
          if (!isPostContainer(node)) {
            continue;
          }
          if (expandVisibleTruncations(node)) {
            await helpers.delay?.(100);
          }
          const post = postFromNode(node, profile);
          if (!hasPostPayload(post) || !post.url) {
            continue;
          }
          const key = post.url;
          if (seen.has(key)) {
            continue;
          }
          seen.add(key);
          await enrichPostDetails(post, node);
          posts.push(post);
        } catch (_error) {
          continue;
        }
      }

      idleScrolls = posts.length === postsBeforeScroll ? idleScrolls + 1 : 0;
      if (posts.length >= limit || scrollIndex === maxScrolls) {
        break;
      }
      if (idleScrolls >= 5) {
        break;
      }
      scrollPosts(scrollIndex);
      await waitForPostContainersToChange(visiblePostsBeforeScroll);
    }

    return posts;
  }

  function getPostContainers() {
    markPostRoots();
    const containers = [];
    const seen = new Set();
    const candidates = [
      ...Array.from(document.querySelectorAll("[data-fb-scraper-post-root]")),
      ...Array.from(document.querySelectorAll(POST_CONTAINER_SELECTOR)),
      ...POST_MARKER_SELECTORS.flatMap((selector) => Array.from(document.querySelectorAll(selector)))
        .map((marker) => bestPostContainerForMarker(marker))
        .filter(Boolean)
    ];

    for (const node of candidates) {
      const key = node.dataset?.fbScraperContainerKey || assignContainerKey(node);
      if (seen.has(key)) {
        continue;
      }
      seen.add(key);
      containers.push(node);
    }
    return containers.sort((left, right) => {
      const leftTop = left.getBoundingClientRect?.().top ?? 0;
      const rightTop = right.getBoundingClientRect?.().top ?? 0;
      return leftTop - rightTop;
    });
  }

  function markPostRoots() {
    let index = Number(document.documentElement.dataset.fbScraperPostSeq || "0");
    const markers = document.querySelectorAll(POST_MARKER_SELECTORS.join(","));
    for (const marker of markers) {
      const root = bestPostContainerForMarker(marker);
      if (root && !root.dataset.fbScraperPostRoot) {
        index += 1;
        root.dataset.fbScraperPostRoot = String(index);
      }
    }
    document.documentElement.dataset.fbScraperPostSeq = String(index);
  }

  function assignContainerKey(node) {
    const key = `fb-post-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    try {
      node.dataset.fbScraperContainerKey = key;
    } catch (_error) {
      // Dataset writes can fail on unusual DOM nodes; use geometry fallback.
    }
    return key;
  }

  function bestPostContainerForStory(story) {
    return bestPostContainerForMarker(story);
  }

  function bestPostContainerForMarker(marker) {
    const candidates = [];
    const article = marker.closest?.("div[role='article']");
    if (article) {
      candidates.push(article);
    }
    for (let node = marker; node && node !== document.body; node = node.parentElement) {
      if (node.matches?.("[data-virtualized='false']") && node.querySelector("[data-ad-rendering-role='story_message']")) {
        candidates.push(node);
      }
      const hasProfile = !!node.querySelector("[data-ad-rendering-role='profile_name']");
      const hasBody = !!node.querySelector(POST_MARKER_SELECTORS.join(","));
      if (hasProfile && hasBody) {
        candidates.push(node);
      }
      if (candidates.length >= 8) {
        break;
      }
    }
    if (!candidates.length) {
      return null;
    }
    return candidates
      .map((node) => ({ node, score: postContainerScore(node) }))
      .sort((left, right) => right.score - left.score)[0]?.node || candidates[0];
  }

  function postContainerScore(node) {
    const storyCount = node.querySelectorAll("[data-ad-rendering-role='story_message']").length;
    const rect = node.getBoundingClientRect?.() || {};
    let score = 0;
    if (findPostLink(node)) score += 80;
    if (node.querySelector("[data-ad-rendering-role='profile_name']")) score += 20;
    if (node.querySelector("[data-ad-rendering-role='like_button']")) score += 10;
    if (node.querySelector("[data-ad-rendering-role='comment_button']")) score += 10;
    if (node.querySelector("[data-ad-rendering-role='share_button']")) score += 10;
    if (node.querySelector("[data-ad-rendering-role='title']")) score += 8;
    if (node.querySelector("[data-ad-rendering-role='description']")) score += 8;
    if (node.querySelector("img[data-imgperflogname='feedImage']")) score += 25;
    if (node.querySelector("video")) score += 25;
    if (rect.height > 120) score += 5;
    if (storyCount === 1) score += 20;
    if (storyCount > 3) score -= storyCount * 25;
    return score;
  }

  function postContainerSignature() {
    return getPostContainers()
      .slice(0, 8)
      .map((node) => {
        const link = findPostLink(node);
        const url = cleanFacebookUrl(link?.getAttribute("href") || "");
        const text = helpers.cleanText(node.querySelector("[data-ad-rendering-role='story_message']")?.innerText || node.textContent || "");
        const rect = node.getBoundingClientRect?.() || {};
        return `${url}|${text.slice(0, 120)}|${Math.round(rect.top || 0)}`;
      })
      .join("||");
  }

  function scrollPosts(scrollIndex) {
    const amount = Math.max(900, Math.floor(window.innerHeight * (1.05 + Math.min(scrollIndex, 4) * 0.08)));
    const target = getScrollTarget();
    const containers = getPostContainers();
    const lastPost = containers[containers.length - 1];

    if (lastPost?.scrollIntoView) {
      lastPost.scrollIntoView({ block: "end", inline: "nearest", behavior: "auto" });
    }
    if (target && target !== document.documentElement && target !== document.body) {
      target.scrollBy({ top: amount, behavior: "auto" });
      target.scrollTop += amount;
      target.dispatchEvent(new WheelEvent("wheel", { deltaY: amount, bubbles: true, cancelable: true }));
    }
    window.scrollBy({ top: amount, behavior: "auto" });
    window.dispatchEvent(new WheelEvent("wheel", { deltaY: amount, bubbles: true, cancelable: true }));
    document.dispatchEvent(new KeyboardEvent("keydown", { key: "PageDown", code: "PageDown", bubbles: true }));
  }

  function getScrollTarget() {
    const candidates = [
      ...Array.from(document.querySelectorAll("div[role='feed'], div[role='main'], div[aria-label*='Feed' i]")),
      document.querySelector("[role='main']"),
      document.scrollingElement,
      document.documentElement,
      document.body
    ].filter(Boolean);

    return candidates.find((node) => {
      if (node === document.scrollingElement || node === document.documentElement || node === document.body) {
        return true;
      }
      const style = window.getComputedStyle(node);
      const canScroll = /(auto|scroll)/i.test(`${style.overflowY} ${style.overflow}`);
      return canScroll && node.scrollHeight > node.clientHeight + 50;
    }) || document.scrollingElement || document.documentElement;
  }

  async function waitForPostContainersToChange(previousSignature) {
    const startedAt = Date.now();
    while (Date.now() - startedAt < 2800) {
      await helpers.delay?.(250);
      const nextSignature = postContainerSignature();
      if (nextSignature && nextSignature !== previousSignature) {
        return true;
      }
    }
    await helpers.delay?.(700);
    return false;
  }

  function isPostContainer(node) {
    const aria = helpers.cleanText(node.getAttribute("aria-label") || "").toLowerCase();
    if (aria.startsWith("comment by") || aria.startsWith("reply by")) {
      return false;
    }
    if (node.matches(`[data-commentid], ${COMMENT_SELECTORS}`) || node.closest("[data-commentid]")) {
      return false;
    }
    if (looksLikeStandaloneComment(node)) {
      return false;
    }

    const hasPostRole = !!node.querySelector([
      "[data-ad-rendering-role='profile_name']",
      "[data-ad-rendering-role='story_message']",
      "[data-ad-comet-preview='message']",
      "[data-ad-preview='message']",
      "[data-testid='post_message']",
      "[data-ad-rendering-role='like_button']",
      "[data-ad-rendering-role='comment_button']",
      "[data-ad-rendering-role='share_button']",
      "[data-ad-rendering-role='title']",
      "[data-ad-rendering-role='description']",
      "img[data-imgperflogname='feedImage']",
      "video"
    ].join(","));
    return hasPostRole || !!findPostLink(node);
  }

  function looksLikeStandaloneComment(node) {
    const text = normalizeText(node.innerText || node.textContent || "");
    if (!text) {
      return true;
    }
    const hasPostMarker = !!node.querySelector([
      "[data-ad-rendering-role='profile_name']",
      "[data-ad-rendering-role='story_message']",
      "[data-ad-comet-preview='message']",
      "[data-ad-preview='message']",
      "[data-ad-rendering-role='like_button']",
      "[data-ad-rendering-role='comment_button']",
      "[data-ad-rendering-role='share_button']",
      "[data-ad-rendering-role='title']",
      "[data-ad-rendering-role='description']",
      "img[data-imgperflogname='feedImage']",
      "video"
    ].join(","));
    if (/Like\s*Reply/i.test(text) && !hasPostMarker) {
      return true;
    }
    return /^(comment|reply) by\b/i.test(helpers.cleanText(node.getAttribute("aria-label") || ""));
  }

  function postFromNode(node, profile) {
    const rawText = node.innerText || node.textContent || "";
    const link = findPostLink(node);
    const url = cleanFacebookUrl(link?.getAttribute("href") || "");
    const media = extractMedia(node);
    const content = extractContent(node, rawText);
    const date = extractPostDate(node, rawText, link);

    return {
      id: postIdFromUrl(url),
      title: extractPostTitle(node) || profile.display_name || "Facebook post",
      text: content,
      url,
      created_at: date,
      likes_count: extractLikes(node, rawText),
      comments_count: extractComments(node, rawText),
      shares_count: extractShares(node, rawText),
      loaded_comments: extractLoadedComments(node),
      type: detectPostType(url, media, rawText, node),
      image_url: media.images[0] || "",
      images: media.images,
      videos: media.videos,
      attachment_urls: media.attachment_urls,
      source: "facebook"
    };
  }

  function hasPostPayload(post) {
    return !!(post.url || post.text || post.image_url || post.videos.length || post.attachment_urls.length);
  }

  async function enrichPostDetails(post, node) {
    const maxComments = 50;
    const scrollState = captureScrollState();
    try {
      await withTimeout(async () => {
        await openPostComments(node, post);
        await expandVisibleComments(node);
        await expandVisibleComments(document);
      }, isReelPost(post) ? 4500 : 8000);
      const containerComments = extractLoadedComments(node);
      const pageComments = extractLoadedComments(document);
      post.loaded_comments = uniqueStrings([...containerComments, ...pageComments]).slice(0, maxComments);
      if (!post.comments_count) {
        post.comments_count = extractComments(node, node.innerText || node.textContent || "");
      }
    } catch (_error) {
      // Keep the feed post even when Facebook refuses to open comment UI.
    } finally {
      tryClosePostOverlay();
      closeReelOverlay();
      restoreScrollState(scrollState);
      await helpers.delay?.(200);
    }
  }

  async function openPostComments(node, post) {
    const commentButton = node.querySelector("[data-ad-rendering-role='comment_button']");
    if (commentButton) {
      clickElement(commentButton);
      await helpers.delay?.(900);
      return true;
    }

    if (isReelPost(post)) {
      return false;
    }

    const link = findPostLink(node);
    if (!link) {
      return false;
    }
    const beforePath = window.location.href;
    clickElement(link);
    await helpers.delay?.(1200);
    if (window.location.href !== beforePath) {
      window.history.back();
      await helpers.delay?.(1200);
      return false;
    }
    return true;
  }

  function isReelPost(post) {
    const url = String(post?.url || "").toLowerCase();
    return post?.type === "reel" || url.includes("/reel/");
  }

  async function withTimeout(task, timeoutMs) {
    let timeoutId = null;
    try {
      return await Promise.race([
        Promise.resolve().then(task),
        new Promise((_resolve, reject) => {
          timeoutId = setTimeout(() => reject(new Error("facebook_detail_timeout")), timeoutMs);
        })
      ]);
    } finally {
      if (timeoutId !== null) {
        clearTimeout(timeoutId);
      }
    }
  }

  async function expandVisibleComments(root = document) {
    for (let pass = 0; pass < 4; pass += 1) {
      let clicked = 0;
      for (const element of root.querySelectorAll("div[role='button'], span[role='button'], a[role='link'], a[href], span")) {
        const text = helpers.cleanText(element.innerText || element.textContent || "");
        if (!/^(view|see|show)\s+(more|previous|all)?\s*(comments?|replies?)|more comments?|view previous replies$/i.test(text)) {
          continue;
        }
        const rect = element.getBoundingClientRect?.() || {};
        if (!rect.width || !rect.height) {
          continue;
        }
        clickElement(element);
        clicked += 1;
        if (clicked >= 8) {
          break;
        }
      }
      if (!clicked) {
        break;
      }
      await helpers.delay?.(900);
    }
  }

  function clickElement(element) {
    try {
      element.dispatchEvent(new MouseEvent("mouseover", { bubbles: true, cancelable: true, view: window }));
      element.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true, view: window }));
      element.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true, view: window }));
      element.click();
    } catch (_error) {
      // Ignore blocked synthetic interactions.
    }
  }

  function tryClosePostOverlay() {
    const closeButton = Array.from(document.querySelectorAll("div[aria-label='Close'][role='button'], div[aria-label='Close']"))
      .find((button) => {
        const rect = button.getBoundingClientRect?.() || {};
        return rect.width && rect.height;
      });
    if (closeButton) {
      clickElement(closeButton);
    }
  }

  function closeReelOverlay() {
    const dialog = Array.from(document.querySelectorAll("div[role='dialog']"))
      .find((node) => /reel|comment|like|share/i.test(helpers.cleanText(node.textContent || "")));
    if (!dialog) {
      return;
    }
    const closeButton = Array.from(dialog.querySelectorAll("div[aria-label='Close'][role='button'], div[aria-label='Close'], button[aria-label='Close']"))
      .find((button) => {
        const rect = button.getBoundingClientRect?.() || {};
        return rect.width && rect.height;
      });
    if (closeButton) {
      clickElement(closeButton);
      return;
    }
    try {
      document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", bubbles: true }));
    } catch (_error) {
      // Ignore blocked synthetic key events.
    }
  }

  function captureScrollState() {
    const target = getScrollTarget();
    return {
      target,
      targetTop: target?.scrollTop || 0,
      windowX: window.scrollX,
      windowY: window.scrollY
    };
  }

  function restoreScrollState(state) {
    if (!state) {
      return;
    }
    try {
      if (state.target && state.target !== document.documentElement && state.target !== document.body) {
        state.target.scrollTop = state.targetTop;
      }
      window.scrollTo({ left: state.windowX, top: state.windowY, behavior: "auto" });
    } catch (_error) {
      // Ignore scroll restoration failures after Facebook rerenders.
    }
  }

  function uniqueStrings(values) {
    const seen = new Set();
    return values.filter((value) => {
      const key = helpers.cleanText(value);
      if (!key || seen.has(key)) {
        return false;
      }
      seen.add(key);
      return true;
    });
  }

  function extractPostTitle(node) {
    const profileName = firstText(["[data-ad-rendering-role='profile_name']", "h2 strong", "h3 strong", "strong"], node);
    if (profileName && !isNoiseLine(profileName)) {
      return profileName;
    }
    const labelledLink = Array.from(node.querySelectorAll("a[aria-label]"))
      .map((link) => helpers.cleanText(link.getAttribute("aria-label") || ""))
      .find((label) => label && !isIgnoredLinkLabel(label) && !isNoiseLine(label));
    return labelledLink || "";
  }

  function findPostLink(node) {
    for (const root of postLinkSearchRoots(node)) {
      const link = firstPostLinkInRoot(root);
      if (link) {
        return link;
      }
    }
    return null;
  }

  function postLinkSearchRoots(node) {
    const roots = [];
    const seen = new Set();
    for (let current = node; current && current !== document.body; current = current.parentElement) {
      if (!seen.has(current)) {
        seen.add(current);
        roots.push(current);
      }
      if (roots.length >= 8) {
        break;
      }
    }
    return roots;
  }

  function firstPostLinkInRoot(root) {
    for (const selector of POST_URL_SELECTORS) {
      for (const link of root.querySelectorAll(selector)) {
        if (isUsablePostLink(link)) {
          return link;
        }
      }
    }
    return null;
  }

  function isUsablePostLink(link) {
    const label = helpers.cleanText(link.getAttribute("aria-label") || "").toLowerCase();
    if (isIgnoredLinkLabel(label)) {
      return false;
    }
    const href = link.getAttribute("href") || "";
    if (!href || isCommentPermalink(href)) {
      return false;
    }
    return !!cleanFacebookUrl(href);
  }

  function isIgnoredLinkLabel(label) {
    return ["enlarge", "comment", "like", "share", "react", "play", "mute", "reply"].includes(String(label || "").trim().toLowerCase());
  }

  function isCommentPermalink(value) {
    try {
      const url = new URL(value, window.location.href);
      return url.searchParams.has("comment_id") || /comment_id=/i.test(url.href);
    } catch (_error) {
      return /comment_id=/i.test(String(value || ""));
    }
  }

  function extractContent(node, rawText) {
    const contentParts = [];
    for (const selector of CONTENT_SELECTORS) {
      for (const element of node.querySelectorAll(selector)) {
        appendUnique(contentParts, cleanContentText(element.innerText || element.textContent || ""));
      }
    }
    if (contentParts.length) {
      return contentParts.join("\n").trim().slice(0, 4000);
    }

    const attachmentParts = [];
    for (const selector of ATTACHMENT_TEXT_SELECTORS) {
      for (const element of node.querySelectorAll(selector)) {
        appendUnique(attachmentParts, cleanContentText(element.innerText || element.textContent || ""));
      }
    }
    if (attachmentParts.length) {
      return attachmentParts.join("\n").trim().slice(0, 4000);
    }

    const lines = cleanContentText(rawText).split("\n");
    if (lines.length > 1 && lines[0].split(/\s+/).length <= 5) {
      lines.shift();
    }
    return lines.join("\n").trim().slice(0, 4000);
  }

  function appendUnique(parts, rawText) {
    for (const line of normalizeText(rawText).split("\n")) {
      if (line && !parts.includes(line)) {
        parts.push(line);
      }
    }
  }

  function normalizeText(rawText) {
    return String(rawText || "")
      .replace(/\r/g, "\n")
      .split("\n")
      .map((line) => line.replace(/\s+/g, " ").trim())
      .filter(Boolean)
      .join("\n")
      .trim();
  }

  function cleanContentText(rawText) {
    const cleaned = [];
    for (const line of normalizeText(rawText).split("\n")) {
      if (!isNoiseLine(line) && !cleaned.includes(line)) {
        cleaned.push(line);
      }
    }
    return cleaned.join("\n").trim();
  }

  function isNoiseLine(line) {
    const low = String(line || "").trim().toLowerCase();
    if (!low) {
      return true;
    }
    const skipWords = new Set([
      "facebook",
      "like",
      "comment",
      "share",
      "reply",
      "send",
      "react",
      "follow",
      "all reactions:",
      "see more",
      "show more",
      "view more comments",
      "write a comment...",
      "write a comment…",
      "shared with public",
      "public",
      "m.me",
      "facebook.com",
      "www.facebook.com"
    ]);
    if (skipWords.has(low)) {
      return true;
    }
    if (/\b(actions for this post|write a comment|like\s*reply|see original)\b/i.test(low)) {
      return true;
    }
    if (/\b(like|comment|share|send|react|reply)\b/i.test(low) && low.split(/\s+/).length <= 8) {
      return true;
    }
    if (/\b\d+(?:\.\d+)?[km]?\s*(views?|shares?|comments?|reactions?|likes?|followers?|following|members?)\b/i.test(low)) {
      return true;
    }
    if (/^\d+(?:\.\d+)?[km]?$/.test(low)) {
      return true;
    }
    if (/\.com$/.test(low) && !/\s/.test(low)) {
      return true;
    }
    if (low.length >= 40 && !/\s/.test(low) && /^[a-z0-9_=-]+$/i.test(low)) {
      return true;
    }
    return isDateLike(line);
  }

  function extractPostDate(node, rawText, link) {
    const candidates = [];
    for (const selector of POST_URL_SELECTORS) {
      for (const element of node.querySelectorAll(selector)) {
        for (const attr of ["datetime", "title", "aria-label"]) {
          const value = element.getAttribute(attr);
          if (value && !/reply|comment/i.test(value)) {
            candidates.push(value);
          }
        }
        const visible = helpers.cleanText(element.innerText || element.textContent || "");
        if (visible) {
          candidates.push(visible);
        }
      }
    }
    for (const attr of ["datetime", "title", "aria-label"]) {
      const value = link?.getAttribute(attr);
      if (value) {
        candidates.unshift(value);
      }
    }
    candidates.push(rawText);

    for (const candidate of candidates) {
      const parsed = parseDateText(candidate);
      if (parsed) {
        return parsed;
      }
    }
    return "";
  }

  function isDateLike(value) {
    return !!parseDateText(value);
  }

  function parseDateText(value) {
    const text = helpers.cleanText(String(value || "").replace(/·/g, " "));
    if (!text) {
      return "";
    }
    const patterns = [
      /\b\d{1,2}\s+[A-Za-z]{3,9}\s+\d{4}\b/,
      /\b[A-Za-z]{3,9}\s+\d{1,2},\s*\d{4}\b/,
      /\b\d{4}-\d{2}-\d{2}\b/,
      /\b(today|yesterday)\b/i,
      /\b\d+\s*(h|hr|hrs|hour|hours|m|min|mins|minute|minutes|d|day|days|w|week|weeks)\b/i,
      /\b\d{1,2}\s+[A-Za-z]{3,9}\b/,
      /\b[A-Za-z]{3,9}\s+\d{1,2}\b/
    ];
    const matched = patterns.map((pattern) => text.match(pattern)?.[0]).find(Boolean);
    return matched || "";
  }

  function extractLikes(node, rawText) {
    const text = helpers.cleanText(rawText);
    const reactionText = helpers.cleanText(node.querySelector("[data-ad-rendering-role='like_button']")?.innerText || "");
    const reactionMatch = reactionText.match(/([0-9.,kKmM]+)/i) || text.match(/all reactions:\s*([0-9.,kKmM]+)/i) || text.match(/([0-9.,kKmM]+)\s*(reactions?|likes?)\b/i);
    if (reactionMatch) {
      return countToInt(reactionMatch[1]);
    }
    const labelMatch = Array.from(node.querySelectorAll("[aria-label*='reaction' i], [aria-label*='like' i]"))
      .map((el) => el.getAttribute("aria-label") || "")
      .map((label) => label.match(/([0-9.,kKmM]+)/i)?.[1])
      .find(Boolean);
    return labelMatch ? countToInt(labelMatch) : "";
  }

  function extractComments(node, rawText) {
    const commentText = helpers.cleanText(node.querySelector("[data-ad-rendering-role='comment_button']")?.innerText || "");
    const match = commentText.match(/([0-9.,kKmM]+)/i) || helpers.cleanText(rawText).match(/([0-9.,kKmM]+)\s*comments?\b/i);
    return match ? countToInt(match[1]) : "";
  }

  function extractShares(node, rawText) {
    const shareText = helpers.cleanText(node.querySelector("[data-ad-rendering-role='share_button']")?.innerText || "");
    const match = shareText.match(/([0-9.,kKmM]+)/i) || helpers.cleanText(rawText).match(/([0-9.,kKmM]+)\s*shares?\b/i);
    return match ? countToInt(match[1]) : "";
  }

  function extractLoadedComments(node) {
    return Array.from(node.querySelectorAll(COMMENT_SELECTORS))
      .map((comment) => cleanContentText(comment.innerText || comment.textContent || ""))
      .filter(Boolean)
      .slice(0, 50);
  }

  function countToInt(value) {
    const match = String(value || "").replace(/,/g, "").trim().match(/(\d+(?:\.\d+)?)\s*([KM]?)/i);
    if (!match) {
      return "";
    }
    const multiplier = { K: 1000, M: 1000000 }[match[2].toUpperCase()] || 1;
    const parsed = parseFloat(match[1]);
    return Number.isFinite(parsed) ? Math.round(parsed * multiplier) : "";
  }

  function extractMedia(node) {
    const media = {
      images: [],
      videos: [],
      attachment_urls: []
    };

    const images = helpers.unique([
      ...Array.from(node.querySelectorAll("img[data-imgperflogname='feedImage'], img[src*='scontent']")),
      ...Array.from(node.querySelectorAll("img[src]"))
    ], (image) => image);
    for (const image of images) {
      const src = cleanImageUrl(image.getAttribute("src") || "");
      if (!src || isExcludedPostImage(image, src)) {
        continue;
      }
      if (!media.images.includes(src)) {
        media.images.push(src);
      }
    }

    for (const video of node.querySelectorAll("video")) {
      const src = helpers.absoluteUrl(video.getAttribute("src") || "");
      if (src && !src.startsWith("blob:") && !media.videos.includes(src)) {
        media.videos.push(src);
      }
      const poster = cleanImageUrl(video.getAttribute("poster") || "");
      if (poster && !media.images.includes(poster)) {
        media.images.push(poster);
      }
    }

    for (const link of node.querySelectorAll("a[href]")) {
      const clean = cleanFacebookUrl(link.getAttribute("href") || "");
      if (!clean) {
        continue;
      }
      try {
        if (new URL(clean).hostname.includes("facebook.com")) {
          continue;
        }
      } catch (_error) {
        // Keep non-URL attachment text out of this list.
        continue;
      }
      if (!media.attachment_urls.includes(clean)) {
        media.attachment_urls.push(clean);
      }
    }

    return media;
  }

  function isExcludedPostImage(image, src) {
    if (isDefaultAvatar(src) || /emoji|static\.xx\.fbcdn\.net|rsrc\.php|safe_image\.php/i.test(src)) {
      return true;
    }
    if (/_s(?:16|24|32|40|48|56|64|80)x(?:16|24|32|40|48|56|64|80)/i.test(src)) {
      return true;
    }
    const alt = String(image.getAttribute("alt") || "").toLowerCase();
    if (/\b(profile picture|emoji|icon|avatar)\b/.test(alt)) {
      return true;
    }
    const role = String(image.getAttribute("role") || "").toLowerCase();
    if (role === "presentation") {
      return true;
    }
    return isSmallImage(image);
  }

  function detectPostType(url, media, rawText, node) {
    const lowUrl = String(url || "").toLowerCase();
    const lowText = String(rawText || "").toLowerCase();
    if (lowUrl.includes("/marketplace/item/")) {
      return "marketplace";
    }
    if (lowUrl.includes("/events/")) {
      return "event";
    }
    if (lowUrl.includes("/reel/")) {
      return "reel";
    }
    if (lowUrl.includes("/watch/") || lowUrl.includes("/videos/") || media.videos.length || node.querySelector("video")) {
      return "video";
    }
    if (lowUrl.includes("/photo") || media.images.length) {
      return "photo";
    }
    if (lowText.includes(" was live") || lowText.includes(" live ")) {
      return "live";
    }
    if (media.attachment_urls.length || node.querySelector("[data-ad-rendering-role='title'], [data-ad-rendering-role='description']")) {
      return "link_or_share";
    }
    return "post";
  }

  function cleanFacebookUrl(value) {
    const absolute = helpers.absoluteUrl(value);
    if (!absolute) {
      return "";
    }
    try {
      const url = new URL(absolute);
      if (!url.hostname.includes("facebook.com")) {
        return url.toString();
      }
      const keepParams = new Set(["story_fbid", "id", "fbid"]);
      for (const key of Array.from(url.searchParams.keys())) {
        if (!keepParams.has(key)) {
          url.searchParams.delete(key);
        }
      }
      url.hash = "";
      return url.toString();
    } catch (_error) {
      return absolute;
    }
  }

  function postIdFromUrl(value) {
    if (!value) {
      return "";
    }
    try {
      const url = new URL(value);
      return url.searchParams.get("story_fbid")
        || url.searchParams.get("fbid")
        || (url.pathname.match(/\/groups\/[^/]+\/posts\/([^/?#]+)/i) || [])[1]
        || (url.pathname.match(/\/(?:posts|videos|reel|photos|permalink|events)\/([^/?#]+)/i) || [])[1]
        || (url.pathname.match(/\/marketplace\/item\/([^/?#]+)/i) || [])[1]
        || "";
    } catch (_error) {
      return "";
    }
  }

  function collectImages(posts, profile) {
    return helpers.unique(posts.flatMap((post) => (post.images?.length ? post.images : [post.image_url]).filter(Boolean).map((imageUrl) => ({
      image_url: imageUrl,
      source_url: post.url,
      title: post.title,
      source: "facebook"
    }))), (image) => image.image_url).slice(0, 30);
  }

  function expandVisibleTruncations(root = document) {
    const labels = new Set(["See more", "Show more"]);
    let clicked = 0;
    for (const element of root.querySelectorAll("div[role='button'], span[role='button'], a[role='link'], span")) {
      const text = helpers.cleanText(element.innerText || element.textContent || "");
      if (!labels.has(text)) {
        continue;
      }
      const rect = element.getBoundingClientRect();
      if (!rect.width || !rect.height) {
        continue;
      }
      try {
        element.click();
        clicked += 1;
      } catch (_error) {
        // Ignore inaccessible UI affordances.
      }
      if (clicked >= 25) {
        break;
      }
    }
    return clicked;
  }

  function assertCanScrape(username) {
    const authState = detectAuthRequired(username);
    if (authState.required) {
      throw createAuthRequiredError(authState);
    }
  }

  function detectAuthRequired(username) {
    const path = window.location.pathname.toLowerCase();
    const bodyText = helpers.cleanText(document.body?.innerText || document.body?.textContent || "");
    const hasLoginRoute = /\/(?:login|recover|checkpoint)\b/i.test(path);
    const hasCredentialForm = !!document.querySelector("input[name='email'], input[name='pass'], form[action*='/login']");
    const hasProfileSignals = hasFacebookProfileSignals(username);
    const hasLoginCopy = /\b(log in|sign up|create new account|forgot password)\b/i.test(bodyText);

    return {
      required: hasLoginRoute || (hasCredentialForm && !hasProfileSignals) || (!hasProfileSignals && hasLoginCopy),
      platform: "facebook",
      login_url: buildFacebookLoginUrl()
    };
  }

  function hasFacebookProfileSignals(username) {
    const mainText = helpers.cleanText(document.querySelector("[role='main']")?.innerText || "");
    if (document.querySelector("[role='main'] h1, [data-ad-rendering-role='profile_name'], [data-ad-rendering-role='story_message'], [data-pagelet*='FeedUnit']")) {
      return true;
    }
    return !!username && mainText.toLowerCase().includes(String(username).toLowerCase());
  }

  function buildFacebookLoginUrl() {
    return `https://www.facebook.com/login/?next=${encodeURIComponent(window.location.href)}`;
  }

  function createAuthRequiredError(authState) {
    const error = new Error("Facebook login required in this browser.");
    error.code = "AUTH_REQUIRED";
    error.error_code = "AUTH_REQUIRED";
    error.platform = authState.platform || "facebook";
    error.login_url = authState.login_url || buildFacebookLoginUrl();
    return error;
  }
})();

(function () {
  "use strict";

  const helpers = window.OrionScraperHelpers;
  const POST_LINK_SELECTORS = [
    'a[href*="/groups/"][href*="/posts/"]',
    'a[href*="/posts/"]',
    'a[href*="/permalink.php"]',
    'a[href*="/story.php"]',
    'a[href*="story_fbid="]',
    'a[href*="/reel/"]',
    'a[href*="/videos/"]',
    'a[href*="/watch/"]',
    'a[href*="/photo.php"]',
    'a[href*="/photos/"]'
  ].join(",");
  const MESSAGE_SELECTORS = [
    '[data-ad-rendering-role="story_message"]',
    '[data-ad-comet-preview="message"]',
    '[data-ad-preview="message"]',
    '[data-testid="post_message"]'
  ].join(",");
  const MEDIA_IMAGE_SELECTORS = [
    'img[data-imgperflogname="feedImage"]',
    'img[src*="scontent"]',
    'img[referrerpolicy="origin-when-cross-origin"]'
  ].join(",");
  const CONNECTION_BLOCKLIST = new Set([
    "about", "ads", "bookmarks", "business", "events", "friends", "followers",
    "following", "gaming", "groups", "help", "home.php", "login", "marketplace",
    "messages", "notifications", "pages", "people", "photo.php", "photos", "privacy",
    "reel", "reels", "search", "settings", "share", "story.php", "videos", "watch"
  ]);

  window.OrionScrapers = window.OrionScrapers || {};
  window.OrionScrapers.facebook = {
    selectors: [
      'meta[property="og:title"]',
      '[role="main"]',
      '[role="feed"]',
      '[data-pagelet^="ProfileTimeline"]'
    ],

    async run(job) {
      if (!helpers) throw new Error("OrionScraperHelpers is unavailable");

      const command = helpers.command(job) || "profile_info";
      const username = String(job?.username || usernameFromUrl()).replace(/^@/, "");
      const profileUrl = profileBaseUrl(job?.profile_url || job?.url || location.href, username);
      const profile = collectProfile(username, profileUrl);
      await mergePublicPluginProfile(profile, profileUrl);
      const state = { posts: [], photos: [], friends: [], followers: [], following: [] };
      const publish = () => setPartialResult(username, profileUrl, profile, state, job);

      if (["friends", "followers", "following"].includes(command)) {
        state[command] = await collectConnections(profileUrl, command, connectionLimit(job, command));
      } else if (!job?.skip_details && requestedItemId(job) && postKey(job?.url || location.href)) {
        const detailPost = await collectCurrentPostDetail(job, profileUrl);
        state.posts = detailPost ? [detailPost] : [];
      } else {
        await returnToProfile(profileUrl);
        state.posts = await collectPostQueue(job, profileUrl);
        publish();

        if (command !== "posts" && !job?.skip_details) {
          if (command !== "images") {
            for (const post of state.posts) {
              await enrichPost(post, profileUrl, job);
              publish();
            }
          }

          await returnToProfile(profileUrl);
          state.photos = await collectProfilePhotos(
            profileUrl,
            helpers.limit(job, "max_images", 25, 100)
          );
          publish();

          if (command !== "images") {
            state.friends = await collectConnections(profileUrl, "friends", connectionLimit(job, "friends"));
            publish();
            state.followers = await collectConnections(profileUrl, "followers", connectionLimit(job, "followers"));
            publish();
            state.following = await collectConnections(profileUrl, "following", connectionLimit(job, "following"));
            publish();
          }
        }
      }

      window.__orionLastPartialResult = null;
      return buildResult(username, profileUrl, profile, state, job);
    }
  };

  async function collectPostQueue(job, profileUrl) {
    const requested = Math.min(20, helpers.limit(job, "max_posts", 20, 100));
    const targetId = requestedItemId(job);
    const existing = existingPostKeys(job);
    let skip = existing.size ? 0 : helpers.limit(job, "post_offset", 0, 5000);
    const posts = [];
    const seen = new Set();
    let idle = 0;

    if (!await returnToProfile(profileUrl)) return posts;
    window.scrollTo({ top: 0, behavior: "instant" });
    await helpers.delay(800);

    for (let scroll = 0; scroll < 35 && posts.length < requested; scroll += 1) {
      const root = centerFeedRoot();
      if (!root) {
        await helpers.delay(700);
        continue;
      }

      expandVisibleText(root);
      const before = seen.size;
      for (const card of postCards(root)) {
        const post = await extractPostCard(card);
        if (!post?.url || !post.id || seen.has(post.id)) continue;
        seen.add(post.id);
        if (targetId && post.id !== targetId) continue;
        if (existing.has(post.id) || existing.has(postKey(post.url))) continue;
        if (skip > 0) {
          skip -= 1;
          continue;
        }
        posts.push(post);
        if (posts.length >= requested || targetId) break;
      }

      idle = seen.size === before ? idle + 1 : 0;
      if (posts.length >= requested || (targetId && posts.length) || idle >= 5) break;
      scrollRoot(root, 2200);
      await helpers.delay(1200);
    }

    return posts;
  }

  async function collectCurrentPostDetail(job, profileUrl) {
    const item = {
      id: requestedItemId(job) || postKey(job?.url || location.href),
      url: normalizePostUrl(job?.url || location.href) || normalizePostUrl(location.href)
    };
    const root = activePostRoot(item)
      || postCards(document.querySelector('[role="main"]') || document)[0]
      || document.querySelector('[role="main"]');
    if (!root) return null;
    const post = await extractPostCard(root);
    if (!post) return null;
    if (!post.url) {
      post.url = item.url;
      post.post_url = item.url;
      post.id = item.id;
      post.hash_id = item.id;
    }
    await enrichPost(post, profileUrl, job);
    return post;
  }

  async function extractPostCard(card) {
    const url = extractPostUrl(card);
    if (!url) return null;

    expandVisibleText(card);
    const author = extractAuthor(card);
    const caption = extractCaption(card);
    const attachment = extractAttachmentText(card);
    const media = await extractMedia(card);
    const shared = extractSharedContent(card);
    const type = detectPostType(card, url, media, shared);
    const counts = extractCounts(card);
    const createdAt = extractPostDate(card);
    const title = caption.slice(0, 140)
      || attachment.title
      || shared.text.slice(0, 140)
      || `${author || "Facebook"} ${type}`;

    return {
      id: postKey(url),
      hash_id: postKey(url),
      title,
      caption,
      text: caption || attachment.description || shared.text || title,
      url,
      post_url: url,
      created_at: createdAt,
      author,
      source: "facebook",
      media_type: type,
      media_url: media.thumbnail || media.images[0] || media.videoUrl || "",
      image_url: media.thumbnail || media.images[0] || "",
      thumbnail: media.thumbnail || media.images[0] || "",
      image_urls: media.images,
      video_url: media.videoUrl,
      attachment_urls: media.attachments,
      attachment_title: attachment.title,
      attachment_description: attachment.description,
      shared_author: shared.author,
      shared_text: shared.text,
      is_repost: shared.isShared,
      likes_count: counts.likes,
      comments_count: counts.comments,
      shares_count: counts.shares,
      views_count: counts.views,
      collected_comments_count: 0,
      comment_items: [],
      comment_details: []
    };
  }

  async function enrichPost(item, profileUrl, job) {
    const root = await openPost(item, profileUrl);
    if (!root) return;

    expandVisibleText(root);
    const stable = await waitForStableValue(() => postSignature(activePostRoot(item) || root), 12000);
    const currentRoot = activePostRoot(item) || root;
    if (!stable || !currentRoot) {
      await returnToProfile(profileUrl);
      return;
    }

    const detail = await extractPostCard(currentRoot);
    if (detail) mergePost(item, detail);

    const limit = helpers.limit(job, "max_comments", 25, 100);
    if (limit > 0) {
      const offset = helpers.limit(job, "comment_offset", 0, 5000);
      const comments = await collectComments(item, offset, limit);
      item.comment_details = comments;
      item.comment_items = comments.map((comment) => comment.text);
      item.collected_comments_count = comments.length;
      const displayed = extractCounts(activePostRoot(item) || currentRoot).comments;
      if (displayed > 0) item.comments_count = displayed;
    }

    await returnToProfile(profileUrl);
  }

  function mergePost(target, detail) {
    const scalarFields = [
      "title", "caption", "text", "created_at", "author", "media_type", "media_url",
      "image_url", "thumbnail", "video_url", "attachment_title", "attachment_description",
      "shared_author", "shared_text"
    ];
    for (const field of scalarFields) {
      if (detail[field]) target[field] = detail[field];
    }
    for (const field of ["likes_count", "comments_count", "shares_count", "views_count"]) {
      target[field] = Math.max(Number(target[field]) || 0, Number(detail[field]) || 0);
    }
    target.image_urls = unique([...(target.image_urls || []), ...(detail.image_urls || [])]);
    target.attachment_urls = unique([...(target.attachment_urls || []), ...(detail.attachment_urls || [])]);
    target.is_repost = Boolean(target.is_repost || detail.is_repost);
  }

  async function openPost(item, profileUrl) {
    if (routeMatchesPost(location.href, item.url)) {
      return waitForPostRoot(item, 8000);
    }

    if (!await returnToProfile(profileUrl)) return null;
    let link = findRenderedPostLink(item.url);
    if (!link) {
      window.scrollTo({ top: 0, behavior: "instant" });
      for (let scroll = 0; scroll < 35 && !link; scroll += 1) {
        link = findRenderedPostLink(item.url);
        if (link) break;
        const root = centerFeedRoot();
        if (!root) break;
        scrollRoot(root, 2200);
        await helpers.delay(900);
      }
    }
    if (!link) return null;

    link.scrollIntoView({ block: "center", behavior: "instant" });
    await helpers.delay(250);
    try { link.click(); } catch (_error) { return null; }
    return waitForPostRoot(item, 12000);
  }

  async function waitForPostRoot(item, timeoutMs) {
    const started = Date.now();
    while (Date.now() - started < timeoutMs) {
      const root = activePostRoot(item);
      if (root && isVisible(root) && postSignature(root)) {
        await helpers.delay(500);
        return root;
      }
      await helpers.delay(250);
    }
    return null;
  }

  function activePostRoot(item) {
    const dialogs = Array.from(document.querySelectorAll('div[role="dialog"]')).filter(isVisible);
    for (const dialog of dialogs.reverse()) {
      const articles = Array.from(dialog.querySelectorAll('[role="article"]')).filter(isVisible);
      const exact = articles.find((node) => {
        const link = extractPostUrl(node);
        return link && routeMatchesPost(link, item.url);
      });
      if (exact) return exact;
      const topPost = articles.find((node) => {
        if (node.parentElement?.closest('[role="article"]')) return false;
        if (/^comment by/i.test(cleanText(node.getAttribute("aria-label")))) return false;
        return Boolean(node.querySelector(`${MESSAGE_SELECTORS}, video, ${MEDIA_IMAGE_SELECTORS}`));
      });
      if (topPost) return topPost;
      if (dialog.querySelector("video, img") && postSignature(dialog)) return dialog;
    }

    const main = document.querySelector('[role="main"]');
    if (!main) return null;
    const candidates = postCards(main);
    return candidates.find((card) => {
      const link = extractPostUrl(card);
      return link && routeMatchesPost(link, item.url);
    }) || (routeMatchesPost(location.href, item.url) ? candidates[0] || main : null);
  }

  async function collectComments(item, offset, limit) {
    const target = offset + limit;
    const comments = [];
    const seen = new Set();
    let idle = 0;

    await selectAllComments(activePostRoot(item));
    for (let round = 0; round < 30 && comments.length < target; round += 1) {
      const root = activePostRoot(item);
      if (!root) break;
      expandCommentControls(root);
      const before = comments.length;

      for (const node of commentNodes(root)) {
        const comment = extractComment(node);
        if (!comment?.text) continue;
        const key = `${comment.username}|${comment.date}|${comment.text}`;
        if (seen.has(key)) continue;
        seen.add(key);
        comments.push(comment);
        if (comments.length >= target) break;
      }

      idle = comments.length === before ? idle + 1 : 0;
      if (comments.length >= target || idle >= 6) break;
      scrollCommentArea(root, 1800);
      await helpers.delay(700);
    }

    return comments.slice(offset, target);
  }

  async function selectAllComments(root) {
    if (!root || root.dataset.orionCommentsSorted === "1") return;
    root.dataset.orionCommentsSorted = "1";
    const controls = Array.from(root.querySelectorAll('[role="button"], button')).filter(isVisible);
    const sort = controls.find((node) => /most relevant|newest|top comments/i.test(cleanText(node.textContent)));
    if (!sort) return;
    try {
      sort.click();
      await helpers.delay(400);
      const options = Array.from(document.querySelectorAll('[role="menuitem"], [role="option"]')).filter(isVisible);
      const all = options.find((node) => /all comments/i.test(cleanText(node.textContent)));
      if (all) {
        all.click();
        await helpers.delay(700);
      }
    } catch (_error) { /* Best effort. */ }
  }

  function expandCommentControls(root) {
    const wanted = /view (?:more|previous) comments|more comments|view .*repl|more repl|see more comments/i;
    let clicked = 0;
    for (const node of root.querySelectorAll('[role="button"], button, span[role="button"]')) {
      if (!isVisible(node) || !wanted.test(cleanText(node.textContent))) continue;
      try { node.click(); clicked += 1; } catch (_error) { /* Detached. */ }
      if (clicked >= 12) break;
    }
  }

  function commentNodes(root) {
    return Array.from(root.querySelectorAll(
      '[aria-label^="Comment by" i], [data-commentid], div[role="article"]'
    )).filter((node) => {
      if (node === root || !isVisible(node)) return false;
      const text = cleanText(node.innerText || node.textContent);
      if (!text || /write a comment|view more comments|most relevant/i.test(text)) return false;
      const label = cleanText(node.getAttribute("aria-label"));
      return /^comment by/i.test(label)
        || node.hasAttribute("data-commentid")
        || (/\breply\b/i.test(text) && /\blike\b/i.test(text));
    });
  }

  function extractComment(node) {
    const label = cleanText(node.getAttribute("aria-label"));
    let username = label.match(/^Comment by\s+(.+?)(?:\s+\d|$)/i)?.[1] || "";
    if (!username) {
      username = cleanText(
        node.querySelector('a[role="link"] strong, strong, h3, h4')?.textContent || ""
      );
    }

    const time = cleanText(
      node.querySelector('a[href*="comment_id"], a[aria-label*="Reply" i], abbr, time')?.textContent || ""
    );
    const likes = count(
      node.querySelector('[aria-label*="Like" i]')?.getAttribute("aria-label") || ""
    );

    const lines = String(node.innerText || node.textContent || "")
      .split(/\n|(?<=\S)\s{2,}/)
      .map(cleanText)
      .filter(Boolean)
      .filter((line) => {
        const lower = line.toLowerCase();
        if (line === username) return false;
        if (["like", "reply", "share", "edited", "author"].includes(lower)) return false;
        if (/^\d+[smhdw]$/i.test(lower)) return false;
        if (/^\d+\s*(?:likes?|repl(?:y|ies))$/i.test(line)) return false;
        return !isCommentNoise(line);
      });

    const text = lines.find((line) => line.length > 2 && line !== username) || "";
    return {
      sender_name: username,
      username,
      text,
      date: time,
      likes
    };
  }

  async function collectProfilePhotos(profileUrl, requested) {
    if (requested < 1 || !await navigateToPhotosSection(profileUrl)) return [];

    const photos = [];
    const seen = new Set();
    let idle = 0;
    window.scrollTo({ top: 0, behavior: "instant" });
    await helpers.delay(800);

    for (let scroll = 0; scroll < 35 && photos.length < requested; scroll += 1) {
      const root = Array.from(document.querySelectorAll('[role="main"]')).find(isVisible);
      if (!root) break;
      const before = seen.size;

      for (const anchor of root.querySelectorAll([
        'a[href*="photo.php"][href*="fbid="]',
        'a[href*="/photo/"][href*="fbid="]',
        'a[href*="/photos/"]'
      ].join(","))) {
        const photo = extractProfilePhoto(anchor);
        if (!photo || seen.has(photo.id)) continue;
        seen.add(photo.id);
        photos.push(photo);
        if (photos.length >= requested) break;
      }

      idle = seen.size === before ? idle + 1 : 0;
      if (photos.length >= requested || idle >= 5) break;
      scrollRoot(root, 2200);
      await helpers.delay(950);
    }

    await returnToProfile(profileUrl);
    return photos;
  }

  function extractProfilePhoto(anchor) {
    if (!isVisible(anchor)) return null;
    const image = Array.from(anchor.querySelectorAll("img")).find((node) => {
      if (!isVisible(node)) return false;
      const rect = node.getBoundingClientRect();
      return rect.width >= 100 && rect.height >= 100;
    });
    if (!image) return null;

    const sourceUrl = normalizePhotoUrl(anchor.getAttribute("href") || "");
    const imageUrl = absoluteUrl(image.currentSrc || image.getAttribute("src") || "");
    if (!sourceUrl || !isUsableMediaUrl(imageUrl)) return null;

    const id = photoKey(sourceUrl) || `image:${imageUrl}`;
    const alt = cleanContent(image.getAttribute("alt") || "");
    const title = isUsefulPhotoText(alt) ? alt : "Facebook photo";
    return {
      id,
      hash_id: id,
      image_url: imageUrl,
      thumbnail: imageUrl,
      source_url: sourceUrl,
      url: sourceUrl,
      title,
      caption: isUsefulPhotoText(alt) ? alt : "",
      media_type: "photo",
      source: "facebook"
    };
  }

  async function navigateToPhotosSection(profileUrl) {
    if (!await returnToProfile(profileUrl)) return false;

    let link = findPhotosSectionLink(profileUrl);
    if (!link) {
      const more = Array.from(document.querySelectorAll('[role="button"], button')).find((node) => {
        const label = cleanText(node.textContent || node.getAttribute("aria-label"));
        return isVisible(node) && /^(?:more|more about)/i.test(label);
      });
      if (more) {
        try { more.click(); } catch (_error) { /* Best effort. */ }
        await helpers.delay(450);
        link = findPhotosSectionLink(profileUrl);
      }
    }

    if (!link) return false;
    try { link.click(); } catch (_error) { return false; }
    return waitForPhotosSection(10000);
  }

  function findPhotosSectionLink(profileUrl) {
    const links = Array.from(document.querySelectorAll('a[href]')).filter(isVisible);
    return links.find((anchor) => {
      const text = cleanText(anchor.textContent).toLowerCase();
      return isPhotosSectionUrl(anchor.href, profileUrl) && text === "photos";
    }) || links.find((anchor) => isPhotosSectionUrl(anchor.href, profileUrl)) || null;
  }

  async function waitForPhotosSection(timeoutMs) {
    const started = Date.now();
    while (Date.now() - started < timeoutMs) {
      const main = Array.from(document.querySelectorAll('[role="main"]')).find(isVisible);
      const heading = Array.from(document.querySelectorAll('h1, h2, [role="heading"]'))
        .find((node) => isVisible(node) && /^photos$/i.test(cleanText(node.textContent)));
      if (main && (isPhotosSectionUrl(location.href) || heading)) {
        await helpers.delay(700);
        return true;
      }
      await helpers.delay(250);
    }
    return false;
  }

  function isPhotosSectionUrl(value, profileUrl = "") {
    try {
      const url = new URL(String(value || ""), location.origin);
      if (!/(^|\.)facebook\.com$/i.test(url.hostname)) return false;
      if (url.pathname === "/profile.php") {
        const sameId = !profileUrl || profileKey(url.href) === profileKey(profileUrl);
        return sameId && /^(?:photos|photos_by|photos_of|photos_albums)$/.test(
          (url.searchParams.get("sk") || "").toLowerCase()
        );
      }
      const parts = url.pathname.split("/").filter(Boolean).map((part) => part.toLowerCase());
      const hasPhotosSection = /^(?:photos|photos_by|photos_of|photos_albums)$/.test(
        parts[parts.length - 1] || ""
      );
      if (!hasPhotosSection || /photo\.php$/i.test(url.pathname)) return false;
      return !profileUrl || profileKey(url.href) === profileKey(profileUrl);
    } catch (_error) {
      return false;
    }
  }

  function normalizePhotoUrl(value) {
    try {
      const url = new URL(String(value || ""), location.origin);
      if (!/(^|\.)facebook\.com$/i.test(url.hostname)) return "";
      url.protocol = "https:";
      url.hostname = "www.facebook.com";
      url.hash = "";
      const keep = new Set(["fbid", "id", "set"]);
      for (const key of [...url.searchParams.keys()]) {
        if (!keep.has(key)) url.searchParams.delete(key);
      }
      return url.toString().replace(/\/$/, "");
    } catch (_error) {
      return "";
    }
  }

  function photoKey(value) {
    try {
      const url = new URL(normalizePhotoUrl(value));
      const id = url.searchParams.get("fbid")
        || url.pathname.match(/\/photos\/(?:[^/]+\/)?([^/?#]+)/)?.[1];
      return id ? `photo:${id}` : `photo:${url.pathname}?${url.searchParams}`;
    } catch (_error) {
      return "";
    }
  }

  function isUsefulPhotoText(value) {
    const text = cleanText(value);
    return Boolean(text
      && !/^no photo description available$/i.test(text)
      && !/^(?:profile|cover) photo$/i.test(text));
  }

  async function collectConnections(profileUrl, type, requested) {
    if (requested < 1 || !await navigateToConnectionSection(profileUrl, type)) return [];
    const results = [];
    const seen = new Set();
    let idle = 0;

    window.scrollTo({ top: 0, behavior: "instant" });
    await helpers.delay(800);
    for (let scroll = 0; scroll < 35 && results.length < requested; scroll += 1) {
      const root = Array.from(document.querySelectorAll('[role="main"]')).find(isVisible);
      if (!root) break;
      const before = seen.size;

      for (const anchor of root.querySelectorAll('a[href]')) {
        if (!isVisible(anchor) || !isProfileUrl(anchor.href)) continue;
        const url = normalizeProfileUrl(anchor.href);
        if (!url || sameProfile(url, profileUrl) || seen.has(url)) continue;

        const card = anchor.closest('[role="listitem"], [role="article"]')
          || anchor.parentElement?.parentElement
          || anchor;
        const name = cleanText(
          anchor.getAttribute("aria-label")
          || anchor.querySelector("strong, span")?.textContent
          || anchor.textContent
          || card.querySelector('a[role="link"] strong, strong, h3, h4')?.textContent
          || ""
        );
        if (!isUsablePersonName(name)) continue;

        const image = Array.from(card.querySelectorAll("img")).find((node) => {
          const rect = node.getBoundingClientRect();
          return isVisible(node) && rect.width >= 36 && rect.height >= 36;
        });
        seen.add(url);
        results.push({
          username: profileSlug(url),
          display_name: name,
          name,
          url,
          profile_url: url,
          avatar_url: cleanAssetUrl(image?.currentSrc || image?.src || ""),
          relationship_type: type,
          source: "facebook"
        });
        if (results.length >= requested) break;
      }

      idle = seen.size === before ? idle + 1 : 0;
      if (results.length >= requested || idle >= 6) break;
      scrollRoot(root, 2200);
      await helpers.delay(1000);
    }

    await returnToProfile(profileUrl);
    return results;
  }

  async function navigateToConnectionSection(profileUrl, type) {
    if (!await returnToProfile(profileUrl)) return false;
    const wanted = type.toLowerCase();

    const findLink = () => Array.from(document.querySelectorAll('a[href]')).find((anchor) => {
      if (!isVisible(anchor)) return false;
      const section = connectionSection(anchor.href);
      const text = cleanText(anchor.textContent).toLowerCase();
      return section === wanted || new RegExp(`^${wanted}(?:\\s|$)`, "i").test(text);
    });

    let link = findLink();
    if (!link && wanted !== "friends") {
      const friendsLink = Array.from(document.querySelectorAll('a[href]')).find((anchor) => {
        return isVisible(anchor) && connectionSection(anchor.href) === "friends";
      });
      if (friendsLink) {
        try { friendsLink.click(); } catch (_error) { /* Continue with direct candidates. */ }
        await waitForConnectionSection("friends", 9000);
        link = findLink();
      }
    }

    if (!link) {
      const candidates = connectionCandidates(profileUrl, wanted);
      link = Array.from(document.querySelectorAll('a[href]')).find((anchor) => {
        return isVisible(anchor) && candidates.some((target) => sameConnectionRoute(anchor.href, target));
      }) || null;
    }

    if (!link) return false;
    try {
      link.scrollIntoView({ block: "center", behavior: "instant" });
      await helpers.delay(250);
      link.click();
    } catch (_error) {
      return false;
    }
    return waitForConnectionSection(wanted, 12000);
  }

  function connectionCandidates(profileUrl, type) {
    try {
      const url = new URL(profileUrl);
      if (url.pathname === "/profile.php" && url.searchParams.get("id")) {
        const id = encodeURIComponent(url.searchParams.get("id"));
        return [
          `https://www.facebook.com/profile.php?id=${id}&sk=${type}`,
          `https://www.facebook.com/profile.php?sk=${type}&id=${id}`
        ];
      }
      const base = profileUrl.replace(/\/$/, "");
      return [`${base}/${type}`, `${base}/friends/${type}`];
    } catch (_error) {
      return [];
    }
  }

  function sameConnectionRoute(left, right) {
    return profileKey(left) === profileKey(right)
      && connectionSection(left) === connectionSection(right);
  }

  async function waitForConnectionSection(type, timeoutMs) {
    const started = Date.now();
    while (Date.now() - started < timeoutMs) {
      if (connectionSection(location.href) === type && document.querySelector('[role="main"]')) {
        await helpers.delay(600);
        return true;
      }
      const heading = Array.from(document.querySelectorAll('h1, h2, [role="heading"]'))
        .find((node) => isVisible(node) && cleanText(node.textContent).toLowerCase() === type);
      if (heading) {
        await helpers.delay(600);
        return true;
      }
      await helpers.delay(250);
    }
    return false;
  }

  async function returnToProfile(profileUrl) {
    const dialog = Array.from(document.querySelectorAll('div[role="dialog"]')).filter(isVisible).pop();
    if (dialog) {
      const close = Array.from(dialog.querySelectorAll('[aria-label="Close"], [aria-label*="close" i]'))
        .find(isVisible);
      if (close) {
        try { close.click(); } catch (_error) { /* Continue. */ }
        await helpers.delay(600);
      }
    }

    if (sameProfile(location.href, profileUrl) && centerFeedRoot()) return true;

    const profileLink = Array.from(document.querySelectorAll('a[href]')).find((anchor) => {
      return isVisible(anchor) && sameProfile(anchor.href, profileUrl);
    });
    if (profileLink) {
      try { profileLink.click(); } catch (_error) { /* Try browser history. */ }
      const clickedAt = Date.now();
      while (Date.now() - clickedAt < 9000) {
        if (sameProfile(location.href, profileUrl) && centerFeedRoot()) {
          await helpers.delay(700);
          return true;
        }
        await helpers.delay(250);
      }
    }

    history.back();
    const started = Date.now();
    while (Date.now() - started < 11000) {
      if (sameProfile(location.href, profileUrl) && centerFeedRoot()) {
        await helpers.delay(700);
        return true;
      }
      await helpers.delay(250);
    }
    return false;
  }

  function centerFeedRoot() {
    const main = Array.from(document.querySelectorAll('[role="main"]')).find(isVisible);
    if (!main) return null;
    return Array.from(main.querySelectorAll('[role="feed"]')).find(isVisible)
      || main.querySelector('[data-pagelet^="ProfileTimeline"]')
      || main;
  }

  function postCards(root) {
    const candidates = Array.from(root.querySelectorAll('[role="article"], [data-pagelet^="FeedUnit_"]'))
      .filter(isVisible)
      .filter((node) => !node.parentElement?.closest('[role="article"]'));
    return candidates.filter((node) => {
      if (/^comment by/i.test(cleanText(node.getAttribute("aria-label")))) return false;
      return Boolean(node.querySelector(`${POST_LINK_SELECTORS}, ${MESSAGE_SELECTORS}, video, ${MEDIA_IMAGE_SELECTORS}`));
    });
  }

  function extractPostUrl(root) {
    const anchors = Array.from(root.querySelectorAll(POST_LINK_SELECTORS));
    const ranked = anchors.map((anchor) => ({
      anchor,
      url: normalizePostUrl(anchor.getAttribute("href") || ""),
      score: postLinkScore(anchor, root)
    })).filter((entry) => entry.url).sort((a, b) => b.score - a.score);
    return ranked[0]?.url || "";
  }

  function postLinkScore(anchor, root) {
    const href = String(anchor.getAttribute("href") || "");
    const label = cleanText(anchor.getAttribute("aria-label") || anchor.textContent).toLowerCase();
    let score = 0;
    if (/\/posts\/|story_fbid=|permalink\.php/.test(href)) score += 100;
    if (/\/reel\/|\/videos\/|\/watch\//.test(href)) score += 80;
    if (/photo\.php|\/photos\//.test(href)) score += 50;
    if (/\b(?:ago|today|yesterday|\d+[smhdwy])\b/.test(label)) score += 40;
    if (/comment|like|share|react|play|enlarge/.test(label)) score -= 100;
    const ownerArticle = anchor.closest('[role="article"]');
    if (root.matches?.('[role="article"]') && ownerArticle && ownerArticle !== root) score -= 70;
    return score;
  }

  function extractAuthor(root) {
    const node = root.querySelector('[data-ad-rendering-role="profile_name"]')
      || Array.from(root.querySelectorAll('h2 a[href], h3 a[href], strong a[href]'))
        .find((anchor) => isProfileUrl(anchor.href));
    return cleanText(node?.textContent || node?.getAttribute?.("aria-label"));
  }

  function extractCaption(root) {
    const parts = [];
    for (const node of root.querySelectorAll(MESSAGE_SELECTORS)) {
      const ownerArticle = node.closest('[role="article"]');
      if (root.matches?.('[role="article"]') && ownerArticle && ownerArticle !== root) continue;
      const text = cleanContent(node.textContent);
      if (text && !parts.includes(text)) parts.push(text);
    }
    return parts.join("\n");
  }

  function extractAttachmentText(root) {
    const title = cleanContent(root.querySelector('[data-ad-rendering-role="title"]')?.textContent || "");
    const description = cleanContent(root.querySelector('[data-ad-rendering-role="description"]')?.textContent || "");
    return { title, description };
  }

  function extractSharedContent(root) {
    const nested = Array.from(root.querySelectorAll('[role="article"]')).find((node) => node !== root && isVisible(node));
    const raw = cleanText(root.textContent).toLowerCase();
    return {
      isShared: Boolean(nested || /\bshared (?:a|an|the|.*?'s) (?:post|photo|video|reel)|\breposted\b/i.test(raw)),
      author: nested ? extractAuthor(nested) : "",
      text: nested ? extractCaption(nested) || extractAttachmentText(nested).description : ""
    };
  }

  async function extractMedia(root) {
    const images = [];
    for (const image of root.querySelectorAll(MEDIA_IMAGE_SELECTORS)) {
      if (!isVisible(image)) continue;
      const rect = image.getBoundingClientRect();
      if (rect.width < 160 || rect.height < 120) continue;
      const url = absoluteUrl(image.currentSrc || image.getAttribute("src") || "");
      if (!isUsableMediaUrl(url)) continue;
      images.push(url);
    }

    let videoUrl = "";
    let thumbnail = "";
    const video = Array.from(root.querySelectorAll("video")).find(isVisible);
    if (video) {
      const source = video.currentSrc || video.getAttribute("src") || "";
      if (/^https?:/i.test(source)) videoUrl = source;
      thumbnail = absoluteUrl(video.poster || "") || images[0] || await captureVideoFrame(video);
    }

    const attachments = unique(Array.from(root.querySelectorAll('a[href]'))
      .map((anchor) => absoluteUrl(anchor.getAttribute("href") || ""))
      .filter((url) => /^https?:/i.test(url) && !/facebook\.com|fbcdn\.net/i.test(url)));

    return {
      images: unique(thumbnail ? [thumbnail, ...images] : images),
      thumbnail,
      videoUrl,
      attachments
    };
  }

  async function captureVideoFrame(video) {
    try {
      if (video.readyState < 2 || !video.videoWidth || !video.videoHeight) return "";
      const width = Math.min(480, video.videoWidth);
      const height = Math.max(1, Math.round(width * video.videoHeight / video.videoWidth));
      const canvas = document.createElement("canvas");
      canvas.width = width;
      canvas.height = height;
      canvas.getContext("2d").drawImage(video, 0, 0, width, height);
      return canvas.toDataURL("image/jpeg", 0.62);
    } catch (_error) {
      return "";
    }
  }

  function detectPostType(root, url, media, shared) {
    if (shared.isShared) return "repost";
    if (/\/reel\//.test(url)) return "reel";
    if (/\/watch\/|\/videos\//.test(url) || root.querySelector("video")) return "video";
    if (/photo\.php|\/photos\//.test(url) || media.images.length) return "photo";
    if (media.attachments.length) return "link";
    return "text";
  }

  function extractCounts(root) {
    const values = Array.from(root.querySelectorAll('[aria-label], [role="button"], a, span'))
      .filter(isVisible)
      .map((node) => `${node.getAttribute("aria-label") || ""} ${node.textContent || ""}`);
    const raw = values.join(" ");
    return {
      likes: countMatch(raw, /([\d.,]+\s*[KMB]?)\s*(?:reactions?|likes?)/i),
      comments: countMatch(raw, /([\d.,]+\s*[KMB]?)\s*comments?/i),
      shares: countMatch(raw, /([\d.,]+\s*[KMB]?)\s*shares?/i),
      views: countMatch(raw, /([\d.,]+\s*[KMB]?)\s*views?/i)
    };
  }

  function extractPostDate(root) {
    const candidates = [];
    for (const node of root.querySelectorAll(`time, abbr[title], ${POST_LINK_SELECTORS}`)) {
      candidates.push(
        node.getAttribute("datetime"),
        node.getAttribute("title"),
        node.getAttribute("aria-label"),
        node.textContent
      );
    }
    return candidates.map(cleanText).find((value) => {
      return value && /(?:ago|today|yesterday|\d+[smhdwy]|\b\d{1,2}\s+[A-Za-z]{3}|[A-Za-z]{3}\s+\d{1,2})/i.test(value);
    }) || "";
  }

  function expandVisibleText(root) {
    let clicked = 0;
    for (const node of root.querySelectorAll('[role="button"], span[role="button"]')) {
      const text = cleanText(node.textContent);
      if (!isVisible(node) || !/^(?:see more|show more)$/i.test(text)) continue;
      if (node.closest('[aria-label^="Comment by" i], [data-commentid]')) continue;
      try { node.click(); clicked += 1; } catch (_error) { /* Detached. */ }
      if (clicked >= 20) break;
    }
  }

  function findRenderedPostLink(target) {
    return Array.from(document.querySelectorAll(POST_LINK_SELECTORS)).find((anchor) => {
      return isVisible(anchor) && routeMatchesPost(anchor.href, target);
    }) || null;
  }

  function postSignature(root) {
    if (!root) return "";
    const url = extractPostUrl(root);
    const caption = extractCaption(root);
    const media = Array.from(root.querySelectorAll("img, video")).filter(isVisible).length;
    return url || caption || media ? `${postKey(url)}|${caption.slice(0, 180)}|${media}` : "";
  }

  async function waitForStableValue(reader, timeoutMs, checksRequired = 3) {
    const started = Date.now();
    let previous = "";
    let checks = 0;
    while (Date.now() - started < timeoutMs) {
      const value = cleanText(reader());
      if (value && value === previous) checks += 1;
      else {
        previous = value;
        checks = value ? 1 : 0;
      }
      if (checks >= checksRequired) {
        await helpers.delay(350);
        return value;
      }
      await helpers.delay(300);
    }
    return "";
  }

  function profileBaseUrl(value, username) {
    try {
      const url = new URL(String(value || ""), location.origin);
      if (url.pathname === "/profile.php" && url.searchParams.get("id")) {
        return `https://www.facebook.com/profile.php?id=${encodeURIComponent(url.searchParams.get("id"))}`;
      }
      const slug = url.pathname.split("/").filter(Boolean)[0] || username;
      return `https://www.facebook.com/${encodeURIComponent(String(slug || "").replace(/^@/, ""))}`;
    } catch (_error) {
      return `https://www.facebook.com/${encodeURIComponent(String(username || "").replace(/^@/, ""))}`;
    }
  }

  function usernameFromUrl() {
    try {
      const url = new URL(location.href);
      return url.pathname === "/profile.php"
        ? url.searchParams.get("id") || ""
        : decodeURIComponent(url.pathname.split("/").filter(Boolean)[0] || "");
    } catch (_error) {
      return "";
    }
  }

  function collectProfile(username, profileUrl) {
    const main = document.querySelector('[role="main"]') || document;
    const images = Array.from(document.images).map((image) => {
      const rect = image.getBoundingClientRect();
      return {
        src: cleanAssetUrl(image.currentSrc || image.src || image.getAttribute("src")),
        width: rect.width || image.naturalWidth || image.width || 0,
        height: rect.height || image.naturalHeight || image.height || 0,
        top: rect.top
      };
    }).filter((image) => image.src && !image.src.includes("static.xx.fbcdn.net"));

    const avatar = firstAsset([
      ['meta[property="og:image"]', "content"],
      ['meta[name="twitter:image"]', "content"],
      ['div[role="main"] a[href*="/photo"] img', "src"],
      ['div[role="main"] image', "href"],
      ['svg image', "href"],
      ['img[alt*="profile" i]', "src"]
    ]) || images.find((image) => image.width >= 80 && image.width <= 260
      && image.height >= 80 && image.height <= 260)?.src || "";

    const cover = firstAsset([
      ['img[data-imgperflogname="profileCoverPhoto"]', "src"],
      ['div[data-pagelet*="Cover"] img', "src"],
      ['div[aria-label*="Cover photo" i] img', "src"],
      ['img[alt*="cover photo" i]', "src"]
    ]) || firstBackground([
      'div[data-pagelet*="Cover"]',
      'div[aria-label*="Cover photo" i]',
      'div[style*="background-image"]'
    ]) || images.find((image) => image.width > 320 && image.height > 90
      && image.top < 700 && image.src !== avatar)?.src || "";

    const title = cleanText(
      document.querySelector('meta[property="og:title"]')?.content
      || main.querySelector("h1")?.textContent
      || main.querySelector("h2")?.textContent
      || main.querySelector("strong")?.textContent
      || document.title.replace(/\s*\|\s*Facebook.*$/i, "")
      || username
    );
    const description = cleanContent(
      document.querySelector('meta[property="og:description"]')?.content
      || document.querySelector('meta[name="description"]')?.content
      || main.querySelector('[data-ad-rendering-role="profile_intro_card"]')?.textContent
      || ""
    );
    const body = cleanText(main.textContent || document.body?.innerText || "");

    return {
      username,
      display_name: title,
      bio: description,
      description,
      url: profileUrl,
      profile_url: profileUrl,
      avatar_url: avatar,
      cover_url: cover,
      followers_count: countMatch(body, /([\d.,]+\s*[KMB]?)\s*followers?/i),
      following_count: countMatch(body, /([\d.,]+\s*[KMB]?)\s*following/i),
      friends_count: countMatch(body, /([\d.,]+\s*[KMB]?)\s*friends?/i),
      members_count: countMatch(body, /([\d.,]+\s*[KMB]?)\s*members?/i)
    };
  }

  async function mergePublicPluginProfile(profile, profileUrl) {
    try {
      const raw = await fetchFacebookPlugin(profileUrl);
      if (!raw) return;
      const plugin = {
        display_name: jsonStringValue(raw, "pageName"),
        description: jsonStringValue(raw, "pageDescription"),
        avatar_url: jsonStringValue(raw, "profilePicURL"),
        cover_url: jsonStringValue(raw, "coverPhotoURL")
      };
      if (!profile.display_name && plugin.display_name) profile.display_name = plugin.display_name;
      if (!profile.bio && plugin.description) profile.bio = plugin.description;
      if (!profile.description && plugin.description) profile.description = plugin.description;
      if (!profile.avatar_url && plugin.avatar_url) profile.avatar_url = plugin.avatar_url;
      if (!profile.cover_url && plugin.cover_url) profile.cover_url = plugin.cover_url;
    } catch (_error) {
      // The plugin is only a fallback; authenticated DOM extraction remains primary.
    }
  }

  async function fetchFacebookPlugin(profileUrl) {
    const params = new URLSearchParams({
      href: profileUrl,
      tabs: "timeline",
      width: "500",
      height: "800",
      small_header: "false",
      adapt_container_width: "true",
      hide_cover: "false",
      show_facepile: "false",
      locale: "en_US"
    });
    const response = await fetch(`https://www.facebook.com/plugins/page.php?${params}`, {
      credentials: "include",
      headers: {
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9"
      }
    });
    return response.ok ? response.text() : "";
  }

  function jsonStringValue(raw, key) {
    const escapedKey = String(key).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const match = String(raw || "").match(
      new RegExp(`"${escapedKey}"\\s*:\\s*"((?:\\\\.|[^"\\\\])*)"`)
    );
    if (!match) return "";
    try { return JSON.parse(`"${match[1]}"`); }
    catch (_error) { return match[1]; }
  }

  function firstAsset(entries) {
    for (const [selector, attribute] of entries) {
      const node = document.querySelector(selector);
      const raw = node?.getAttribute(attribute)
        || (attribute === "href" ? node?.getAttribute("xlink:href") : "")
        || node?.[attribute]
        || "";
      const url = cleanAssetUrl(raw);
      if (url) return url;
    }
    return "";
  }

  function firstBackground(selectors) {
    for (const selector of selectors) {
      const node = document.querySelector(selector);
      if (!node) continue;
      const url = cleanAssetUrl(getComputedStyle(node).backgroundImage || node.style?.backgroundImage);
      if (url) return url;
    }
    return "";
  }

  function cleanAssetUrl(value) {
    const match = String(value || "").match(/url\(["']?([^"')]+)["']?\)/);
    const raw = cleanText(match ? match[1] : value);
    if (!raw || raw.startsWith("data:") || /^(?:none|initial|inherit|unset)$/i.test(raw)) return "";
    return absoluteUrl(raw);
  }

  function buildResult(username, profileUrl, profile, state, job) {
    const resultProfile = {
      ...profile,
      friends_count: Math.max(Number(profile.friends_count) || 0, state.friends.length),
      followers_count: Math.max(Number(profile.followers_count) || 0, state.followers.length),
      following_count: Math.max(Number(profile.following_count) || 0, state.following.length)
    };
    return {
      platform: "facebook",
      username,
      url: profileUrl,
      profile: resultProfile,
      posts: state.posts,
      videos: [],
      shorts: [],
      images: mergeImages(state.photos, collectImages(state.posts))
        .slice(0, helpers.limit(job, "max_images", 25, 100)),
      friends: state.friends,
      followers: state.followers,
      following: state.following
    };
  }

  function setPartialResult(username, profileUrl, profile, state, job) {
    window.__orionLastPartialResult = buildResult(username, profileUrl, profile, {
      posts: [...state.posts],
      photos: [...state.photos],
      friends: [...state.friends],
      followers: [...state.followers],
      following: [...state.following]
    }, job);
  }

  function collectImages(posts) {
    const seen = new Set();
    const output = [];
    for (const post of posts) {
      for (const url of post.image_urls || []) {
        if (!url || seen.has(url)) continue;
        seen.add(url);
        output.push({
          image_url: url,
          thumbnail: url,
          source_url: post.url,
          title: post.title || post.caption || "Facebook media",
          source: "facebook"
        });
      }
    }
    return output;
  }

  function mergeImages(...groups) {
    const output = [];
    const seen = new Set();
    for (const item of groups.flat()) {
      const keys = [item?.id, item?.image_url, item?.source_url].filter(Boolean);
      if (!keys.length || keys.some((key) => seen.has(key))) continue;
      keys.forEach((key) => seen.add(key));
      output.push(item);
    }
    return output;
  }

  function normalizePostUrl(value) {
    try {
      const url = new URL(String(value || ""), location.origin);
      if (!/(^|\.)facebook\.com$/i.test(url.hostname)) return "";
      url.protocol = "https:";
      url.hostname = "www.facebook.com";
      url.hash = "";
      const keep = new Set(["story_fbid", "id", "fbid", "set", "v"]);
      for (const key of [...url.searchParams.keys()]) {
        if (!keep.has(key)) url.searchParams.delete(key);
      }
      return url.toString().replace(/\/$/, "");
    } catch (_error) {
      return "";
    }
  }

  function postKey(value) {
    try {
      const url = new URL(normalizePostUrl(value));
      const path = url.pathname.replace(/\/$/, "");
      const id = path.match(/\/(?:posts|reel|videos)\/([^/?#]+)/)?.[1]
        || url.searchParams.get("story_fbid")
        || url.searchParams.get("fbid")
        || url.searchParams.get("v");
      if (id) return `post:${id}`;
      return `${path}?${url.searchParams.toString()}`.toLowerCase();
    } catch (_error) {
      return "";
    }
  }

  function routeMatchesPost(left, right) {
    const leftKey = postKey(left);
    const rightKey = postKey(right);
    return Boolean(leftKey && rightKey && leftKey === rightKey);
  }

  function sameProfile(left, right) {
    return profileKey(left) && profileKey(left) === profileKey(right)
      && !postKey(left).startsWith("post:")
      && !connectionSection(left)
      && !isPhotosSectionUrl(left);
  }

  function profileKey(value) {
    try {
      const url = new URL(String(value || ""), location.origin);
      if (url.pathname === "/profile.php") return `id:${url.searchParams.get("id") || ""}`;
      return `slug:${decodeURIComponent(url.pathname.split("/").filter(Boolean)[0] || "").toLowerCase()}`;
    } catch (_error) {
      return "";
    }
  }

  function normalizeProfileUrl(value) {
    try {
      const url = new URL(String(value || ""), location.origin);
      if (!/(^|\.)facebook\.com$/i.test(url.hostname)) return "";
      if (url.pathname === "/profile.php" && url.searchParams.get("id")) {
        return `https://www.facebook.com/profile.php?id=${encodeURIComponent(url.searchParams.get("id"))}`;
      }
      const slug = decodeURIComponent(url.pathname.split("/").filter(Boolean)[0] || "");
      if (!slug || CONNECTION_BLOCKLIST.has(slug.toLowerCase())) return "";
      return `https://www.facebook.com/${encodeURIComponent(slug)}`;
    } catch (_error) {
      return "";
    }
  }

  function isProfileUrl(value) {
    return Boolean(normalizeProfileUrl(value));
  }

  function profileSlug(value) {
    const key = profileKey(value);
    return key.replace(/^(?:slug|id):/, "");
  }

  function connectionSection(value) {
    try {
      const url = new URL(String(value || ""), location.origin);
      const sk = (url.searchParams.get("sk") || "").toLowerCase();
      if (["friends", "followers", "following"].includes(sk)) return sk;
      const parts = url.pathname.split("/").filter(Boolean).map((part) => part.toLowerCase());
      return ["friends", "followers", "following"].find((type) => parts.includes(type)) || "";
    } catch (_error) {
      return "";
    }
  }

  function requestedItemId(job) {
    const value = String(job?.cursor?.hash_id || job?.hash_id || "").trim();
    return value.startsWith("post:") ? value : postKey(value);
  }

  function existingPostKeys(job) {
    const values = Array.isArray(job?.cursor?.existing_post_urls) ? job.cursor.existing_post_urls : [];
    return new Set(values.flatMap((value) => [String(value || ""), postKey(value)]).filter(Boolean));
  }

  function connectionLimit(job, type) {
    const key = type === "friends" ? "max_friends"
      : type === "following" ? "max_following"
      : "max_followers";
    return helpers.limit(job, key, 100, 500);
  }

  function countMatch(text, pattern) {
    const match = String(text || "").match(pattern);
    return match ? count(match[1]) : 0;
  }

  function count(value) {
    return helpers.count(cleanText(value)) || 0;
  }

  function cleanContent(value) {
    return unique(cleanText(value).split("\n")
      .map((line) => cleanText(line))
      .filter((line) => !isContentNoise(line))).join("\n");
  }

  function isContentNoise(value) {
    const text = cleanText(value).toLowerCase();
    if (!text) return true;
    if (/^(?:like|comment|share|send|reply|follow|see more|show more|public)$/i.test(text)) return true;
    if (/actions for this post|write a comment/.test(text)) return true;
    if (/^[\d.,]+\s*[kmb]?\s*(?:views?|shares?|comments?|reactions?|likes?)$/i.test(text)) return true;
    if (/^(?:\d+\s*)?(?:s|m|h|d|w|y)$/i.test(text)) return true;
    return false;
  }

  function isCommentNoise(value) {
    const text = cleanText(value).toLowerCase();
    return !text || /^(?:like|reply|edited|author|see more|follow)$/i.test(text)
      || /^\d+\s*(?:likes?|replies?)$/i.test(text)
      || /write a comment/.test(text);
  }

  function isUsablePersonName(value) {
    const text = cleanText(value);
    return Boolean(text && text.length <= 120
      && !/^(?:friends?|followers?|following|see all|add friend|message|follow|facebook)$/i.test(text)
      && !/^\d[\d.,]*\s*(?:friends?|followers?)$/i.test(text));
  }

  function absoluteUrl(value) {
    try { return new URL(String(value || ""), location.origin).toString(); }
    catch (_error) { return ""; }
  }

  function isUsableMediaUrl(value) {
    return /^(?:https?:|data:image\/)/i.test(String(value || ""))
      && !/static\.xx\.fbcdn\.net|emoji|rsrc\.php/i.test(String(value || ""));
  }

  function scrollRoot(root, amount) {
    const scrollable = [root, ...root.querySelectorAll("div")].find((node) => {
      if (!isVisible(node) || node.scrollHeight <= node.clientHeight + 50) return false;
      return /auto|scroll|overlay/.test(getComputedStyle(node).overflowY);
    });
    (scrollable || window).scrollBy({ top: amount, behavior: "instant" });
  }

  function scrollCommentArea(root, amount) {
    const dialog = root.closest('div[role="dialog"]');
    scrollRoot(dialog || root, amount);
  }

  function isVisible(node) {
    if (!node?.getBoundingClientRect) return false;
    const rect = node.getBoundingClientRect();
    const style = getComputedStyle(node);
    return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none";
  }

  function cleanText(value) {
    return helpers.cleanText(String(value || ""));
  }

  function unique(values) {
    return [...new Set(values.filter(Boolean))];
  }
})();

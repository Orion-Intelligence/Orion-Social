(function () {
  const helpers = window.OrionScraperHelpers;
  const CHANNEL_ITEM_SELECTORS = [
    "ytd-rich-item-renderer",
    "ytd-grid-video-renderer",
    "ytd-video-renderer",
    "yt-lockup-view-model"
  ].join(",");
  const COMMUNITY_ITEM_SELECTORS = [
    "ytd-backstage-post-thread-renderer",
    "ytd-backstage-post-renderer",
    "ytd-post-renderer",
    "yt-backstage-post-renderer-view-model",
    "yt-post-renderer-view-model",
    "yt-post-view-model",
    "ytd-rich-item-renderer"
  ].join(",");
  let channelTabEndpoints = new Map();

  window.OrionScrapers = window.OrionScrapers || {};
  window.OrionScrapers.youtube = {
    selectors: [
      'meta[property="og:title"]',
      "yt-page-header-view-model",
      "ytd-c4-tabbed-header-renderer",
      "ytd-rich-grid-renderer"
    ],

    async run(job) {
      const username = job.username || usernameFromUrl();
      const command = helpers.command(job);
      const channelUrl = channelBaseUrl(username);
      channelTabEndpoints = collectChannelTabEndpoints();
      const profile = collectProfile(username, channelUrl);
      let posts = [];
      let videos = [];
      let shorts = [];

      if (["profile", "profile_info", "comments"].includes(command)) {
        const bundleLimit = Math.max(1, Math.min(20, helpers.limit(job, "max_posts", 20, 100)));
        const bundleJob = {
          ...job,
          social_data_type: "profile_info",
          skip_details: true,
          limits: {
            ...(job.limits || {}),
            max_posts: bundleLimit,
            max_videos: bundleLimit,
            max_shorts: bundleLimit,
            max_comments: Math.max(1, helpers.limit(job, "max_comments", 25, 100)),
            comment_offset: 0
          }
        };
        const bundle = { posts, videos, shorts };
        const updatePartial = () => setPartialBundle(
          username, channelUrl, profile, bundle.posts, bundle.videos, bundle.shorts, job
        );
        await collectBundleLinks(bundle, bundleJob, channelUrl, updatePartial);
        await enrichBundleItems(bundle, bundleJob, channelUrl, updatePartial);
        ({ posts, videos, shorts } = bundle);
      } else if (command === "posts") {
        posts = await collectCommunityPosts(job, channelUrl, command);
      } else if (command === "videos") {
        videos = await collectChannelVideos(job, channelUrl, false);
      } else if (command === "shorts") {
        shorts = await collectChannelVideos(job, channelUrl, true);
      } else if (command === "images") {
        const imageLimit = helpers.limit(job, "max_images", 25, 100);
        posts = await collectCommunityPosts(job, channelUrl, command);
        if (collectImages(posts).length < imageLimit) {
          videos = await collectChannelVideos(job, channelUrl, false, true);
        }
        if (collectImages([...posts, ...videos]).length < imageLimit) {
          shorts = await collectChannelVideos(job, channelUrl, true, true);
        }
      }

      const allItems = [...posts, ...videos, ...shorts];
      const result = {
        platform: "youtube",
        username,
        url: channelUrl,
        profile,
        posts,
        videos,
        shorts,
        images: collectImages(allItems).slice(0, helpers.limit(job, "max_images", 25, 100)),
        followers: [],
        following: []
      };
      window.__orionLastPartialResult = null;
      return result;
    }
  };

  async function collectBundleLinks(bundle, job, channelUrl, updatePartial) {
    bundle.posts = await collectCommunityPosts(job, channelUrl, "posts");
    updatePartial();
    bundle.videos = await collectChannelVideos(job, channelUrl, false);
    updatePartial();
    bundle.shorts = await collectChannelVideos(job, channelUrl, true);
    updatePartial();
  }

  async function enrichBundleItems(bundle, job, channelUrl, updatePartial) {
    const detailJob = { ...job, social_data_type: "comments", skip_details: false };
    await goToSection(channelUrl, "posts", "community");
    for (const post of bundle.posts) {
      const comments = await collectCommentsForItem(post, channelUrl, "posts", detailJob, true);
      setItemComments(post, comments);
      updatePartial();
    }
    await goToSection(channelUrl, "videos");
    for (const video of bundle.videos) {
      await enrichVideoItem(video, channelUrl, "videos", detailJob, true, false);
      updatePartial();
    }
    await goToSection(channelUrl, "shorts");
    for (const short of bundle.shorts) {
      await enrichShortItem(short, channelUrl, detailJob, true);
      updatePartial();
    }
  }

  function setItemComments(item, comments) {
    item.comment_details = comments;
    item.comment_items = comments.map((comment) => comment.text);
    item.collected_comments_count = comments.length;
    const displayedCount = currentItemMatches(item) ? displayedCommentCount() : 0;
    item.comments_count = Math.max(
      Number(item.comments_count) || 0,
      displayedCount,
      comments.length
    );
  }

  function displayedCommentCount() {
    const values = [];
    const countSelectors = [
      "ytd-comments-header-renderer #count",
      "ytd-comments-header-renderer #title",
      "ytd-comments #count",
      "ytd-reel-player-overlay-renderer #comments-button button",
      "#comments-button button"
    ];
    for (const node of document.querySelectorAll(countSelectors.join(","))) {
      values.push(node.getAttribute("aria-label") || "", node.textContent || "");
    }
    for (const node of document.querySelectorAll(
      'button[aria-label*="comment" i], [role="button"][aria-label*="comment" i]'
    )) {
      values.push(node.getAttribute("aria-label") || "");
    }
    return values.reduce((maximum, value) => {
      return Math.max(maximum, helpers.count(helpers.cleanText(value)) || 0);
    }, 0);
  }

  function currentItemMatches(item) {
    const itemId = String(item?.id || "");
    const currentVideoId = videoId(location.href);
    if (itemId && currentVideoId && itemId === currentVideoId) return true;
    return samePath(location.href, item?.url || "");
  }

  function usernameFromUrl() {
    const match = location.pathname.match(/^\/@([^/?#]+)/);
    return match ? decodeURIComponent(match[1]) : "";
  }

  function channelBaseUrl(username) {
    const match = location.pathname.match(/^\/(?:@[^/?#]+|channel\/[^/?#]+|c\/[^/?#]+|user\/[^/?#]+)/);
    if (match) return `${location.origin}${match[0]}`;
    return `https://www.youtube.com/@${encodeURIComponent(String(username || "").replace(/^@/, ""))}`;
  }

  function collectProfile(username, channelUrl) {
    const bodyText = document.body?.innerText || "";
    const subscribersText = bodyText.match(/[\d.,]+\s*[KMB]?\s+subscribers/i)?.[0] || "";
    const avatar = firstUrl([
      ['meta[property="og:image"]', "content"],
      ['link[itemprop="thumbnailUrl"]', "href"],
      ["#avatar img", "src"],
      ["yt-decorated-avatar-view-model img", "src"],
      ["yt-avatar-shape img", "src"]
    ]);
    const cover = firstUrl([
      ["ytd-c4-tabbed-header-renderer #banner img", "src"],
      ["#page-header-banner img", "src"],
      ["yt-page-header-view-model img", "src"],
      ["yt-image-banner-view-model img", "src"]
    ]) || backgroundImage("#banner, #page-header-banner");
    const title = document.querySelector('meta[property="og:title"]')?.content
      || document.title.replace(/\s*-\s*YouTube\s*$/i, "")
      || username;
    const description = document.querySelector('meta[name="description"]')?.content || "";
    const subscribers = helpers.count(subscribersText) || 0;
    return {
      username,
      display_name: helpers.cleanText(title),
      bio: helpers.cleanText(description),
      description: helpers.cleanText(description),
      url: channelUrl,
      profile_url: channelUrl,
      avatar_url: avatar,
      cover_url: cover,
      followers_count: subscribers,
      total_followers: subscribers,
      following_count: 0,
      total_following: 0
    };
  }

  async function collectChannelVideos(job, channelUrl, isShorts, imagesOnly = false) {
    const section = isShorts ? "shorts" : "videos";
    const key = isShorts ? "max_shorts" : "max_videos";
    const requested = imagesOnly
      ? helpers.limit(job, "max_images", 25, 100)
      : helpers.limit(job, key, 5, 100);
    const targetId = requestedItemId(job);
    const existing = existingIds(job);
    let skip = existing.size ? 0 : helpers.limit(job, "post_offset", 0, 5000);
    const reached = await goToSection(channelUrl, section);
    if (!reached) return [];

    const items = [];
    const seen = new Set();
    let idle = 0;
    window.scrollTo({ top: 0, behavior: "instant" });
    await helpers.delay(600);
    for (let scroll = 0; scroll < 30 && items.length < requested; scroll += 1) {
      const before = seen.size;
      for (const card of sectionCards(section)) {
        const item = extractVideoCard(card, isShorts);
        if (!item?.id || !item.title || seen.has(item.id)) continue;
        seen.add(item.id);
        if (targetId && item.id !== targetId) continue;
        if (existing.has(item.id) || existing.has(normalizeYoutubeUrl(item.url))) continue;
        if (skip > 0) {
          skip -= 1;
          continue;
        }
        items.push(item);
        if (items.length >= requested || targetId) break;
      }
      idle = seen.size === before ? idle + 1 : 0;
      if (items.length >= requested || targetId && items.length || idle >= 4) break;
      window.scrollBy({ top: 2600, behavior: "instant" });
      await helpers.delay(1200);
    }

    if (!imagesOnly && !job?.skip_details) {
      const loadComments = shouldCollectComments(job, items.length);
      const detailTargets = requestedItemId(job)
        ? items.slice(0, 1)
        : socialDataType(job) === "comments" ? items : items.slice(0, 5);
      for (const item of detailTargets) {
        if (isShorts) {
          await enrichShortItem(item, channelUrl, job, loadComments);
        } else {
          await enrichVideoItem(item, channelUrl, section, job, loadComments, false);
        }
      }
    }
    return items;
  }

  function extractVideoCard(card, isShorts) {
    const anchors = Array.from(card.querySelectorAll('a[href*="/watch"], a[href*="/shorts/"]'));
    const anchor = anchors.find((item) => isShorts
      ? /\/shorts\//.test(item.getAttribute("href") || "")
      : /\/watch\?/.test(item.getAttribute("href") || ""));
    if (!anchor) return null;
    const url = isShorts
      ? cleanYoutubeUrl(anchor.getAttribute("href") || "").split("?")[0]
      : canonicalVideoUrl(anchor.getAttribute("href") || "");
    const id = videoId(url);
    if (!id) return null;
    const title = extractVideoCardTitle(card, anchor, isShorts);
    const thumbnail = bestThumbnail(card, id);
    const lines = Array.from(card.querySelectorAll("#metadata-line span, .yt-content-metadata-view-model-wiz__metadata-row span"))
      .map((node) => helpers.cleanText(node.textContent || ""))
      .filter(Boolean);
    const viewsText = lines.find((line) => /views?/i.test(line)) || "";
    const dateText = lines.find((line) => /\b(?:ago|streamed|premiered)\b/i.test(line)) || "";
    return {
      id,
      hash_id: id,
      title,
      caption: title,
      text: title,
      url,
      post_url: url,
      created_at: dateText,
      author: helpers.cleanText(card.querySelector("#channel-name, ytd-channel-name")?.textContent || ""),
      source: "youtube",
      views_count: helpers.count(viewsText) || 0,
      likes_count: 0,
      comments_count: 0,
      media_type: isShorts ? "short" : "video",
      media_url: thumbnail,
      image_url: thumbnail,
      thumbnail,
      comment_items: [],
      comment_details: []
    };
  }

  async function collectCommunityPosts(job, channelUrl, command) {
    const requested = command === "images"
      ? Math.min(100, helpers.limit(job, "max_images", 25, 100) * 3)
      : helpers.limit(job, "max_posts", 20, 100);
    const targetId = requestedItemId(job);
    const existing = existingIds(job);
    let skip = existing.size ? 0 : helpers.limit(job, "post_offset", 0, 5000);
    const reached = await goToSection(channelUrl, "posts", "community");
    if (!reached) return [];

    const posts = [];
    const seen = new Set();
    let idle = 0;
    window.scrollTo({ top: 0, behavior: "instant" });
    await helpers.delay(600);
    for (let scroll = 0; scroll < 30 && posts.length < requested; scroll += 1) {
      const before = seen.size;
      for (const card of sectionCards("posts")) {
        const post = extractCommunityCard(card);
        if (!post?.id || (!post.text && !post.image_url) || seen.has(post.id)) continue;
        seen.add(post.id);
        if (targetId && post.id !== targetId) continue;
        if (existing.has(post.id) || existing.has(normalizeYoutubeUrl(post.url))) continue;
        if (skip > 0) {
          skip -= 1;
          continue;
        }
        posts.push(post);
        if (posts.length >= requested || targetId) break;
      }
      idle = seen.size === before ? idle + 1 : 0;
      if (posts.length >= requested || targetId && posts.length || idle >= 4) break;
      window.scrollBy({ top: 2600, behavior: "instant" });
      await helpers.delay(1200);
    }

    if (command !== "images" && shouldCollectComments(job, posts.length)) {
      for (const post of requestedCommentTargets(job, posts)) {
        const comments = await collectCommentsForItem(post, channelUrl, "posts", job, true);
        setItemComments(post, comments);
      }
    }
    return posts;
  }

  function extractCommunityCard(card) {
    const link = Array.from(card.querySelectorAll('a[href*="/post/"]'))
      .find((anchor) => /\/post\/[^/?#]+/.test(anchor.getAttribute("href") || ""));
    if (!link) return null;
    const url = cleanYoutubeUrl(link.getAttribute("href") || "");
    const id = url.match(/\/post\/([^/?#]+)/)?.[1] || "";
    const text = extractCommunityText(card);
    const images = helpers.unique(Array.from(card.querySelectorAll("img"))
      .filter((image) => (image.naturalWidth || image.width || 0) > 80 && (image.naturalHeight || image.height || 0) > 80)
      .map((image) => helpers.absoluteUrl(image.currentSrc || image.getAttribute("src") || ""))
      .filter((value) => isHttpUrl(value) && !/yt3\.ggpht\.com\/.*s\d+-c-k-c0x00ffffff-no-rj/i.test(value)), (value) => value);
    for (const node of card.querySelectorAll("[style*='background-image']")) {
      const value = backgroundImageForNode(node);
      if (value && !images.includes(value)) images.push(value);
    }
    const videoThumb = bestThumbnail(card, videoId(card.querySelector('a[href*="/watch"]')?.getAttribute("href") || ""));
    if (videoThumb && !images.includes(videoThumb)) images.push(videoThumb);
    const likesText = helpers.cleanText(card.querySelector("#vote-count-middle, #vote-count-left")?.textContent || "");
    const commentsText = helpers.cleanText(card.querySelector('a[href*="/post/"] #count, #reply-count')?.textContent || "");
    const thumbnail = images[0] || "";
    return {
      id,
      hash_id: id,
      title: text.slice(0, 120) || "YouTube post",
      caption: text,
      text,
      url,
      post_url: url,
      created_at: helpers.cleanText(card.querySelector("#published-time-text a, #published-time-text")?.textContent || ""),
      author: helpers.cleanText(card.querySelector("#author-text, #author-name, #channel-name")?.textContent || ""),
      source: "youtube",
      likes_count: helpers.count(likesText) || 0,
      comments_count: helpers.count(commentsText) || 0,
      media_type: thumbnail ? "image" : "",
      media_url: thumbnail,
      image_url: thumbnail,
      thumbnail,
      image_urls: images,
      comment_items: [],
      comment_details: []
    };
  }

  async function collectCommentsForItem(item, channelUrl, section, job, returnAfter = true) {
    const selectors = [
      "ytd-comment-thread-renderer",
      "ytd-comments",
      "h1.ytd-watch-metadata",
      "ytd-backstage-post-thread-renderer",
      "yt-backstage-post-renderer-view-model",
      "yt-post-renderer-view-model",
      "yt-post-view-model"
    ];
    const opened = section === "posts"
      ? await navigateToCommunityPost(item, channelUrl, selectors)
      : await navigateWithinYoutube(item.url, selectors);
    if (!opened) return [];
    if (!await waitForStableItemContent(item, section)) {
      if (returnAfter) await returnToSection(channelUrl, section);
      return [];
    }
    const offset = helpers.limit(job, "comment_offset", 0, 5000);
    const limit = helpers.limit(job, "max_comments", 10, 100);
    const comments = await collectVisibleComments(offset, limit, section === "posts" ? 3 : 5);
    if (returnAfter) await returnToSection(channelUrl, section);
    return comments;
  }

  async function enrichVideoItem(item, channelUrl, section, job, loadComments, returnAfter = true) {
    const opened = await navigateToWatch(item.id, [
      "h1.ytd-watch-metadata",
      "ytd-video-owner-renderer"
    ]);
    if (!opened) return;
    if (!await waitForStableWatchTitle(item.id)) {
      if (returnAfter) await returnToSection(channelUrl, section);
      return;
    }
    const title = currentPlayerTitle(item.id) || helpers.cleanText(
      document.querySelector("h1.ytd-watch-metadata yt-formatted-string, h1.ytd-watch-metadata, yt-formatted-string.style-scope.ytd-watch-metadata")?.textContent
      || document.querySelector('meta[property="og:title"]')?.content
      || item.title
    );
    const description = helpers.cleanText(
      document.querySelector("ytd-watch-metadata #description-inline-expander, ytd-watch-metadata ytd-text-inline-expander, #description #content")?.textContent
      || document.querySelector('meta[name="description"]')?.content
      || item.text
    );
    const viewsValue = Array.from(document.querySelectorAll('meta[itemprop="interactionCount"], meta[itemprop="userInteractionCount"]'))
      .map((meta) => Number(String(meta.content || "").replace(/\D/g, "")))
      .filter(Boolean)
      .sort((left, right) => right - left)[0]
      || helpers.count(document.querySelector('[aria-label*="views" i]')?.getAttribute("aria-label") || "")
      || helpers.count(document.querySelector("yt-formatted-string#info span")?.textContent || "")
      || item.views_count;
    const likeButton = document.querySelector("like-button-view-model button");
    const likesValue = helpers.count(
      likeButton?.getAttribute("aria-label")
      || likeButton?.querySelector(".ytSpecButtonShapeNextButtonTextContent")?.textContent
      || likeButton?.textContent
      || ""
    ) || item.likes_count;
    const cardThumbnail = /(?:i|img)\.ytimg\.com/i.test(item.thumbnail || "") ? item.thumbnail : "";
    const thumbnail = cardThumbnail || `https://i.ytimg.com/vi/${item.id}/hqdefault.jpg`;
    item.title = title;
    item.caption = title;
    item.text = description || title;
    item.author = helpers.cleanText(
      document.querySelector("ytd-video-owner-renderer #channel-name a")?.textContent || item.author
    );
    item.created_at = document.querySelector('meta[itemprop="datePublished"]')?.content || item.created_at;
    item.views_count = viewsValue || 0;
    item.likes_count = likesValue || 0;
    item.media_url = thumbnail;
    item.image_url = thumbnail;
    item.thumbnail = thumbnail;

    if (loadComments) {
      const offset = helpers.limit(job, "comment_offset", 0, 5000);
      const limit = helpers.limit(job, "max_comments", 10, 100);
      if (section === "shorts" && /^\/shorts\//.test(location.pathname)) await openShortsComments();
      const comments = await collectVisibleComments(offset, limit);
      setItemComments(item, comments);
    }
    if (returnAfter) {
      await returnToSection(channelUrl, section);
    }
  }

  async function enrichShortItem(item, channelUrl, job, loadComments, returnAfter = true) {
    const opened = await navigateWithinYoutube(item.url, [
      "ytd-reel-video-renderer",
      "ytd-reel-player-overlay-renderer",
      "yt-reel-video-renderer"
    ]);
    if (!opened) return;
    const root = await waitForStableShort(item.id);
    if (!root) {
      if (returnAfter) await returnToSection(channelUrl, "shorts");
      return;
    }
    const title = currentPlayerTitle(item.id) || helpers.cleanText(
      root?.querySelector([
        "ytd-reel-player-header-renderer h2",
        "ytd-reel-player-header-renderer #title",
        "yt-shorts-video-title-view-model h2",
        ".ytShortsVideoTitleViewModelShortsVideoTitle",
        "#overlay #title"
      ].join(","))?.textContent
      || item.title
    );
    const viewsValue = helpers.count(
      root?.querySelector('[aria-label*="views" i]')?.getAttribute("aria-label")
      || root?.querySelector('[aria-label*="view" i]')?.textContent
      || ""
    ) || item.views_count;
    const likeButton = root?.querySelector(
      'like-button-view-model button, button[aria-label*="like" i]'
    );
    const likesValue = helpers.count(
      likeButton?.getAttribute("aria-label")
      || likeButton?.textContent
      || ""
    ) || item.likes_count;
    item.title = title || item.title;
    item.caption = title || item.title;
    item.text = title || item.text;
    item.views_count = viewsValue || 0;
    item.likes_count = likesValue || 0;

    if (loadComments) {
      const offset = helpers.limit(job, "comment_offset", 0, 5000);
      const limit = helpers.limit(job, "max_comments", 10, 100);
      await openShortsComments();
      const comments = await collectVisibleComments(offset, limit);
      setItemComments(item, comments);
    }
    if (returnAfter) await returnToSection(channelUrl, "shorts");
  }

  async function collectVisibleComments(offset, limit, idleLimit = 5) {
    const target = offset + limit;
    const comments = [];
    const seen = new Set();
    let idle = 0;
    for (let index = 0; index < 4; index += 1) {
      scrollCommentsArea(Math.max(700, window.innerHeight));
      await helpers.delay(450);
      const scope = activeShortCommentsPanel() || document;
      if (scope.querySelector("ytd-comment-thread-renderer")) break;
    }
    for (let scroll = 0; scroll < 25 && comments.length < target; scroll += 1) {
      const scope = activeShortCommentsPanel() || document;
      clickMoreComments(scope);
      const before = comments.length;
      for (const thread of scope.querySelectorAll("ytd-comment-thread-renderer")) {
        const text = helpers.cleanText(thread.querySelector("#content-text")?.textContent || "");
        if (!text) continue;
        const sender = helpers.cleanText(thread.querySelector("#author-text")?.textContent || "");
        const date = helpers.cleanText(thread.querySelector("#published-time-text a, #published-time-text")?.textContent || "");
        const key = `${sender}|${date}|${text}`;
        if (seen.has(key)) continue;
        seen.add(key);
        comments.push({
          sender_name: sender,
          username: sender,
          text,
          date,
          likes: helpers.count(thread.querySelector("#vote-count-middle")?.textContent || "") || 0
        });
        if (comments.length >= target) break;
      }
      idle = comments.length === before ? idle + 1 : 0;
      if (comments.length >= target || idle >= idleLimit) break;
      const threads = scope.querySelectorAll("ytd-comment-thread-renderer");
      threads[threads.length - 1]?.scrollIntoView({ block: "end", behavior: "instant" });
      scrollCommentsArea(3000);
      await helpers.delay(700);
    }
    return comments.slice(offset, target);
  }

  async function openShortsComments() {
    const selectors = [
      "ytd-reel-player-overlay-renderer #comments-button button",
      "#comments-button button",
      'button[aria-label*="comments" i]',
      'button[aria-label*="comment" i]'
    ];
    for (const selector of selectors) {
      const button = Array.from(document.querySelectorAll(selector)).find(isVisible);
      if (!button) continue;
      button.click();
      await helpers.waitForAny(["ytd-comment-thread-renderer", "ytd-engagement-panel-section-list-renderer"], 6000);
      return;
    }
  }

  function clickMoreComments(root = document) {
    for (const button of root.querySelectorAll("#more, #more-replies, ytd-button-renderer, tp-yt-paper-button")) {
      const text = helpers.cleanText(button.textContent || "").toLowerCase();
      if ((text.includes("more") || text.includes("repl")) && isVisible(button)) {
        try { button.click(); } catch (_error) { /* Ignore detached buttons. */ }
      }
    }
  }

  function activeShortCommentsPanel() {
    return Array.from(document.querySelectorAll(
      'ytd-engagement-panel-section-list-renderer[target-id*="comment" i], ytd-engagement-panel-section-list-renderer'
    )).find((panel) => {
      if (!isVisible(panel)) return false;
      const target = String(panel.getAttribute("target-id") || "").toLowerCase();
      return target.includes("comment") || Boolean(panel.querySelector("ytd-comment-thread-renderer"));
    }) || null;
  }

  function scrollCommentsArea(amount) {
    const panel = activeShortCommentsPanel();
    if (!panel) {
      window.scrollBy({ top: amount, behavior: "instant" });
      return;
    }
    const candidates = [
      panel,
      ...Array.from(panel.querySelectorAll("#content, #contents, [scrollable], tp-yt-paper-dialog, div"))
    ];
    const scrollable = candidates.find((node) => {
      if (!isVisible(node) || node.scrollHeight <= node.clientHeight + 20) return false;
      const overflow = getComputedStyle(node).overflowY;
      return overflow === "auto" || overflow === "scroll" || overflow === "overlay";
    }) || panel;
    scrollable.scrollBy({ top: amount, behavior: "instant" });
  }

  async function goToSection(channelUrl, section, fallback = "") {
    const candidates = [section, fallback].filter(Boolean);
    for (const candidate of candidates) {
      const target = `${channelUrl.replace(/\/$/, "")}/${candidate}`;
      if (samePath(location.href, target)) {
        if (await waitForSection(candidate)) return true;
        continue;
      }
      const previous = captureSectionState(candidate);
      const app = document.querySelector("ytd-app");
      const endpoint = findChannelTabEndpoint(candidate);
      if (endpoint && typeof app?.handleNavigate === "function"
        && await navigateSection(
          () => app.handleNavigate({ command: endpoint, form: {} }),
          target, candidate, previous, true
        )) {
        return true;
      }
      const link = findSectionNavigationLink(target, candidate);
      if (link) {
        link.scrollIntoView({ block: "nearest", inline: "nearest", behavior: "instant" });
        await helpers.delay(300);
        if (await navigateSection(() => link.click(), target, candidate, previous)) return true;
      }
    }
    return false;
  }

  async function navigateSection(action, target, section, previous, allowUnchanged = false) {
    try {
      const finished = waitForYoutubeNavigation(target);
      action();
      if (!await waitForPath(target, 12000)) return false;
      await Promise.race([finished, helpers.delay(3000)]);
      return waitForSection(section, previous, allowUnchanged);
    } catch (_error) {
      return false;
    }
  }

  function findChannelTabEndpoint(section) {
    const wanted = normalizedSection(section);
    const fresh = collectChannelTabEndpoints();
    const endpoint = fresh.get(wanted) || channelTabEndpoints.get(wanted) || null;
    for (const [key, value] of fresh.entries()) {
      channelTabEndpoints.set(key, value);
    }
    return endpoint;
  }

  function collectChannelTabEndpoints() {
    const endpoints = new Map();
    const seen = new Set();
    const knownSections = new Set(["home", "featured", "posts", "videos", "shorts", "streams", "live", "playlists"]);
    const walk = (value) => {
      if (!value || typeof value !== "object" || seen.has(value)) return;
      seen.add(value);
      const tab = value.tabRenderer
        || value.expandableTabRenderer
        || (value.endpoint && value.title !== undefined ? value : null);
      const title = helpers.cleanText(tab?.title || "").toLowerCase();
      const url = tab?.endpoint?.commandMetadata?.webCommandMetadata?.url || "";
      const pathSection = normalizedSection(normalizeSectionPath(url));
      const titleSection = normalizedSection(title);
      if (tab?.endpoint && knownSections.has(pathSection) && !endpoints.has(pathSection)) {
        endpoints.set(pathSection, tab.endpoint);
      } else if (tab?.endpoint && knownSections.has(titleSection) && !endpoints.has(titleSection)) {
        endpoints.set(titleSection, tab.endpoint);
      }
      for (const child of Object.values(value)) walk(child);
    };
    walk(window.ytInitialData);
    return endpoints;
  }

  function findSectionNavigationLink(target, section) {
    const exact = findNavigationLink(target);
    if (exact) return exact;
    const wanted = normalizedSection(section);
    const tabRoot = document.querySelector(
      "yt-tab-group-shape, ytd-c4-tabbed-header-renderer, yt-page-header-view-model"
    ) || document;
    const matches = Array.from(tabRoot.querySelectorAll("a[href]")).filter((anchor) => {
      const pathSection = normalizedSection(normalizeSectionPath(anchor.getAttribute("href") || ""));
      return pathSection === wanted;
    });
    return matches.find(isVisible) || matches[0] || null;
  }

  function normalizeSectionPath(value) {
    try {
      const parts = new URL(String(value || ""), location.origin).pathname.split("/").filter(Boolean);
      return String(parts[parts.length - 1] || "").toLowerCase();
    } catch (_error) {
      return "";
    }
  }

  async function returnToSection(channelUrl, section) {
    const candidates = [section, section === "posts" ? "community" : ""].filter(Boolean);
    const isSectionUrl = () => candidates.some((candidate) => {
      return samePath(location.href, `${channelUrl.replace(/\/$/, "")}/${candidate}`);
    });
    if (!isSectionUrl()) {
      history.back();
      if (await waitForRestoredSection(channelUrl, section, candidates)) return true;
    }
    return goToSection(channelUrl, section, section === "posts" ? "community" : "");
  }

  async function waitForRestoredSection(channelUrl, section, candidates, timeoutMs = 6000) {
    const started = Date.now();
    let fingerprint = "";
    let stableChecks = 0;
    while (Date.now() - started < timeoutMs) {
      const onSectionUrl = candidates.some((candidate) => {
        return samePath(location.href, `${channelUrl.replace(/\/$/, "")}/${candidate}`);
      });
      const state = onSectionUrl ? captureSectionState(section) : null;
      if (state?.ready && currentSectionPath() === normalizedSection(section)) {
        if (state.fingerprint === fingerprint) {
          stableChecks += 1;
        } else {
          fingerprint = state.fingerprint;
          stableChecks = 1;
        }
        if (stableChecks >= 2) {
          await helpers.delay(200);
          return true;
        }
      }
      await helpers.delay(200);
    }
    return false;
  }

  async function navigateWithinYoutube(target, selectors, readyTimeoutMs = 8000, settleMs = 650) {
    if (samePath(location.href, target)) return true;
    let link = findNavigationLink(target);
    if (!link) {
      window.scrollTo({ top: 0, behavior: "instant" });
      for (let index = 0; index < 12 && !link; index += 1) {
        await helpers.delay(index ? 350 : 500);
        link = findNavigationLink(target);
        if (!link) window.scrollBy({ top: 1600, behavior: "instant" });
      }
    }
    if (!link) return false;
    link.click();
    const arrived = await waitForPath(target, 10000, settleMs);
    if (arrived && readyTimeoutMs > 0) await helpers.waitForAny(selectors, readyTimeoutMs);
    return arrived;
  }

  async function navigateToCommunityPost(item, channelUrl, selectors) {
    const target = item.url;
    if (samePath(location.href, target)
      && await waitForStableItemContent(item, "posts", 2500)) {
      return true;
    }
    if (currentSectionPath() === "posts") {
      const openedFromSection = await navigateWithinYoutube(target, selectors, 0, 100);
      if (openedFromSection) return true;
    }

    if (!await returnToSection(channelUrl, "posts")) return false;
    return navigateWithinYoutube(target, selectors, 0, 100);
  }

  async function navigateToWatch(id, selectors) {
    const target = `https://www.youtube.com/watch?v=${encodeURIComponent(id)}`;
    if (!samePath(location.href, target)) {
      const app = document.querySelector("ytd-app");
      if (typeof app?.handleNavigate === "function") {
        try {
          app.handleNavigate({
            command: {
              commandMetadata: {
                webCommandMetadata: {
                  url: `/watch?v=${encodeURIComponent(id)}`,
                  webPageType: "WEB_PAGE_TYPE_WATCH",
                  rootVe: 3832
                }
              },
              watchEndpoint: { videoId: id }
            },
            form: {}
          });
        } catch (_error) {
          return navigateWithinYoutube(target, selectors);
        }
      } else {
        return navigateWithinYoutube(target, selectors);
      }
      if (!await waitForPath(target, 10000)) return false;
    }
    if (!await waitForWatchVideo(id, 12000)) return false;
    await helpers.waitForAny(selectors, 5000);
    return selectors.some((selector) => document.querySelector(selector));
  }

  async function waitForWatchVideo(id, timeoutMs) {
    const started = Date.now();
    while (Date.now() - started < timeoutMs) {
      const watch = Array.from(document.querySelectorAll("ytd-watch-flexy"))
        .find((node) => node.getAttribute("video-id") === id);
      const title = helpers.cleanText(
        watch?.querySelector("h1.ytd-watch-metadata yt-formatted-string, h1.ytd-watch-metadata")?.textContent || ""
      );
      if (watch && title) {
        await helpers.delay(350);
        return true;
      }
      await helpers.delay(200);
    }
    return false;
  }

  async function waitForStableWatchTitle(id, timeoutMs = 10000) {
    return waitForStableValue(() => {
      const watch = Array.from(document.querySelectorAll("ytd-watch-flexy"))
        .find((node) => node.getAttribute("video-id") === id && isVisible(node));
      return helpers.cleanText(
        watch?.querySelector(
          "h1.ytd-watch-metadata yt-formatted-string, h1.ytd-watch-metadata, yt-formatted-string.style-scope.ytd-watch-metadata"
        )?.textContent || ""
      );
    }, timeoutMs);
  }

  async function waitForStableItemContent(item, section, timeoutMs = 6000) {
    if (section !== "posts") return true;
    return Boolean(await waitForStableValue(() => {
      const card = currentCommunityPostRoot(item);
      if (!card) return "";
      const text = extractCommunityText(card);
      const backgroundNode = Array.from(card.querySelectorAll("[style*='background-image']")).find(isVisible);
      const media = Array.from(card.querySelectorAll("img"))
        .map((image) => image.currentSrc || image.getAttribute("src") || "")
        .find((value) => isHttpUrl(value))
        || (backgroundNode ? backgroundImageForNode(backgroundNode) : "");
      return `${item.id}|${text || media || ""}`;
    }, timeoutMs, 2));
  }

  function currentCommunityPostRoot(item) {
    const expected = String(item?.id || "").trim();
    const expectedText = helpers.cleanText(item?.text || item?.caption || "");
    if (!expected || location.pathname.replace(/\/+$/, "") !== `/post/${expected}`) {
      return null;
    }
    const selectors = [
      "ytd-backstage-post-thread-renderer",
      "ytd-backstage-post-renderer",
      "ytd-post-renderer",
      "yt-backstage-post-renderer-view-model",
      "yt-post-renderer-view-model",
      "yt-post-view-model"
    ].join(",");
    return Array.from(document.querySelectorAll(selectors)).filter(isVisible).find((candidate) => {
      const attributeId = candidate.getAttribute("post-id")
        || candidate.getAttribute("data-post-id")
        || "";
      if (attributeId === expected) return true;
      const linkMatches = Array.from(candidate.querySelectorAll('a[href*="/post/"]')).some((anchor) => {
        const owner = anchor.closest(selectors);
        return owner === candidate
          && String(anchor.getAttribute("href") || "").match(/\/post\/([^/?#]+)/)?.[1] === expected;
      });
      return linkMatches || Boolean(
        expectedText
        && extractCommunityText(candidate) === expectedText
      );
    }) || null;
  }

  async function waitForStableShort(id, timeoutMs = 12000) {
    let activeRoot = null;
    const stable = await waitForStableValue(() => {
      if (location.pathname.replace(/\/$/, "") !== `/shorts/${id}`) return "";
      const roots = Array.from(document.querySelectorAll(
        "ytd-reel-video-renderer, yt-reel-video-renderer, ytd-reel-player-overlay-renderer"
      )).filter(isVisible);
      activeRoot = roots.find((root) => {
        if (root.getAttribute("video-id") === id) return true;
        return Array.from(root.querySelectorAll('a[href*="/shorts/"]'))
          .some((anchor) => videoId(anchor.getAttribute("href") || "") === id);
      }) || roots[roots.length - 1] || null;
      if (!activeRoot) return "";
      const title = currentPlayerTitle(id) || helpers.cleanText(
        activeRoot.querySelector([
          "ytd-reel-player-header-renderer h2",
          "ytd-reel-player-header-renderer #title",
          "yt-shorts-video-title-view-model h2",
          ".ytShortsVideoTitleViewModelShortsVideoTitle",
          "#overlay #title"
        ].join(","))?.textContent || ""
      );
      return `${id}|${title || "renderer-ready"}`;
    }, timeoutMs);
    return stable ? activeRoot : null;
  }

  async function waitForStableValue(reader, timeoutMs, stableChecksRequired = 3) {
    const started = Date.now();
    let previous = "";
    let stableChecks = 0;
    while (Date.now() - started < timeoutMs) {
      const value = helpers.cleanText(String(reader() || ""));
      if (value && value === previous) {
        stableChecks += 1;
      } else {
        previous = value;
        stableChecks = value ? 1 : 0;
      }
      if (value && stableChecks >= stableChecksRequired) {
        await helpers.delay(350);
        return value;
      }
      await helpers.delay(300);
    }
    return "";
  }

  function findNavigationLink(target) {
    const normalized = normalizeYoutubeUrl(target);
    return Array.from(document.querySelectorAll("a[href]")).find((anchor) => {
      const href = anchor.getAttribute("href") || "";
      return normalizeYoutubeUrl(href) === normalized;
    }) || null;
  }

  async function waitForPath(target, timeoutMs, settleMs = 650) {
    const started = Date.now();
    while (Date.now() - started < timeoutMs) {
      if (samePath(location.href, target)) {
        if (settleMs > 0) await helpers.delay(settleMs);
        return true;
      }
      await helpers.delay(200);
    }
    return false;
  }

  async function waitForSection(section, previous = null, allowUnchanged = false) {
    const started = Date.now();
    let stableFingerprint = "";
    let stableChecks = 0;
    while (Date.now() - started < 12000) {
      const state = captureSectionState(section);
      const changed = !previous
        || state.root !== previous.root
        || state.fingerprint !== previous.fingerprint;
      if (state.ready && (changed || allowUnchanged) && currentSectionPath() === normalizedSection(section)) {
        if (state.fingerprint === stableFingerprint) {
          stableChecks += 1;
        } else {
          stableFingerprint = state.fingerprint;
          stableChecks = 1;
        }
        if (stableChecks >= 3) {
          await helpers.delay(600);
          return true;
        }
      }
      await helpers.delay(250);
    }
    return false;
  }

  function waitForYoutubeNavigation(target, timeoutMs = 15000) {
    return new Promise((resolve) => {
      let settled = false;
      const finish = (value) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        window.removeEventListener("yt-navigate-finish", onFinish);
        document.removeEventListener("yt-navigate-finish", onFinish);
        resolve(value);
      };
      const onFinish = () => {
        if (samePath(location.href, target)) finish(true);
      };
      const timer = setTimeout(() => finish(false), timeoutMs);
      window.addEventListener("yt-navigate-finish", onFinish);
      document.addEventListener("yt-navigate-finish", onFinish);
    });
  }

  function currentSectionPath() {
    return normalizedSection(normalizeSectionPath(location.href));
  }

  function normalizedSection(value) {
    const section = helpers.cleanText(String(value || "")).toLowerCase();
    return section === "community" ? "posts" : section;
  }

  function captureSectionState(section) {
    const root = activeChannelContent();
    const cards = sectionCards(section, root);
    return {
      root,
      cards,
      ready: cards.length > 0 && cards.slice(0, 3).every((card) => {
        return Boolean(sectionCardId(card, section) && sectionCardContent(card, section));
      }),
      fingerprint: cards.slice(0, 20).map((card) => {
        return `${sectionCardId(card, section)}:${sectionCardContent(card, section)}`;
      }).filter(Boolean).join("|")
    };
  }

  function activeChannelContent() {
    const browseRoots = Array.from(document.querySelectorAll(
      'ytd-browse[page-subtype="channels"], ytd-browse[role="main"], ytd-browse'
    )).filter(isVisible);
    return browseRoots[browseRoots.length - 1] || null;
  }

  function sectionCards(section, root = activeChannelContent()) {
    if (!root) return [];
    const selectors = section === "posts" || section === "community"
      ? COMMUNITY_ITEM_SELECTORS
      : CHANNEL_ITEM_SELECTORS;
    return Array.from(root.querySelectorAll(selectors)).filter((card) => {
      if (!isVisible(card)) return false;
      if (section === "shorts") {
        return Boolean(card.querySelector('a[href*="/shorts/"]'));
      }
      if (section === "videos") {
        return Boolean(card.querySelector('a[href*="/watch?"]'));
      }
      return Boolean(card.querySelector('a[href*="/post/"]'));
    });
  }

  function sectionCardId(card, section) {
    if (section === "posts" || section === "community") {
      return card.querySelector('a[href*="/post/"]')?.getAttribute("href") || "";
    }
    const selector = section === "shorts" ? 'a[href*="/shorts/"]' : 'a[href*="/watch?"]';
    return card.querySelector(selector)?.getAttribute("href") || "";
  }

  function sectionCardContent(card, section) {
    if (section === "posts" || section === "community") {
      const text = extractCommunityText(card);
      const media = Array.from(card.querySelectorAll("img"))
        .map((image) => image.currentSrc || image.getAttribute("src") || "")
        .find((value) => isHttpUrl(value)) || "";
      return text || media;
    }
    const isShorts = section === "shorts";
    const selector = isShorts ? 'a[href*="/shorts/"]' : 'a[href*="/watch?"]';
    const anchor = card.querySelector(selector);
    return anchor ? extractVideoCardTitle(card, anchor, isShorts) : "";
  }

  function extractVideoCardTitle(card, anchor, isShorts) {
    const selectors = isShorts
      ? [
          "[class*='shortsLockupViewModelHostMetadataTitle']",
          "ytm-shorts-lockup-view-model h3",
          "h3 a[href*='/shorts/']",
          "#video-title"
        ]
      : [
          "#video-title",
          "a.yt-lockup-metadata-view-model-wiz__title",
          "[class*='yt-lockup-metadata-view-model-wiz__title']",
          "h3 a[href*='/watch']",
          "h3"
        ];
    const candidates = [];
    for (const selector of selectors) {
      const node = card.querySelector(selector);
      candidates.push(node?.getAttribute("title"), node?.textContent);
    }
    const matchingAnchors = Array.from(card.querySelectorAll(
      isShorts ? 'a[href*="/shorts/"]' : 'a[href*="/watch?"]'
    )).filter((node) => videoId(node.getAttribute("href") || "") === videoId(anchor.getAttribute("href") || ""));
    for (const node of [anchor, ...matchingAnchors]) {
      candidates.push(
        node?.getAttribute("title"),
        node?.querySelector("[title]")?.getAttribute("title"),
        node?.querySelector("img")?.getAttribute("alt")
      );
    }
    return candidates
      .map((value) => helpers.cleanText(value || ""))
      .find(isUsableItemTitle) || "";
  }

  function extractCommunityText(card) {
    const selectors = [
      "yt-formatted-string#content-text",
      "yt-attributed-string#content-text",
      "#content-text",
      "yt-post-text-view-model .yt-core-attributed-string",
      "yt-post-text-view-model"
    ];
    for (const selector of selectors) {
      const value = helpers.cleanText(card.querySelector(selector)?.textContent || "");
      if (value) return value;
    }
    return "";
  }

  function currentPlayerTitle(id) {
    const details = window.ytInitialPlayerResponse?.videoDetails;
    if (details?.videoId === id && isUsableItemTitle(details.title)) {
      return helpers.cleanText(details.title);
    }
    const watch = Array.from(document.querySelectorAll("ytd-watch-flexy"))
      .find((node) => node.getAttribute("video-id") === id);
    return helpers.cleanText(
      watch?.querySelector("h1.ytd-watch-metadata yt-formatted-string, h1.ytd-watch-metadata")?.textContent || ""
    );
  }

  function isUsableItemTitle(value) {
    const title = helpers.cleanText(value || "");
    return Boolean(title)
      && !/^(?:shorts?|videos?|posts?|watch|youtube)$/i.test(title)
      && !/^[\d.,]+\s*[KMB]?\s+(?:views?|likes?)$/i.test(title);
  }

  function shouldCollectComments(job, itemCount) {
    if (!itemCount || helpers.limit(job, "max_comments", 10, 100) < 1) return false;
    return socialDataType(job) === "comments";
  }

  function requestedCommentTargets(job, items) {
    const targetId = requestedItemId(job);
    if (targetId) return items.filter((item) => item.id === targetId).slice(0, 1);
    return socialDataType(job) === "comments" ? items : items.slice(0, 5);
  }

  function socialDataType(job) {
    return String(job?.social_data_type || job?.command || "").trim().toLowerCase();
  }

  function requestedItemId(job) {
    const value = String(job?.cursor?.hash_id || job?.hash_id || "").trim();
    return videoId(value) || value.replace(/^.*\/post\//, "").split(/[/?#]/)[0];
  }

  function existingIds(job) {
    const values = Array.isArray(job?.cursor?.existing_post_urls) ? job.cursor.existing_post_urls : [];
    const result = new Set();
    for (const value of values) {
      const normalized = normalizeYoutubeUrl(value);
      const id = videoId(value) || String(value || "").match(/\/post\/([^/?#]+)/)?.[1] || "";
      if (normalized) result.add(normalized);
      if (id) result.add(id);
    }
    return result;
  }

  function videoId(value) {
    try {
      const url = new URL(String(value || ""), location.origin);
      return url.searchParams.get("v") || url.pathname.match(/\/shorts\/([^/?#]+)/)?.[1] || "";
    } catch (_error) {
      return String(value || "").match(/(?:[?&]v=|\/shorts\/)([^?&#/]+)/)?.[1] || "";
    }
  }

  function canonicalVideoUrl(value) {
    const id = videoId(value);
    return id ? `https://www.youtube.com/watch?v=${id}` : cleanYoutubeUrl(value);
  }

  function cleanYoutubeUrl(value) {
    try {
      const url = new URL(String(value || ""), location.origin);
      url.hash = "";
      return url.toString();
    } catch (_error) {
      return "";
    }
  }

  function normalizeYoutubeUrl(value) {
    try {
      const url = new URL(String(value || ""), location.origin);
      const id = url.searchParams.get("v") || url.pathname.match(/\/shorts\/([^/?#]+)/)?.[1];
      if (id) return `video:${id}`;
      const post = url.pathname.match(/\/post\/([^/?#]+)/)?.[1];
      if (post) return `post:${post}`;
      return url.pathname.replace(/\/$/, "").toLowerCase();
    } catch (_error) {
      return "";
    }
  }

  function samePath(left, right) {
    return normalizeYoutubeUrl(left) === normalizeYoutubeUrl(right);
  }

  function bestThumbnail(root, id) {
    const images = Array.from(root.querySelectorAll("img"));
    const preferred = [
      ...images.filter((image) => /i\.ytimg\.com|ytimg\.com\/vi/i.test(`${image.currentSrc || ""} ${image.src || ""}`)),
      ...images.filter((image) => (image.naturalWidth || image.width || 0) > 120)
    ];
    for (const image of preferred) {
      for (const raw of [image.currentSrc, image.getAttribute("src")]) {
        const value = helpers.absoluteUrl(raw || "");
        if (isHttpUrl(value)) return value;
      }
    }
    return id ? `https://i.ytimg.com/vi/${id}/hqdefault.jpg` : "";
  }

  function collectImages(items) {
    const images = [];
    const seen = new Set();
    for (const item of items) {
      const urls = Array.isArray(item.image_urls)
        ? item.image_urls
        : [item.image_url, item.thumbnail, item.media_url];
      for (const url of urls) {
        if (!isHttpUrl(url) || seen.has(url)) continue;
        seen.add(url);
        images.push({
          image_url: url,
          thumbnail: url,
          source_url: item.url,
          title: item.title || item.text || "YouTube media",
          source: "youtube"
        });
      }
    }
    return images;
  }

  function setPartialBundle(username, channelUrl, profile, posts, videos, shorts, job) {
    const allItems = [...posts, ...videos, ...shorts];
    window.__orionLastPartialResult = {
      platform: "youtube",
      username,
      url: channelUrl,
      profile,
      posts: [...posts],
      videos: [...videos],
      shorts: [...shorts],
      images: collectImages(allItems).slice(0, helpers.limit(job, "max_images", 25, 100)),
      followers: [],
      following: []
    };
  }

  function firstUrl(entries) {
    for (const [selector, attribute] of entries) {
      const node = document.querySelector(selector);
      const value = node?.getAttribute(attribute) || node?.[attribute] || "";
      const url = helpers.absoluteUrl(value);
      if (isHttpUrl(url)) return url;
    }
    return "";
  }

  function backgroundImage(selector) {
    const node = document.querySelector(selector);
    return node ? backgroundImageForNode(node) : "";
  }

  function backgroundImageForNode(node) {
    const value = getComputedStyle(node).backgroundImage || node.style?.backgroundImage || "";
    const match = value.match(/url\(["']?([^"')]+)["']?\)/);
    const url = match ? helpers.absoluteUrl(match[1]) : "";
    return isHttpUrl(url) ? url : "";
  }

  function isVisible(node) {
    const rect = node.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function isHttpUrl(value) {
    return /^https?:\/\//i.test(String(value || ""));
  }
})();

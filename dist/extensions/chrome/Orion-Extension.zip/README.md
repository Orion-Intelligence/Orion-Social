# Orion Social Scraper Extension

Phase 2 browser extension scaffold for Orion social scraping.

## What It Does

- connects to the Orion Social backend over WebSocket
- announces supported platform capabilities
- stores the backend-assigned extension ID after registration
- receives scraping jobs
- opens a browser tab for the target URL
- injects shared helpers, a platform scraper, and the content runner
- sends progress and JSON results back to the backend

The popup shows `registering` while the WebSocket is open but backend registration has not completed. It shows `online` only after the backend returns `extension_registered`.

## Load Locally

1. Open Chromium or Chrome.
2. Go to `chrome://extensions`.
3. Enable developer mode.
4. Load unpacked extension from this folder.
5. Open the extension popup and configure the backend URL if needed.

Default backend URL:

```text
ws://127.0.0.1:8020/extensions/ws
```

Backend connection status:

```text
GET http://127.0.0.1:8020/extensions/status
```

The status response includes connected extensions, capabilities, active job ID, and `status: online`.

## Job Message

The background worker accepts messages shaped like:

```json
{
  "type": "job",
  "job": {
    "job_id": "reddit-profile-test",
    "command": "profile",
    "platform": "reddit",
    "username": "example",
    "url": "https://www.reddit.com/user/example/",
    "social_data_type": "profile_info",
    "limits": {
      "max_posts": 25
    }
  }
}
```

## Result Message

Results are returned as:

```json
{
  "type": "job_result",
  "job_id": "reddit-profile-test",
  "status": "done",
  "success": true,
  "data": {},
  "error": null
}
```

## Scraper Status

`reddit.js`, `github.js`, `linkedin.js`, `x.js`, `instagram.js`, `facebook.js`, `youtube.js`, and `tiktok.js` return normalized profile, post, comment, and image payloads from the live DOM where the page exposes those fields to the browser session. YouTube returns separate post, video, and Shorts collections; TikTok profile videos are returned as Shorts.

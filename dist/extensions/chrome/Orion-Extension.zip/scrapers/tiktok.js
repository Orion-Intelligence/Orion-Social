(function () {
  const helpers = window.OrionScraperHelpers;
  const CARD = '[data-e2e="user-post-item"], [data-e2e="user-post-item-list"] > div';
  const COMMENT = [
    '[data-e2e="comment-item"]',
    '[data-e2e^="comment-item-"]',
    'div[class*="DivCommentItemContainer"]',
    'div[class*="CommentItemContainer"]'
  ].join(',');
  const COMMENT_TEXT = [
    '[data-e2e="comment-level-1"]',
    '[data-e2e^="comment-level-"]',
    'p[class*="CommentText"]',
    '[class*="CommentText"]'
  ].join(',');

  window.OrionScrapers = window.OrionScrapers || {};
  window.OrionScrapers.tiktok = {
    selectors: [
      '[data-e2e="user-page"]',
      '[data-e2e="user-title"]',
      '[data-e2e="user-post-item-list"]',
      '[data-e2e="video-detail"]',
      '[data-e2e="video-desc"]',
      'a[href*="/video/"]'
    ],

    async run(job) {
      const username = cleanUsername(job.username || usernameFromUrl());
      const profileUrl = getProfileUrl(username);
      assertCanScrape();
      const profile = getProfile(username, profileUrl);
      const command = helpers.command(job);
      if (job.detail_only) {
        const short = await collectCurrentShort(job);
        return makeResult(username, profileUrl, profile, short ? [short] : [], job);
      }
      const limitKey = command === 'images' ? 'max_images' : 'max_shorts';
      const requestedLimit = helpers.limit(job, limitKey, 20, 100);
      const limit = ['profile', 'profile_info'].includes(command)
        ? Math.min(requestedLimit, 20)
        : requestedLimit;

      // TikTok profile items are short videos. Collect every link before opening any.
      const shorts = await collectPostQueue(job, profileUrl, limit);
      savePartial(username, profileUrl, profile, shorts, job);

      // Then enrich the saved queue sequentially so navigation cannot mix items.
      if (command !== 'images' && !job.skip_details) {
        const withComments = helpers.limit(job, 'max_comments', 10, 100) > 0;
        for (const short of shorts) {
          await enrichPost(short, profileUrl, job, withComments);
          savePartial(username, profileUrl, profile, shorts, job);
        }
      }

      const result = makeResult(username, profileUrl, profile, shorts, job);
      window.__orionLastPartialResult = null;
      return result;
    }
  };

  function usernameFromUrl() {
    return decodeURIComponent(location.pathname.match(/^\/@([^/?#]+)/)?.[1] || '');
  }

  function cleanUsername(value) {
    return String(value || '').trim().replace(/^@/, '');
  }

  function assertCanScrape() {
    const path = location.pathname.toLowerCase();
    const body = helpers.cleanText(document.body?.innerText || '');
    const hasProfile = Boolean(document.querySelector(
      '[data-e2e="user-title"], [data-e2e="user-subtitle"], [data-e2e="followers-count"], '
      + '[data-e2e="user-post-item-list"], a[href*="/video/"]'
    ));
    const hasLoginForm = Boolean(document.querySelector(
      'input[type="password"], input[name*="username" i], form[action*="login" i]'
    ));
    const blocked = /\/login|\/signup/.test(path)
      || (!hasProfile && (hasLoginForm || /^\s*log in\s*$/i.test(body)));
    if (!blocked) return;

    const error = new Error('TikTok login required in this browser.');
    error.code = 'AUTH_REQUIRED';
    error.error_code = 'AUTH_REQUIRED';
    error.platform = 'tiktok';
    error.login_url = `https://www.tiktok.com/login?redirect_url=${encodeURIComponent(location.href)}`;
    throw error;
  }

  function getProfileUrl(username) {
    const path = location.pathname.match(/^\/@[^/?#]+/)?.[0];
    return path
      ? `${location.origin}${path}`
      : `https://www.tiktok.com/@${encodeURIComponent(username)}`;
  }

  function getProfile(username, url) {
    const followers = count('[data-e2e="followers-count"]');
    const following = count('[data-e2e="following-count"]');
    const likes = count('[data-e2e="likes-count"]');
    const bio = text('[data-e2e="user-bio"]');

    return {
      username,
      display_name: text('[data-e2e="user-subtitle"]') || username,
      bio,
      description: bio,
      url,
      profile_url: url,
      avatar_url: firstUrl([
        ['[data-e2e="user-avatar"] img', 'src'],
        ['img[data-e2e="user-avatar"]', 'src'],
        ['meta[property="og:image"]', 'content']
      ]),
      cover_url: '',
      followers_count: followers,
      total_followers: followers,
      following_count: following,
      total_following: following,
      likes_count: likes,
      total_likes: likes
    };
  }

  async function collectPostQueue(job, profileUrl, limit) {
    if (!sameProfile(location.href, profileUrl) || !await waitForProfile()) return [];

    const targetId = requestedId(job);
    const existing = existingIds(job);
    const cursorId = existingCursorId(job);
    let cursorReached = !cursorId;
    let offset = cursorId ? 0 : helpers.limit(job, 'post_offset', 0, 5000);
    const posts = [];
    const seen = new Set();
    let idle = 0;

    window.scrollTo({ top: 0, behavior: 'instant' });
    await helpers.delay(600);

    for (let scroll = 0; scroll < 40 && posts.length < limit; scroll += 1) {
      await waitForStableCards();
      const before = seen.size;

      for (const card of cards()) {
        const post = readCard(card);
        if (!post || seen.has(post.id)) continue;
        seen.add(post.id);

        if (targetId && post.id !== targetId) continue;
        if (!cursorReached) {
          cursorReached = post.id === cursorId;
          continue;
        }
        if (offset > 0) {
          offset -= 1;
          continue;
        }
        if (existing.has(post.id) || existing.has(normalizeUrl(post.url))) continue;

        posts.push(post);
        if (posts.length >= limit || targetId) break;
      }

      idle = seen.size === before ? idle + 1 : 0;
      if (posts.length >= limit || (targetId && posts.length) || idle >= 5) break;

      window.scrollBy({ top: 2600, behavior: 'instant' });
      await helpers.delay(1000);
    }

    return posts;
  }

  function cards() {
    return Array.from(document.querySelectorAll(CARD)).filter((card) => {
      return visible(card) && card.querySelector('a[href*="/video/"]');
    });
  }

  function readCard(card) {
    const anchor = card.querySelector('a[href*="/video/"]');
    const url = cleanUrl(anchor?.getAttribute('href') || '');
    const id = videoId(url);
    if (!id) return null;

    const image = card.querySelector('img');
    const title = helpers.cleanText(
      image?.getAttribute('alt')
      || anchor?.getAttribute('aria-label')
      || card.querySelector('[data-e2e="user-post-item-desc"]')?.textContent
      || ''
    );
    const thumbnail = helpers.absoluteUrl(image?.currentSrc || image?.src || '');
    return {
      id,
      hash_id: id,
      title: title || id,
      text: title || id,
      url,
      post_url: url,
      created_at: '',
      author: usernameFromVideoUrl(url),
      source: 'tiktok',
      views_count: helpers.count(text('[data-e2e="video-views"]', card)) || 0,
      likes_count: 0,
      comments_count: 0,
      shares: 0,
      collected_comments_count: 0,
      media_type: 'image',
      media_url: thumbnail,
      image_url: thumbnail,
      thumbnail,
      comment_items: [],
      comment_details: []
    };
  }

  async function collectCurrentShort(job) {
    const id = videoId(location.href) || requestedId(job);
    if (!id) return null;
    const title = helpers.cleanText(
      document.querySelector('meta[property="og:title"]')?.content
      || document.title.replace(/\s*\|\s*TikTok\s*$/i, '')
      || id
    );
    const image = firstUrl([['meta[property="og:image"]', 'content']]);
    const short = {
      id,
      hash_id: id,
      title,
      text: title,
      url: cleanUrl(location.href),
      post_url: cleanUrl(location.href),
      created_at: '',
      author: usernameFromVideoUrl(location.href),
      source: 'tiktok',
      views_count: 0,
      likes_count: 0,
      comments_count: 0,
      shares: 0,
      collected_comments_count: 0,
      media_type: 'image',
      media_url: image,
      image_url: image,
      thumbnail: image,
      comment_items: [],
      comment_details: []
    };
    const root = await waitForPost(id);
    if (!root) return short;
    applyPostDetails(short, root);
    const comments = await collectComments(job);
    short.comment_details = comments;
    short.comment_items = comments.map((item) => item.text);
    short.collected_comments_count = comments.length;
    short.comments_count = Math.max(short.comments_count || 0, comments.length);
    return short;
  }

  async function enrichPost(post, profileUrl, job, withComments) {
    if (!await openPost(post)) return;

    const root = await waitForPost(post.id);
    if (!root) {
      await returnToProfile(profileUrl);
      return;
    }

    applyPostDetails(post, root);
    if (withComments) {
      const comments = await collectComments(job);
      post.comment_details = comments;
      post.comment_items = comments.map((item) => item.text);
      post.collected_comments_count = comments.length;
      post.comments_count = Math.max(post.comments_count || 0, comments.length);
    }

    await returnToProfile(profileUrl);
  }

  function applyPostDetails(post, root) {
    post.title = firstText([
      '[data-e2e="browse-video-desc"]',
      '[data-e2e="video-desc"]'
    ], root) || post.title;
    post.text = post.title;
    post.author = firstText([
      '[data-e2e="browse-username"]',
      '[data-e2e="video-author-uniqueid"]'
    ], root).replace(/^@/, '') || post.author;
    post.created_at = firstText([
      '[data-e2e="browse-video-publish-time"]',
      '[data-e2e="browser-video-publish-time"]',
      '[data-e2e="video-publish-time"]'
    ], root) || post.created_at;
    post.likes_count = metric(root, [
      '[data-e2e="browse-like-count"]',
      '[data-e2e="like-count"]'
    ], post.likes_count);
    post.comments_count = metric(root, [
      '[data-e2e="browse-comment-count"]',
      '[data-e2e="comment-count"]'
    ], post.comments_count);
    post.shares = metric(root, [
      '[data-e2e="browse-share-count"]',
      '[data-e2e="share-count"]'
    ], post.shares);

    const image = firstUrl([
      ['img[data-e2e="browse-video-poster"]', 'src']
    ], root) || firstUrl([['meta[property="og:image"]', 'content']]);
    if (image) post.media_url = post.image_url = post.thumbnail = image;
  }

  async function openPost(post) {
    if (videoId(location.href) === post.id) return true;

    let anchor = findPostLink(post.id);
    if (!anchor) {
      window.scrollTo({ top: 0, behavior: 'instant' });
      for (let index = 0; index < 18 && !anchor; index += 1) {
        await helpers.delay(index ? 300 : 500);
        anchor = findPostLink(post.id);
        if (!anchor) window.scrollBy({ top: 1400, behavior: 'instant' });
      }
    }
    if (!anchor) return false;

    anchor.click();
    return waitUntil(() => videoId(location.href) === post.id, 12000);
  }

  async function returnToProfile(profileUrl) {
    if (sameProfile(location.href, profileUrl)) return Boolean(await waitForProfile());

    history.back();
    if (await waitUntil(() => sameProfile(location.href, profileUrl), 10000)) {
      return Boolean(await waitForProfile());
    }

    const close = Array.from(document.querySelectorAll(
      '[data-e2e="browse-close"], button[aria-label*="close" i], button[data-e2e*="close"]'
    )).find(visible);
    close?.click();

    return await waitUntil(() => sameProfile(location.href, profileUrl), 5000)
      && Boolean(await waitForProfile());
  }

  async function collectComments(job) {
    const offset = helpers.limit(job, 'comment_offset', 0, 5000);
    const limit = helpers.limit(job, 'max_comments', 10, 100);
    if (!limit || !await openComments()) return [];
    const target = offset + limit;
    const comments = [];
    const seen = new Set();
    let idle = 0;

    await waitUntil(() => commentEntries().length > 0 || noCommentsVisible(), 15000);

    for (let scroll = 0; scroll < 100 && comments.length < target; scroll += 1) {
      const before = comments.length;

      for (const { item, value } of commentEntries()) {
        const sender = firstText([
          '[data-e2e^="comment-username"]',
          '[data-e2e*="comment-username"]',
          'a[href^="/@"]'
        ], item).replace(/^@/, '');
        const key = `${sender}|${value}`;
        if (seen.has(key)) continue;

        seen.add(key);
        comments.push({
          sender_name: sender,
          username: sender,
          text: value,
          date: firstText([
            '[data-e2e^="comment-time-"]',
            'span[class*="SpanCreatedTime"]'
          ], item),
          likes: helpers.count(firstText([
            '[data-e2e="comment-like-count"]',
            '[data-e2e*="comment-like-count"]',
            '[class*="CommentLike"]'
          ], item)) || 0
        });
        if (comments.length >= target) break;
      }

      idle = comments.length === before ? idle + 1 : 0;
      if (comments.length >= target || idle >= 12 || noCommentsVisible()) break;

      clickReplies();
      scrollComments();
      await helpers.delay(900);
    }

    return comments.slice(offset, target);
  }

  function commentEntries() {
    const entries = [];
    const roots = new Set();
    for (const node of document.querySelectorAll(COMMENT_TEXT)) {
      if (!visible(node)) continue;
      const value = helpers.cleanText(node.textContent || '');
      if (!value) continue;
      const item = commentRoot(node);
      if (!item || roots.has(item)) continue;
      roots.add(item);
      entries.push({ item, value });
    }
    return entries;
  }

  function commentRoot(node) {
    const exact = node.closest(COMMENT);
    if (exact) return exact;

    let parent = node.parentElement;
    for (let depth = 0; parent && depth < 8; depth += 1, parent = parent.parentElement) {
      if (parent.querySelector('[data-e2e*="comment-username"], a[href^="/@"]')) return parent;
    }
    return node.parentElement;
  }

  async function openComments() {
    if (commentsVisible()) return true;

    const controls = Array.from(document.querySelectorAll([
      '[data-e2e="comment-icon"]',
      '[data-e2e="browse-comment"]',
      '[data-e2e="browse-comment-icon"]',
      '[data-e2e="browse-comment-count"]',
      '[data-e2e="comment-count"]',
      '[data-e2e="video-comment"]',
      '[data-e2e="video-comment-button"]',
      '[data-e2e="comment-button"]',
      'button[aria-label*="comment" i]',
      '[role="button"][aria-label*="comment" i]',
      'button[title*="comment" i]'
    ].join(',')));

    for (const control of controls) {
      const button = control.closest('button, [role="button"]') || control;
      if (!visible(button)) continue;
      button.scrollIntoView({ block: 'center', behavior: 'instant' });
      await helpers.delay(250);
      try { button.click(); } catch (_error) { continue; }
      if (await waitUntil(commentsVisible, 8000)) return true;
    }
    return commentsVisible();
  }

  function commentsVisible() {
    return Array.from(document.querySelectorAll([
      COMMENT,
      '[data-e2e="comment-list"]',
      'div[class*="DivCommentList"]',
      'div[class*="CommentListContainer"]',
      'div[class*="CommentDrawer"]'
    ].join(','))).some(visible);
  }

  function noCommentsVisible() {
    return Array.from(document.querySelectorAll(
      '[data-e2e="comment-list"], div[class*="CommentList"], div[class*="CommentDrawer"]'
    )).filter(visible).some((node) => {
      return /no comments|be the first to comment/i.test(helpers.cleanText(node.textContent || ''));
    });
  }

  function clickReplies() {
    for (const node of document.querySelectorAll('button, [role="button"]')) {
      const label = helpers.cleanText([
        node.textContent,
        node.getAttribute('aria-label'),
        node.getAttribute('title')
      ].filter(Boolean).join(' '));
      if (visible(node) && /view|show|load|more/i.test(label) && /repl|comment/i.test(label)) {
        try { node.click(); } catch (_error) { /* Detached node. */ }
      }
    }
  }

  function scrollComments() {
    const panel = commentScrollPanel();
    if (!panel) {
      window.scrollBy({ top: Math.max(2200, innerHeight * 0.9), behavior: 'instant' });
      return;
    }

    const amount = Math.max(900, panel.clientHeight * 0.9);
    panel.scrollTo({
      top: Math.min(panel.scrollTop + amount, panel.scrollHeight),
      behavior: 'instant'
    });
    panel.dispatchEvent(new Event('scroll', { bubbles: true }));
  }

  function commentScrollPanel() {
    const candidates = [];
    const seeds = [
      ...document.querySelectorAll(
        '[data-e2e="comment-list"], div[class*="DivCommentList"], '
        + 'div[class*="CommentListContainer"], div[class*="CommentDrawer"]'
      ),
      ...commentEntries().map(({ item }) => item)
    ];

    for (const seed of seeds) {
      for (let node = seed; node && node !== document.body; node = node.parentElement) {
        if (!visible(node) || candidates.includes(node)) continue;
        const overflow = getComputedStyle(node).overflowY;
        if (node.scrollHeight > node.clientHeight + 20
          && ['auto', 'scroll', 'overlay'].includes(overflow)) {
          candidates.push(node);
        }
      }
    }
    return candidates[0] || null;
  }

  async function waitForProfile() {
    return stableValue(() => {
      const identity = firstText([
        '[data-e2e="user-title"]',
        '[data-e2e="user-subtitle"]'
      ]);
      const hasProfile = Boolean(document.querySelector(
        '[data-e2e="user-page"], [data-e2e="user-post-item-list"]'
      ));
      if (!identity && !hasProfile) return '';
      const values = cards().slice(0, 12).map((card) => {
        const anchor = card.querySelector('a[href*="/video/"]');
        const title = card.querySelector('img')?.getAttribute('alt') || '';
        return `${videoId(anchor?.href || '')}:${helpers.cleanText(title)}`;
      }).filter((value) => !value.endsWith(':'));
      return `${identity}|${values.join('|')}|profile`;
    }, 12000);
  }

  async function waitForStableCards() {
    return stableValue(() => cards().slice(-8).map((card) => {
      const anchor = card.querySelector('a[href*="/video/"]');
      const title = card.querySelector('img')?.getAttribute('alt') || '';
      return `${videoId(anchor?.href || '')}:${helpers.cleanText(title)}`;
    }).filter((value) => !value.endsWith(':')).join('|'), 5000, 2);
  }

  async function waitForPost(id) {
    const ready = await stableValue(() => {
      if (videoId(location.href) !== id) return '';
      const root = postRoot();
      if (!root) return '';
      const title = firstText([
        '[data-e2e="browse-video-desc"]',
        '[data-e2e="video-desc"]'
      ], root);
      return `${id}:${title || 'ready'}`;
    }, 12000);
    return ready ? postRoot() : null;
  }

  function postRoot() {
    return Array.from(document.querySelectorAll([
      '[data-e2e="browse-video"]',
      '[data-e2e="video-detail"]',
      'div[class*="DivVideoDetailContainer"]',
      'main'
    ].join(','))).filter(visible).find((node) => {
      return node.querySelector('[data-e2e="browse-video-desc"], [data-e2e="video-desc"], video');
    }) || null;
  }

  async function stableValue(reader, timeout, checksNeeded = 3) {
    const started = Date.now();
    let previous = '';
    let checks = 0;

    while (Date.now() - started < timeout) {
      const value = helpers.cleanText(String(reader() || ''));
      checks = value && value === previous ? checks + 1 : (value ? 1 : 0);
      previous = value;
      if (value && checks >= checksNeeded) return value;
      await helpers.delay(300);
    }
    return '';
  }

  async function waitUntil(test, timeout) {
    const started = Date.now();
    while (Date.now() - started < timeout) {
      if (test()) {
        await helpers.delay(450);
        return true;
      }
      await helpers.delay(200);
    }
    return false;
  }

  function findPostLink(id) {
    return Array.from(document.querySelectorAll('a[href*="/video/"]'))
      .find((anchor) => videoId(anchor.href) === id) || null;
  }

  function requestedId(job) {
    const value = String(job?.cursor?.hash_id || job?.hash_id || '').trim();
    return videoId(value) || value.split(/[/?#]/)[0];
  }

  function existingIds(job) {
    const values = Array.isArray(job?.cursor?.existing_post_urls)
      ? job.cursor.existing_post_urls
      : [];
    const ids = new Set();
    for (const value of values) {
      if (videoId(value)) ids.add(videoId(value));
      if (normalizeUrl(value)) ids.add(normalizeUrl(value));
    }
    return ids;
  }

  function existingCursorId(job) {
    const values = Array.isArray(job?.cursor?.existing_post_urls)
      ? job.cursor.existing_post_urls
      : [];
    for (let index = values.length - 1; index >= 0; index -= 1) {
      const id = videoId(values[index]);
      if (id) return id;
    }
    return '';
  }

  function makeResult(username, url, profile, shorts, job) {
    return {
      platform: 'tiktok',
      username,
      url,
      profile,
      posts: [],
      videos: [],
      shorts,
      images: shorts.filter((short) => /^https?:\/\//i.test(short.image_url || '')).map((short) => ({
        image_url: short.image_url,
        thumbnail: short.thumbnail,
        source_url: short.url,
        title: short.title,
        source: 'tiktok'
      })).slice(0, helpers.limit(job, 'max_images', 25, 100)),
      followers: [],
      following: []
    };
  }

  function savePartial(username, url, profile, shorts, job) {
    window.__orionLastPartialResult = makeResult(username, url, profile, [...shorts], job);
  }

  function metric(root, selectors, fallback) {
    const node = root.querySelector(Array.isArray(selectors) ? selectors.join(',') : selectors);
    return node ? helpers.count(node.textContent || '') || 0 : fallback || 0;
  }

  function firstText(selectors, root = document) {
    for (const selector of selectors) {
      const value = text(selector, root);
      if (value) return value;
    }
    return '';
  }

  function text(selector, root = document) {
    return helpers.cleanText(root.querySelector(selector)?.textContent || '');
  }

  function count(selector) {
    return helpers.count(text(selector)) || 0;
  }

  function firstUrl(entries, root = document) {
    for (const [selector, attribute] of entries) {
      const node = root.querySelector(selector);
      const value = helpers.absoluteUrl(node?.getAttribute(attribute) || node?.[attribute] || '');
      if (/^https?:\/\//i.test(value)) return value;
    }
    return '';
  }

  function videoId(value) {
    try {
      return new URL(String(value || ''), location.origin).pathname.match(/\/video\/(\d+)/)?.[1] || '';
    } catch (_error) {
      return String(value || '').match(/\/video\/(\d+)/)?.[1] || '';
    }
  }

  function usernameFromVideoUrl(value) {
    try {
      return decodeURIComponent(
        new URL(value, location.origin).pathname.match(/^\/@([^/]+)\/video\//)?.[1] || ''
      );
    } catch (_error) {
      return '';
    }
  }

  function cleanUrl(value) {
    try {
      const url = new URL(value, location.origin);
      url.search = '';
      url.hash = '';
      return url.toString();
    } catch (_error) {
      return '';
    }
  }

  function normalizeUrl(value) {
    const id = videoId(value);
    if (id) return `video:${id}`;
    try {
      return new URL(value, location.origin).pathname.replace(/\/$/, '').toLowerCase();
    } catch (_error) {
      return '';
    }
  }

  function sameProfile(left, right) {
    try {
      const path = (value) => new URL(value, location.origin).pathname.replace(/\/$/, '').toLowerCase();
      return path(left) === path(right);
    } catch (_error) {
      return false;
    }
  }

  function visible(node) {
    if (!node) return false;
    const rect = node.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }
})();

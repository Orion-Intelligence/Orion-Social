(function () {
  const helpers = window.OrionScraperHelpers;
  const POST_SELECTOR = [
    'div.feed-shared-update-v2[data-urn*="activity"]',
    'div[data-urn^="urn:li:activity:"]',
    'article[data-urn*="activity"]',
    'article[data-id="main-feed-card"]',
    'article.main-feed-activity-card',
    '[data-test-id="updates"] article'
  ].join(',');
  const COMMENT_SELECTOR = [
    'article.comments-comment-item',
    'div.comments-comment-item',
    'div[data-id*="comment"]'
  ].join(',');

  window.OrionScrapers = window.OrionScrapers || {};
  window.OrionScrapers.linkedin = {
    selectors: ['main', 'h1', POST_SELECTOR],

    async run(job) {
      assertLinkedInAccess();
      const mode = String(job?.linkedin_mode || 'profile').toLowerCase();
      const command = dataType(job);
      const username = cleanUsername(job?.username || usernameFromUrl());
      const profileUrl = profileUrlFor(username);
      const profile = readProfile(username, profileUrl);
      let posts = [];
      let followers = [];
      let following = [];

      if (mode === 'queue') {
        posts = await collectPostQueue(job);
      } else if (mode === 'detail') {
        const post = detailSeed(job);
        if (post.id || post.url) {
          await enrichCurrentPost(post, job, command !== 'images');
          posts = [post];
        }
      } else if (mode === 'connection') {
        const type = String(job?.connection_type || command).toLowerCase();
        const people = await collectConnections(job, username);
        if (type === 'followers') followers = people;
        if (type === 'following') following = people;
      }

      const result = makeResult(username, profileUrl, profile, posts, job, followers, following);
      if (mode === 'profile') {
        result.activity_url = findActivityUrl(profileUrl);
        result.connection_urls = {
          followers: findConnectionUrl('followers'),
          following: findConnectionUrl('following')
        };
      }
      return result;
    }
  };

  function assertLinkedInAccess() {
    const path = location.pathname.toLowerCase();
    const title = String(document.title || '').toLowerCase();
    const body = helpers.cleanText(document.body?.innerText || '').toLowerCase();
    const blocked = /\/(?:uas\/login|login|authwall|checkpoint)\b/.test(path)
      || (!document.querySelector('main, h1, ' + POST_SELECTOR)
        && /linkedin.*(?:log in|sign in)|sign in with email/.test(`${title} ${body.slice(0, 1200)}`));
    if (!blocked) return;
    const error = new Error('LinkedIn login is required. Log in in this browser and retry.');
    error.code = 'AUTH_REQUIRED';
    error.error_code = 'AUTH_REQUIRED';
    error.platform = 'linkedin';
    error.login_url = `https://www.linkedin.com/login?fromSignIn=true&session_redirect=${encodeURIComponent(location.href)}`;
    throw error;
  }

  function dataType(job) {
    return String(job?.social_data_type || job?.command || 'profile').trim().toLowerCase();
  }

  function usernameFromUrl() {
    return decodeURIComponent(location.pathname.match(/^\/(?:in|company|showcase)\/([^/?#]+)/)?.[1] || '');
  }

  function cleanUsername(value) {
    const raw = String(value || '').trim().replace(/^@/, '');
    const fromUrl = raw.match(/linkedin\.com\/(?:in|company|showcase)\/([^/?#]+)/i)?.[1];
    return decodeURIComponent(fromUrl || raw.replace(/^(?:in|profile|company|showcase)[:/]/i, '').split(/[/?#]/)[0]);
  }

  function profileUrlFor(username) {
    const path = location.pathname.match(/^\/(?:in|company|showcase)\/[^/?#]+/)?.[0];
    return path ? `${location.origin}${path}/` : `https://www.linkedin.com/in/${encodeURIComponent(username)}/`;
  }

  function readProfile(username, url) {
    const body = helpers.cleanText(document.body?.innerText || '');
    const followers = countNearLabel(body, 'followers');
    const following = countNearLabel(body, 'following');
    const bio = firstText([
      '[data-test-id="about-us__description"]',
      '.org-top-card-summary-info-list',
      '.text-body-medium.break-words',
      '.pv-text-details__left-panel .text-body-medium',
      '[data-generated-suggestion-target]'
    ]) || helpers.cleanText(helpers.meta('og:description') || helpers.meta('description'));

    return {
      username,
      display_name: firstText([
        '[data-test-id="about-us__name"]',
        '.org-top-card-summary__title',
        'h1.text-heading-xlarge',
        'main h1',
        'h1'
      ]) || helpers.cleanText(helpers.meta('og:title')).replace(/\s*\|\s*LinkedIn.*$/i, '') || username,
      bio,
      description: bio,
      url,
      profile_url: url,
      avatar_url: firstUrl([
        ['.pv-top-card-profile-picture__image', 'src'],
        ['img.profile-photo-edit__preview', 'src'],
        ['.org-top-card-primary-content__logo', 'src'],
        ['[data-test-id="about-us__logo"] img', 'src'],
        ['meta[property="og:image"]', 'content']
      ]),
      cover_url: firstUrl([
        ['.profile-background-image__image-container img', 'src'],
        ['img.profile-background-image__image', 'src'],
        ['.org-top-card-primary-content__cover img', 'src']
      ]),
      followers_count: followers,
      total_followers: followers,
      following_count: following,
      total_following: following
    };
  }

  function countNearLabel(text, label) {
    return helpers.count(text.match(new RegExp(`[\\d,.]+\\s+${label}`, 'i'))?.[0] || '') || 0;
  }

  async function collectPostQueue(job) {
    const limit = helpers.limit(job, 'max_posts', 20, 100);
    const targetId = requestedId(job);
    const existing = existingIds(job);
    let offset = existing.size ? 0 : helpers.limit(job, 'post_offset', 0, 5000);
    const posts = [];
    const seen = new Set();
    let idle = 0;

    window.scrollTo({ top: 0, behavior: 'instant' });
    await helpers.delay(600);

    for (let scroll = 0; scroll < 45 && posts.length < limit; scroll += 1) {
      await stableValue(cardFingerprint, 3500, 2);
      const before = seen.size;

      for (const card of cards()) {
        const post = readCard(card);
        if (!post || seen.has(post.id)) continue;
        seen.add(post.id);
        if (targetId && post.id !== targetId) continue;
        if (existing.has(post.id) || existing.has(normalizePostUrl(post.url))) continue;
        if (offset > 0) {
          offset -= 1;
          continue;
        }
        posts.push(post);
        if (posts.length >= limit || targetId) break;
      }

      idle = seen.size === before ? idle + 1 : 0;
      if (posts.length >= limit || (targetId && posts.length) || idle >= 6) break;
      clickShowMore(document);
      window.scrollBy({ top: 2500, behavior: 'instant' });
      await helpers.delay(850);
    }
    return posts;
  }

  function cards() {
    const seen = new Set();
    return Array.from(document.querySelectorAll(POST_SELECTOR)).filter((card) => {
      if (!visible(card)) return false;
      const id = activityId(cardIdentity(card));
      if (!id || seen.has(id)) return false;
      seen.add(id);
      return true;
    });
  }

  function cardIdentity(card) {
    return card.getAttribute('data-urn')
      || card.getAttribute('data-activity-urn')
      || card.getAttribute('data-featured-activity-urn')
      || card.getAttribute('data-attributed-urn')
      || card.querySelector('[data-urn*="activity"]')?.getAttribute('data-urn')
      || postLink(card)?.href
      || '';
  }

  function cardFingerprint() {
    return cards().slice(0, 20).map((card) => {
      const post = readCard(card);
      return post ? `${post.id}:${post.title || post.image_url || post.media_url}` : '';
    }).filter(Boolean).join('|');
  }

  function readCard(card) {
    const id = activityId(cardIdentity(card));
    if (!id) return null;

    const text = postText(card);
    const media = mediaDetails(card);
    if (!text && !media.media_url && !media.image_url) return null;

    const url = cleanPostUrl(postLink(card)?.href || canonicalPostUrl(id));
    return {
      id,
      hash_id: id,
      title: text.slice(0, 140) || 'LinkedIn post',
      text,
      caption: text,
      url,
      post_url: url,
      created_at: firstText([
        'time[datetime]',
        '.update-components-actor__sub-description',
        '.feed-shared-actor__sub-description',
        'time'
      ], card),
      author: firstText([
        '[data-test-id="main-feed-activity-card__entity-lockup"] a[href]',
        'a[data-tracking-control-name*="feed-actor-name"]',
        '.update-components-actor__name',
        '.feed-shared-actor__name',
        '.update-components-actor__title'
      ], card),
      source: 'linkedin',
      likes_count: metric(card, [
        '[data-test-id="social-actions__reaction-count"]',
        '[data-id="social-actions__reactions"]',
        '.social-details-social-counts__reactions-count',
        'button[aria-label*="reaction" i]'
      ]),
      comments_count: metric(card, [
        'button[aria-label*="comment" i]',
        '.social-details-social-counts__comments'
      ]),
      shares: metric(card, [
        'button[aria-label*="repost" i]',
        '.social-details-social-counts__reposts'
      ]),
      collected_comments_count: 0,
      ...media,
      comment_items: [],
      comment_details: []
    };
  }

  function detailSeed(job) {
    const source = job?.detail_post && typeof job.detail_post === 'object' ? job.detail_post : {};
    const id = String(source.id || source.hash_id || requestedId(job) || currentPostId());
    const url = cleanPostUrl(source.url || source.post_url || canonicalPostUrl(id));
    return {
      ...source,
      id,
      hash_id: id,
      url,
      post_url: url,
      comment_items: [],
      comment_details: []
    };
  }

  async function enrichCurrentPost(post, job, withComments) {
    const root = await waitForPost(post.id);
    if (!root) return;

    const text = postText(root);
    if (text) {
      post.text = text;
      post.caption = text;
      post.title = text.slice(0, 140);
    }
    post.author = firstText([
      '[data-test-id="main-feed-activity-card__entity-lockup"] a[href]',
      'a[data-tracking-control-name*="feed-actor-name"]',
      '.update-components-actor__name',
      '.feed-shared-actor__name',
      '.update-components-actor__title'
    ], root) || post.author || '';
    post.created_at = firstText([
      '.update-components-actor__sub-description',
      '.feed-shared-actor__sub-description',
      'time'
    ], root) || post.created_at || '';
    post.likes_count = metric(root, [
      '[data-test-id="social-actions__reaction-count"]',
      '[data-id="social-actions__reactions"]',
      '.social-details-social-counts__reactions-count',
      'button[aria-label*="reaction" i]'
    ], post.likes_count);
    post.comments_count = metric(root, [
      'button[aria-label*="comment" i]',
      '.social-details-social-counts__comments'
    ], post.comments_count);
    post.shares = metric(root, [
      'button[aria-label*="repost" i]',
      '.social-details-social-counts__reposts'
    ], post.shares);

    Object.assign(post, mediaDetails(root));
    if (!withComments || helpers.limit(job, 'max_comments', 10, 100) === 0) return;

    const comments = await collectComments(root, job);
    post.comment_details = comments;
    post.comment_items = comments.map((comment) => comment.text);
    post.collected_comments_count = comments.length;
    const offset = helpers.limit(job, 'comment_offset', 0, 5000);
    post.comments_count = Math.max(Number(post.comments_count) || 0, offset + comments.length);
  }

  async function collectComments(root, job) {
    const offset = helpers.limit(job, 'comment_offset', 0, 5000);
    const limit = helpers.limit(job, 'max_comments', 10, 100);
    const target = offset + limit;
    const comments = [];
    const seen = new Set();
    let idle = 0;

    openComments(root);
    await helpers.delay(600);

    for (let scroll = 0; scroll < 35 && comments.length < target; scroll += 1) {
      const scope = commentScope(root);
      clickMoreComments(scope);
      const before = comments.length;

      for (const item of scope.querySelectorAll(COMMENT_SELECTOR)) {
        if (!visible(item)) continue;
        const text = firstText([
          '.comments-comment-item__main-content',
          '.comments-comment-item-content-body',
          '.comments-comment-item__inline-show-more-text',
          '.update-components-text'
        ], item);
        if (!text) continue;

        const sender = firstText([
          '.comments-post-meta__name-text',
          '.comments-comment-meta__description-title',
          '.comments-comment-item__commenter-name'
        ], item);
        const date = firstText(['time', '.comments-comment-item__timestamp'], item);
        const key = `${sender}|${date}|${text}`;
        if (seen.has(key)) continue;
        seen.add(key);
        comments.push({
          sender_name: sender,
          username: sender,
          text,
          date,
          likes: metric(item, ['button[aria-label*="reaction" i]'])
        });
        if (comments.length >= target) break;
      }

      idle = comments.length === before ? idle + 1 : 0;
      if (comments.length >= target || idle >= 6) break;
      scrollWithin(scope, 1800);
      await helpers.delay(650);
    }
    return comments.slice(offset, target);
  }

  function commentScope(root) {
    return Array.from(document.querySelectorAll('.artdeco-modal, .comments-comments-list')).find((node) => {
      return visible(node) && node.querySelector(COMMENT_SELECTOR);
    }) || root || document;
  }

  function openComments(root) {
    const button = Array.from(root.querySelectorAll('button, [role="button"]')).find((node) => {
      const label = `${node.getAttribute('aria-label') || ''} ${node.textContent || ''}`.toLowerCase();
      return visible(node) && label.includes('comment');
    });
    safeClick(button);
  }

  function clickMoreComments(scope) {
    for (const node of scope.querySelectorAll('button, [role="button"]')) {
      const label = `${node.getAttribute('aria-label') || ''} ${node.textContent || ''}`.toLowerCase();
      if (visible(node) && /more comments?|previous comments?|more repl|load more/.test(label)) safeClick(node);
    }
  }

  async function collectConnections(job, ownUsername) {
    const type = String(job?.connection_type || dataType(job)).toLowerCase();
    const limit = helpers.limit(job, type === 'followers' ? 'max_followers' : 'max_following', 100, 5000);
    const people = [];
    const seen = new Set();
    let idle = 0;

    window.scrollTo({ top: 0, behavior: 'instant' });
    for (let scroll = 0; scroll < 60 && people.length < limit; scroll += 1) {
      const before = seen.size;
      for (const item of connectionItems()) {
        const link = item.querySelector('a[href*="/in/"]');
        const url = cleanProfileUrl(link?.href || '');
        const username = cleanUsername(url);
        if (!username || username.toLowerCase() === ownUsername.toLowerCase() || seen.has(username)) continue;
        seen.add(username);
        people.push(username);
        if (people.length >= limit) break;
      }

      idle = seen.size === before ? idle + 1 : 0;
      if (people.length >= limit || idle >= 7) break;
      clickShowMore(document);
      window.scrollBy({ top: 2200, behavior: 'instant' });
      await helpers.delay(700);
    }
    return people;
  }

  function connectionItems() {
    const selector = [
      'li.reusable-search__result-container',
      '.reusable-search__result-container',
      '[data-chameleon-result-urn]',
      'li.mn-connection-card',
      '.mn-connection-card',
      '.artdeco-entity-lockup'
    ].join(',');
    return Array.from(document.querySelectorAll(selector)).filter((item) => {
      return visible(item) && item.querySelector('a[href*="/in/"]');
    });
  }

  function clickShowMore(scope) {
    const button = Array.from(scope.querySelectorAll('button, [role="button"]')).find((node) => {
      const label = `${node.getAttribute('aria-label') || ''} ${node.textContent || ''}`.toLowerCase();
      return visible(node) && /show more results|load more/.test(label);
    });
    safeClick(button);
  }

  function findActivityUrl(profileUrl) {
    const base = pathOf(profileUrl);
    const explicit = Array.from(document.querySelectorAll('a[href]')).map((node) => node.href).find((href) => {
      const path = pathOf(href);
      return path.startsWith(`${base}/`) && /\/(?:recent-activity\/(?:all|posts)|posts)\/?$/i.test(path);
    });
    if (explicit) return cleanUrl(explicit);
    if (/^\/in\//i.test(base)) return `${location.origin}${base}/recent-activity/all/`;
    if (/^\/(?:company|showcase)\//i.test(base)) return `${location.origin}${base}/posts/`;
    return '';
  }

  function findConnectionUrl(type) {
    return navigationUrl(Array.from(document.querySelectorAll('a[href]')).find((anchor) => {
      const label = `${anchor.getAttribute('aria-label') || ''} ${anchor.textContent || ''}`.toLowerCase();
      return visible(anchor) && new RegExp(`\\b${type}\\b`).test(label) && /linkedin\.com/i.test(anchor.href);
    })?.href || '');
  }

  async function waitForPost(id) {
    const ready = await stableValue(() => {
      const root = postRoot(id);
      if (!root) return '';
      return `${id || 'post'}:${postText(root) || mediaDetails(root).media_url || 'ready'}`;
    }, 10000, 2);
    return ready ? postRoot(id) : null;
  }

  function postRoot(id) {
    const roots = Array.from(document.querySelectorAll(`.artdeco-modal, ${POST_SELECTOR}, main`)).filter(visible);
    return roots.find((root) => activityId(cardIdentity(root)) === id)
      || (currentPostId() === id ? roots.find((root) => postText(root) || root.querySelector('video, img')) : null)
      || roots.find((root) => root.querySelector('[data-urn*="activity"], .update-components-text, .feed-shared-update-v2__description'))
      || null;
  }

  async function stableValue(reader, timeout, checksNeeded) {
    const started = Date.now();
    let previous = '';
    let checks = 0;
    while (Date.now() - started < timeout) {
      const value = helpers.cleanText(String(reader() || ''));
      checks = value && value === previous ? checks + 1 : (value ? 1 : 0);
      previous = value;
      if (value && checks >= checksNeeded) return value;
      await helpers.delay(300);
    }
    return '';
  }

  function postText(root) {
    return firstText([
      'p[data-test-id="main-feed-activity-card__commentary"]',
      '.attributed-text-segment-list__content',
      '[data-test-id="main-feed-activity-card__commentary"]',
      '.update-components-text',
      '.feed-shared-update-v2__description',
      '.break-words'
    ], root);
  }

  function postLink(root) {
    const wrapper = root.closest?.('[data-id="entire-feed-card-link"]')
      || root.closest?.('li')
      || root.parentElement
      || root;
    return Array.from(wrapper.querySelectorAll([
      'a[data-id="main-feed-card__full-link"]',
      'a.main-feed-card__overlay-link',
      'a[href*="/feed/update/urn:li:activity:"]',
      'a[href*="/posts/"]',
      'a[href*="activity-"]'
    ].join(','))).find((anchor) => activityId(anchor.href)) || null;
  }

  function activityId(value) {
    return String(value || '').match(/(?:urn:li:activity:|activity[-:])(\d{8,})/i)?.[1] || '';
  }

  function currentPostId() {
    return activityId(location.href);
  }

  function requestedId(job) {
    const value = String(job?.cursor?.hash_id || job?.hash_id || '').trim();
    return activityId(value) || value.split(/[/?#]/)[0];
  }

  function existingIds(job) {
    const values = Array.isArray(job?.cursor?.existing_post_urls) ? job.cursor.existing_post_urls : [];
    const ids = new Set();
    for (const value of values) {
      if (activityId(value)) ids.add(activityId(value));
      if (normalizePostUrl(value)) ids.add(normalizePostUrl(value));
    }
    return ids;
  }

  function canonicalPostUrl(id) {
    return id ? `https://www.linkedin.com/feed/update/urn:li:activity:${id}/` : '';
  }

  function cleanPostUrl(value) {
    const id = activityId(value);
    return id ? canonicalPostUrl(id) : cleanUrl(value);
  }

  function normalizePostUrl(value) {
    const id = activityId(value);
    return id ? `activity:${id}` : '';
  }

  function cleanProfileUrl(value) {
    try {
      const url = new URL(value, location.origin);
      const path = url.pathname.match(/^\/in\/[^/?#]+/)?.[0];
      return path ? `${url.origin}${path}/` : '';
    } catch (_error) {
      return '';
    }
  }

  function cleanUrl(value) {
    try {
      const url = new URL(value, location.origin);
      if (!/^https?:$/.test(url.protocol)) return '';
      url.search = '';
      url.hash = '';
      return url.toString();
    } catch (_error) {
      return '';
    }
  }

  function navigationUrl(value) {
    try {
      const url = new URL(value, location.origin);
      if (!/^https?:$/.test(url.protocol)) return '';
      url.hash = '';
      return url.toString();
    } catch (_error) {
      return '';
    }
  }

  function pathOf(value) {
    try {
      return new URL(value, location.origin).pathname.replace(/\/$/, '').toLowerCase();
    } catch (_error) {
      return '';
    }
  }

  function mediaDetails(root) {
    const image = bestImage(root);
    const video = Array.from(root.querySelectorAll('video')).find(visible);
    const videoUrl = helpers.absoluteUrl(
      video?.currentSrc
      || video?.src
      || video?.querySelector('source[src]')?.src
      || ''
    );
    const poster = helpers.absoluteUrl(video?.poster || image || '');
    if (/^https?:\/\//i.test(videoUrl)) {
      return {
        media_type: 'video',
        media_url: videoUrl,
        image_url: poster,
        thumbnail: poster
      };
    }
    if (/^https?:\/\//i.test(poster)) {
      return {
        media_type: video ? 'video' : 'image',
        media_url: poster,
        image_url: poster,
        thumbnail: poster
      };
    }
    return { media_type: '', media_url: '', image_url: '', thumbnail: '' };
  }

  function bestImage(root) {
    const images = Array.from(root.querySelectorAll([
      '[data-test-id="feed-images-content"] img',
      '.feed-images-content img',
      '.update-components-image__image',
      '.feed-shared-image__image',
      'img[src]',
      'img[data-delayed-url]',
      'img[data-ghost-url]'
    ].join(','))).filter((image) => {
      if (!visible(image)) return false;
      const width = image.naturalWidth || image.width || 0;
      const height = image.naturalHeight || image.height || 0;
      const label = `${image.alt || ''} ${image.className || ''}`.toLowerCase();
      return width >= 180 && height >= 100 && !/(profile|avatar|logo|emoji)/.test(label);
    }).sort((left, right) => imageArea(right) - imageArea(left));
    const image = images[0];
    return helpers.absoluteUrl(
      image?.currentSrc
      || image?.src
      || image?.getAttribute('data-delayed-url')
      || image?.getAttribute('data-ghost-url')
      || ''
    );
  }

  function imageArea(node) {
    return (node.naturalWidth || node.width || 0) * (node.naturalHeight || node.height || 0);
  }

  function metric(root, selectors, fallback = 0) {
    for (const selector of selectors) {
      const node = root.querySelector(selector);
      const value = helpers.count(
        node?.getAttribute('data-num-reactions')
        || node?.getAttribute('aria-label')
        || node?.textContent
        || ''
      );
      if (value) return value;
    }
    return Number(fallback) || 0;
  }

  function firstText(selectors, root = document) {
    for (const selector of selectors) {
      const value = helpers.cleanText(root.querySelector(selector)?.textContent || '');
      if (value) return value;
    }
    return '';
  }

  function firstUrl(entries, root = document) {
    for (const [selector, attribute] of entries) {
      const node = root.querySelector(selector);
      const value = helpers.absoluteUrl(node?.getAttribute(attribute) || node?.[attribute] || '');
      if (/^https?:\/\//i.test(value)) return value;
    }
    return '';
  }

  function makeResult(username, url, profile, posts, job, followers, following) {
    return {
      platform: 'linkedin',
      username,
      url,
      profile,
      posts,
      videos: [],
      shorts: [],
      images: posts.filter((post) => /^https?:\/\//i.test(post.image_url || '')).map((post) => ({
        image_url: post.image_url,
        thumbnail: post.thumbnail,
        source_url: post.url,
        title: post.title,
        source: 'linkedin'
      })).slice(0, helpers.limit(job, 'max_images', 25, 100)),
      followers: followers || [],
      following: following || []
    };
  }

  function scrollWithin(scope, amount) {
    const scrollable = Array.from(scope.querySelectorAll?.('.comments-comments-list, .artdeco-modal__content') || [])
      .find((node) => visible(node) && node.scrollHeight > node.clientHeight + 20);
    (scrollable || window).scrollBy({ top: amount, behavior: 'instant' });
  }

  function safeClick(node) {
    try {
      node?.click();
    } catch (_error) {
      // LinkedIn frequently replaces controls while loading.
    }
  }

  function visible(node) {
    if (!node) return false;
    const rect = node.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }
})();

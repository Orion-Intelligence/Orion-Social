(function () {
  "use strict";

  const helpers = window.OrionScraperHelpers;
  const POST_LINK_SELECTOR = [
    'a[href*="/groups/"][href*="/posts/"]',
    'a[href*="/posts/"]',
    'a[href*="/permalink/"]',
    'a[href*="/permalink.php"]',
    'a[href*="/story.php"]',
    'a[href*="story_fbid="]',
    'a[href*="multi_permalinks="]',
    'a[href*="fbid="]',
    'a[href*="/share/"]',
    'a[href*="/reel/"]',
    'a[href*="/videos/"]',
    'a[href*="/watch/"]',
    'a[href*="/photo.php"]',
    'a[href*="/photos/"]',
    'a[href*="/events/"]',
    'a[href*="/marketplace/item/"]'
  ].join(",");
  const MESSAGE_SELECTOR = [
    '[data-ad-rendering-role="story_message"]',
    '[data-ad-preview="message"]',
    '[data-ad-comet-preview="message"]',
    '[data-testid="post_message"]',
    'div[dir="auto"][style*="text-align"]'
  ].join(",");
  const MEDIA_SELECTOR = [
    'img[data-imgperflogname="feedImage"]',
    'img[src*="scontent"]',
    'img[referrerpolicy="origin-when-cross-origin"]'
  ].join(",");
  const COMMENT_SELECTOR = [
    '[aria-label^="Comment by" i]',
    '[aria-label^="Reply by" i]',
    '[data-commentid]',
    '[data-testid*="comment" i]'
  ].join(",");
  const PROFILE_BLOCKLIST = new Set([
    "about", "ads", "bookmarks", "business", "events", "friends", "followers",
    "following", "gaming", "groups", "help", "home.php", "login", "marketplace",
    "messages", "notifications", "pages", "photo.php", "photos", "privacy",
    "reel", "reels", "search", "settings", "share", "story.php", "videos", "watch"
  ]);

  window.OrionScrapers = window.OrionScrapers || {};
  window.OrionScrapers.facebook = {
    selectors: ['main', '[role="main"]', '[role="feed"]', POST_LINK_SELECTOR],

    async run(job) {
      if (!helpers) throw new Error("OrionScraperHelpers is unavailable");
      assertFacebookAccess();

      const command = helpers.command(job) || "profile_info";
      const username = cleanUsername(job?.username || job?.requested_username || usernameFromUrl());
      const profileUrl = profileUrlFor(username, job?.profile_url || job?.url || location.href);
      const profile = readProfile(username, profileUrl);
      const mediaLimit = helpers.limit(job, "max_media", 20, 200);
      const photosLimit = helpers.limit(job, "max_photos", mediaLimit, 200);
      const reelsLimit = helpers.limit(job, "max_reels", mediaLimit, 200);
      const videosLimit = helpers.limit(job, "max_videos", mediaLimit, 200);
      const state = {
        posts: [], friends: [], followers: [], following: [],
        about: {}, photos: [], reels: [], videos_tab: [],
        reviews: [], events: [], groups: [], community: [],
        mentions: [], discovered_tabs: [], tabs: []
      };

      try { state.tabs = discoverTabs(username); } catch (_e) {}

      if (["friends", "followers", "following"].includes(command)) {
        state[command] = await collectConnections(profileUrl, command, connectionLimit(job, command));
      } else if (command === "about") {
        state.about = await collectAbout(username, profileUrl);
      } else if (command === "photos") {
        state.photos = await collectPhotosTab(username, profileUrl, photosLimit);
      } else if (command === "reels") {
        state.reels = await collectReelsTab(username, profileUrl, reelsLimit);
      } else if (command === "videos") {
        state.videos_tab = await collectVideosTab(username, profileUrl, videosLimit);
      } else if (command === "reviews") {
        state.reviews = await collectReviews(username, profileUrl, 100);
      } else if (!job?.skip_details && requestedPostId(job)) {
        const detail = await collectCurrentPostDetail(job);
        state.posts = detail ? [detail] : [];
      } else {
        // Full profile scrape: posts + all sections
        state.posts = await collectPostQueue(job, { profileUrl, username, displayName: profile.display_name });
        try { state.about = await collectAbout(username, profileUrl); } catch (_e) {}
        try { state.photos = await collectPhotosTab(username, profileUrl, photosLimit); } catch (_e) {}
        try { state.reels = await collectReelsTab(username, profileUrl, reelsLimit); } catch (_e) {}
        try { state.videos_tab = await collectVideosTab(username, profileUrl, videosLimit); } catch (_e) {}
        try { state.reviews = await collectReviews(username, profileUrl, 100); } catch (_e) {}
        for (const tabKey of ["events", "groups", "community", "mentions"]) {
          try { state[tabKey] = await collectGenericTab(username, profileUrl, tabKey, 50); } catch (_e) {}
        }
        // Collect any dynamically discovered tabs not already handled
        const handled = new Set(["posts","about","photos","reels","videos","reviews","events","groups","community","mentions","friends","followers","following"]);
        for (const tab of state.tabs) {
          if (handled.has(tab.key)) continue;
          try {
            const items = await collectGenericTab(username, profileUrl, tab.key, 30);
            if (items.length) state.discovered_tabs.push({ key: tab.key, label: tab.label, items });
          } catch (_e) {}
        }
      }

      return buildResult(username, profileUrl, profile, state, job);
    }
  };

  function assertFacebookAccess() {
    const path = location.pathname.toLowerCase();
    const text = cleanText(document.body?.innerText || "").toLowerCase();
    const login = /\/(?:login|checkpoint|recover)\b/.test(path)
      || document.querySelector('input[name="email"], input[name="pass"], form[action*="/login"]');
    const hasPage = document.querySelector('main, [role="main"], h1, ' + POST_LINK_SELECTOR);
    if (!login || hasPage) return;
    const error = new Error("Facebook login is required. Log in in this browser and retry.");
    error.code = "AUTH_REQUIRED";
    error.error_code = "AUTH_REQUIRED";
    error.platform = "facebook";
    error.login_url = `https://www.facebook.com/login/?next=${encodeURIComponent(location.href)}`;
    if (/log in|sign up|create new account|forgot password/.test(text)) throw error;
  }

  async function collectPostQueue(job, owner) {
    const offsetValue = helpers.limit(job, "post_offset", 0, 5000);
    const target = requestedPostId(job);
    const existing = existingPostIds(job);
    const requestedLimit = helpers.limit(job, "max_posts", 20, 100);
    const nextBatchSize = helpers.limit(job, "next_posts", 5, 20) || 5;
    const limit = existing.size || offsetValue > 0 ? Math.min(requestedLimit || nextBatchSize, nextBatchSize) : requestedLimit;
    let offset = existing.size ? 0 : offsetValue;
    const posts = [];
    const seen = new Set();
    let idle = 0;
    const cardMap = new Map();

    await ensurePostsSurface(owner.profileUrl);
    window.scrollTo({ top: 0, behavior: "instant" });
    await delay(800);

    for (let round = 0; round < 55 && posts.length < limit; round += 1) {
      expandVisibleText(document);
      const before = seen.size;

      for (const card of postCards()) {
        const post = await readPostCard(card);
        if (!post?.id || !post.url || seen.has(post.id) || seen.has(post.url)) continue;
        if (posts.some((p) => p.id === post.id || p.url === post.url || (p.text && post.text && p.text === post.text && p.created_at === post.created_at))) continue;
        seen.add(post.id);
        seen.add(post.url);
        if (target && post.id !== target) continue;
        if (!target && !postBelongsToOwner(post, card, owner)) continue;
        if (existing.has(post.id) || existing.has(post.url)) continue;
        if (offset > 0) {
          offset -= 1;
          continue;
        }
        posts.push(post);
        cardMap.set(post.id, card);
        if (posts.length >= limit || target) break;
      }

      if (posts.length < limit && !target) {
        for (const entry of rankedPostLinks(centerRoot() || document)) {
          const root = postContainer(entry.anchor);
          if (!root || isHeaderOrCoverNode(root) || isHeaderOrCoverNode(entry.anchor)) continue;
          const post = await readPostCard(root, entry.url, entry.anchor);
          if (!post?.id || !post.url || seen.has(post.id) || seen.has(post.url)) continue;
          if (posts.some((p) => p.id === post.id || p.url === post.url || (p.text && post.text && p.text === post.text && p.created_at === post.created_at))) continue;
          seen.add(post.id);
          seen.add(post.url);
          if (!postBelongsToOwner(post, root, owner)) continue;
          if (existing.has(post.id) || existing.has(post.url)) continue;
          if (offset > 0) {
            offset -= 1;
            continue;
          }
          posts.push(post);
          cardMap.set(post.id, root);
          if (posts.length >= limit) break;
        }
      }

      idle = seen.size === before ? idle + 1 : 0;
      if (posts.length >= limit || (target && posts.length) || idle >= 4) break;
      clickLoadMorePosts();
      scrollPage(randomBetween(900, 2600));
      await delay(randomBetween(600, 1100));
    }

    const finalPosts = posts.slice(0, limit);

    // Enrich posts with inline comments if details are not being skipped
    if (!job?.skip_details) {
      const commentLimit = helpers.limit(job, "max_comments", 50, 200) || helpers.limit(job, "max_comments_per_post", 50, 200) || 50;
      const commentOffset = helpers.limit(job, "comment_offset", 0, 5000);
      const deadline = Date.now() + 180000; // 180 seconds max for post comment collection
      for (const post of finalPosts) {
        if (Date.now() > deadline) break;
        try {
          const card = cardMap.get(post.id);
          if (!card || commentLimit <= 0) continue;
          await enrichPostInline(post, card, commentOffset, commentLimit);
        } catch (_error) {
          // Keep post data even if inline comment collection fails.
        }
      }
    }

    return finalPosts;
  }

  async function enrichPostInline(post, card, offset, limit) {
    const scrollState = { x: window.scrollX, y: window.scrollY };
    try {
      card.scrollIntoView?.({ block: "center", behavior: "instant" });
      await delay(400);
      await openComments(card);
      await selectAllComments(card);
      const scope = commentScope(card);
      await waitFor(() => commentNodes(scope).length > 0 || scope.querySelector(COMMENT_SELECTOR), 4000);
      const comments = await collectComments(card, offset, limit);
      post.comment_details = comments;
      post.loaded_comments = comments;
      post.comment_items = comments.map((c) => c.text);
      post.collected_comments_count = comments.length;
      post.comments_count = Math.max(Number(post.comments_count) || 0, offset + comments.length);
      post.comments = post.comments_count;
    } finally {
      // Close any popup/dialog that may have opened
      const dialog = Array.from(document.querySelectorAll('div[role="dialog"]')).filter(visible).pop();
      if (dialog) {
        const close = dialog.querySelector('[aria-label="Close" i], [aria-label="close" i]');
        safeClick(close);
        await delay(400);
      }
      window.scrollTo({ left: scrollState.x, top: scrollState.y, behavior: "instant" });
    }
  }

  async function ensurePostsSurface(profileUrl) {
    if (!sameProfile(location.href, profileUrl)) return false;
    if (rankedPostLinks(centerRoot() || document).length) return true;
    const link = Array.from(document.querySelectorAll('a[href], [role="tab"], [role="link"]'))
      .filter(visible)
      .find((node) => {
        const label = cleanText(`${node.getAttribute("aria-label") || ""} ${node.textContent || ""}`).toLowerCase();
        const href = node.getAttribute?.("href") || "";
        return label === "posts" || /^posts\b/.test(label)
          || (sameProfile(href, profileUrl) && /\/posts(?:[/?#]|$)|[?&]sk=posts\b/i.test(href));
      });
    if (!link) return false;
    safeClick(link);
    await waitFor(() => rankedPostLinks(centerRoot() || document).length > 0, 10000);
    return true;
  }

  function postBelongsToOwner(post, root, owner) {
    if (!owner?.profileUrl) return true;
    if (!sameProfile(location.href, owner.profileUrl)) return false;

    // If we are scraping a Page or Profile feed directly (location.href is on that profile),
    // timeline cards belong to the owner unless explicitly from another source.
    if (sameProfile(location.href, owner.profileUrl)) return true;

    const authorUrl = post.author_url || readAuthorUrl(root);
    if (authorUrl && sameProfile(authorUrl, owner.profileUrl)) return true;

    const author = normalizeName(post.author || readAuthor(root));
    const display = normalizeName(owner.displayName);
    const username = normalizeName(owner.username);
    if (author && display && (author.includes(display) || display.includes(author))) return true;
    if (author && username && (author.includes(username) || username.includes(author))) return true;

    // If Facebook hides the author link on the profile timeline, keep cards whose
    // nearest profile post link is on the requested profile route.
    const linkProfiles = rankedPostLinks(root)
      .map((entry) => ownerProfileFromPostUrl(entry.url))
      .filter(Boolean);
    if (linkProfiles.some((url) => sameProfile(url, owner.profileUrl))) return true;
    return true;
  }

  async function collectCurrentPostDetail(job) {
    const url = normalizePostUrl(job?.url || location.href);
    const id = requestedPostId(job) || postId(url);
    const root = await waitForPostRoot(id, url, 14000) || centerRoot() || document.body;
    if (!root || !url) return null;

    let post = await readPostCard(root, url);
    if (!post) post = await fallbackPost(root, url, id);
    if (!post) return null;

    await enrichPost(post, job);
    return post;
  }

  async function enrichPost(post, job) {
    const root = await waitForPostRoot(post.id, post.url, 10000) || centerRoot() || document.body;
    expandVisibleText(root);
    const detail = await readPostCard(root, post.url);
    if (detail) mergePost(post, detail);

    const limit = helpers.limit(job, "max_comments", 50, 200) || helpers.limit(job, "max_comments_per_post", 50, 200) || 50;
    if (limit <= 0) return;
    const offset = helpers.limit(job, "comment_offset", 0, 5000);
    const comments = await collectComments(root, offset, limit);
    post.comment_details = comments;
    post.loaded_comments = comments;
    post.comment_items = comments.map((comment) => comment.text);
    post.collected_comments_count = comments.length;
    post.comments_count = Math.max(Number(post.comments_count) || 0, offset + comments.length);
    post.comments = post.comments_count;
  }

  async function readPostCard(root, forcedUrl = "", sourceAnchor = null) {
    if (!root || isHeaderOrCoverNode(root) || isHeaderOrCoverNode(sourceAnchor)) return null;
    const url = normalizePostUrl(forcedUrl || rankedPostLinks(root)[0]?.url || "");
    if (!url || isHeaderOrCoverUrl(url)) return null;

    expandVisibleText(root);
    const media = await readMedia(root);
    const counts = readMetrics(root);
    const author = readAuthor(root);
    const authorUrl = readAuthorUrl(root);
    const caption = readCaption(root) || cleanContent(sourceAnchor?.getAttribute?.("aria-label") || sourceAnchor?.textContent || "");
    const attachment = readAttachment(root);
    const type = postType(url, root, media);
    const title = caption.slice(0, 180)
      || attachment.title
      || cleanText(sourceAnchor?.getAttribute?.("aria-label") || sourceAnchor?.textContent)
      || `${author || "Facebook"} ${type}`;
    const id = postId(url);

    const rawDate = readDate(root);
    if (/set=pb\.|set=pob|set=ecnf\.|set=pcb\./i.test(url)) return null;
    if (/^(?:photos|intro|details|about|community)$/i.test(cleanText(author))) return null;
    if (/^(?:details\n|intro\n|photos\nsee all|communities\n)/i.test(caption || title)) return null;
    if (/^(?:cover photo|profile picture|update cover photo|updated (?:his|her|their) cover photo)/i.test(caption || title)) return null;
    if (!rawDate && !counts.likes && !counts.comments && !counts.shares && (title === "Facebook photo" || !caption)) return null;
    return {
      id,
      hash_id: id,
      title,
      caption,
      text: caption || attachment.description || title,
      url,
      post_url: url,
      created_at: rawDate,
      author,
      author_url: authorUrl,
      author_username: profileSlug(authorUrl),
      source: "facebook",
      media_type: type,
      media_url: media.thumbnail || media.images[0] || media.video_url || "",
      image_url: media.thumbnail || media.images[0] || "",
      thumbnail: media.thumbnail || media.images[0] || "",
      images: media.images,
      image_urls: media.images,
      video_url: media.video_url,
      attachment_urls: media.attachment_urls,
      attachment_title: attachment.title,
      attachment_description: attachment.description,
      m_title: author || title,
      date: parseDateIso(rawDate),
      content: caption || attachment.description || title,
      likes: counts.likes,
      comments: counts.comments,
      shares: counts.shares,
      type,
      videos: media.video_url ? [media.video_url] : [],
      video_blobs: media.video_blobs || 0,
      likes_count: counts.likes,
      comments_count: counts.comments,
      shares_count: counts.shares,
      views_count: counts.views,
      collected_comments_count: 0,
      comment_items: [],
      comment_details: [],
      loaded_comments: []
    };
  }

  async function fallbackPost(root, url, id) {
    const media = await readMedia(root);
    const counts = readMetrics(root);
    const caption = readCaption(root) || cleanContent(root.innerText || root.textContent || "");
    const title = caption.slice(0, 180) || "Facebook post";
    const authorUrl = readAuthorUrl(root);
    const rawDate = readDate(root);
    const type = postType(url, root, media);
    const author = readAuthor(root);
    return {
      id: id || postId(url),
      hash_id: id || postId(url),
      title,
      caption,
      text: caption || title,
      url,
      post_url: url,
      created_at: rawDate,
      author,
      author_url: authorUrl,
      author_username: profileSlug(authorUrl),
      source: "facebook",
      media_type: type,
      media_url: media.thumbnail || media.images[0] || media.video_url || "",
      image_url: media.thumbnail || media.images[0] || "",
      thumbnail: media.thumbnail || media.images[0] || "",
      images: media.images,
      image_urls: media.images,
      video_url: media.video_url,
      attachment_urls: media.attachment_urls,
      m_title: author || title,
      date: parseDateIso(rawDate),
      content: caption || title,
      likes: counts.likes,
      comments: counts.comments,
      shares: counts.shares,
      type,
      videos: media.video_url ? [media.video_url] : [],
      video_blobs: media.video_blobs || 0,
      likes_count: counts.likes,
      comments_count: counts.comments,
      shares_count: counts.shares,
      views_count: counts.views,
      collected_comments_count: 0,
      comment_items: [],
      comment_details: [],
      loaded_comments: []
    };
  }

  async function collectComments(root, offset = 0, limit = 50) {
    const target = offset + limit;
    const comments = [];
    const seen = new Set();
    let idle = 0;

    await openComments(root);
    await selectAllComments(root);
    await delay(400);

    for (let round = 0; round < 35 && comments.length < target; round += 1) {
      const scope = commentScope(root);
      expandCommentControls(scope);
      expandVisibleText(scope, true);
      await delay(300);

      const before = comments.length;

      for (const node of commentNodes(scope)) {
        const comment = readComment(node);
        if (!comment?.text) continue;
        const key = `${comment.sender_name}|${comment.date}|${comment.text}`;
        if (seen.has(key)) continue;
        seen.add(key);
        comments.push(comment);
        if (comments.length >= target) break;
      }

      idle = comments.length === before ? idle + 1 : 0;
      if (comments.length >= target || idle >= 6) break;
      scrollComments(scope, 600);
      await delay(500);
    }

    return comments.slice(offset, target);
  }

  async function openComments(root) {
    const controls = Array.from((root || document).querySelectorAll('a[href], button, [role="button"], span[role="button"], div[role="button"]'))
      .filter(visible)
      .filter((node) => {
        const label = cleanText(`${node.getAttribute("aria-label") || ""} ${node.textContent || ""}`).toLowerCase();
        return /\bcomments?\b/.test(label)
          && !/write a comment|add a comment|comment as|reply/i.test(label);
      });
    const button = controls.find((node) => /\d|view|show|open|comment/.test(cleanText(`${node.getAttribute("aria-label") || ""} ${node.textContent || ""}`).toLowerCase()));
    if (button) safeClick(button);
    await waitFor(() => commentNodes(commentScope(root)).length > 0 || visibleOverlayOrDialog(), 3000);
  }

  async function selectAllComments(root) {
    const scope = commentScope(root);
    const sort = Array.from(scope.querySelectorAll('button, [role="button"], div[role="button"], span')).find((node) => {
      const label = cleanText(`${node.getAttribute("aria-label") || ""} ${node.textContent || ""}`).toLowerCase();
      return visible(node) && /most relevant|newest|all comments|top comments/i.test(label);
    });
    if (!sort) return;
    safeClick(sort);
    await delay(400);
    const all = Array.from(document.querySelectorAll('[role="menuitem"], [role="option"], span, div'))
      .find((node) => visible(node) && /^all comments$/i.test(cleanText(node.textContent || "")));
    if (all) {
      safeClick(all);
      await delay(600);
    }
  }

  function expandCommentControls(scope) {
    if (!scope) return;
    const controls = Array.from(scope.querySelectorAll('button, [role="button"], span[role="button"], a[href], div[role="button"], div[dir="auto"], span[dir="auto"]'));
    let clicked = 0;
    for (const node of controls) {
      if (!visible(node)) continue;
      const label = cleanText(`${node.getAttribute("aria-label") || ""} ${node.getAttribute("title") || ""} ${node.textContent || ""}`).toLowerCase();
      if (!label || label.length > 90) continue;
      if (/write a comment|add a comment|comment as|reply to/i.test(label)) continue;
      if (/(?:view|show|see|load)\s+(?:all\s+)?(?:(?:more|previous)\s+)?(?:comments?|replies?)|more comments?|previous comments?|view\s+\d+\s+(?:more\s+)?(?:comments?|replies?)|see\s+\d+\s+more\s+comments?|\d+\s+replies/i.test(label)) {
        safeClick(node);
        clicked += 1;
        if (clicked >= 15) break;
      }
    }
  }

  function commentScope(root) {
    const dialogs = Array.from(document.querySelectorAll('div[role="dialog"]')).filter(visible);
    const dialog = dialogs.reverse().find((node) => node.querySelector(COMMENT_SELECTOR) || /comment/i.test(cleanText(node.innerText || "")));
    return dialog || root || centerRoot() || document;
  }

  function commentNodes(scope) {
    const nodes = [];
    const add = (node) => {
      if (node && !nodes.includes(node) && visible(node)) nodes.push(node);
    };
    for (const node of scope.querySelectorAll(COMMENT_SELECTOR)) add(node);
    for (const article of scope.querySelectorAll('[role="article"]')) {
      const label = cleanText(article.getAttribute("aria-label"));
      const text = cleanText(article.innerText || article.textContent || "");
      if (/^(?:comment|reply) by/i.test(label) || (/\blike\b/i.test(text) && /\breply\b/i.test(text))) add(article);
    }
    return nodes.filter((node) => {
      if (node === scope) return false;
      const label = cleanText(node.getAttribute("aria-label"));
      const text = cleanText(node.innerText || node.textContent || "");
      if (!text || /write a comment|most relevant|all comments|view more comments/i.test(text)) return false;
      if (/actions for this post/i.test(text)) return false;
      return /^(?:comment|reply) by/i.test(label)
        || node.hasAttribute("data-commentid")
        || (/\blike\b/i.test(text) && /\breply\b/i.test(text) && text.length < 1200);
    });
  }

  function readComment(node) {
    const label = cleanText(node.getAttribute("aria-label"));
    let rawSender = label.match(/^(?:Comment|Reply) by\s+(.+?)(?:\s+Top fan|\s+Author|$)/i)?.[1]
      || firstText([
        'a[role="link"] strong',
        'strong',
        'h3',
        'h4',
        'a[role="link"] span[dir="auto"]'
      ], node);

    if (!rawSender) {
      const authorAnchor = node.querySelector('a[href*="/user/"], a[href*="profile.php"], a[role="link"]');
      if (authorAnchor) {
        rawSender = cleanText(authorAnchor.textContent || "");
      }
    }

    let sender = cleanText(rawSender || "");
    let date = firstText(['a[href*="comment_id"]', 'abbr', 'time'], node);

    const timeMatch = sender.match(/\s+(?:about\s+|nearly\s+)?(?:\d+|an?)\s+(?:sec|second|min|minute|hr|hour|day|week|month|year)s?\s+ago$/i)
      || sender.match(/\s+(?:just now|yesterday(?:\s+at\s+[\d:]+\s*(?:am|pm)?)?|\d{1,2}\s+[a-z]{3}(?:\s+\d{4})?|\d+[smhdwy])$/i);

    if (timeMatch) {
      if (!date) {
        date = cleanText(timeMatch[0]);
      }
      sender = cleanText(sender.slice(0, timeMatch.index));
    }

    if (!date) {
      const timeSpan = Array.from(node.querySelectorAll('a, span, div'))
        .map((el) => cleanText(el.textContent || ""))
        .find((val) => /^(?:just now|yesterday(?:\s+at\s+[\d:]+\s*(?:am|pm)?)?|\d+\s*(?:s|m|h|d|w|y)|(?:about\s+|nearly\s+)?(?:\d+|an?)\s+(?:sec|second|min|minute|hr|hour|day|week|month|year)s?\s+ago)$/i.test(val));
      if (timeSpan) date = timeSpan;
    }

    const likes = count(
      Array.from(node.querySelectorAll('[aria-label*="like" i], [aria-label*="reaction" i]'))
        .map((item) => item.getAttribute("aria-label") || "")
        .find((value) => /\d/.test(value)) || ""
    );

    const blocked = new Set(
      [sender, rawSender, date, "top fan", "author", "follow", "reply", "like", "share"]
        .filter(Boolean)
        .map((line) => line.toLowerCase())
    );

    for (const anchor of node.querySelectorAll('a[role="link"], a[href]')) {
      const anchorText = cleanText(anchor.textContent || "").toLowerCase();
      if (anchorText && anchorText.length < 80) {
        blocked.add(anchorText);
      }
    }

    const lines = Array.from(node.querySelectorAll('div[dir="auto"], span[dir="auto"]'))
      .filter((item) => !item.closest('a, button, [role="button"]'))
      .map((item) => cleanText(item.textContent || ""))
      .filter(Boolean)
      .filter((line, index, list) => list.indexOf(line) === index)
      .filter((line) => !blocked.has(line.toLowerCase()))
      .filter((line) => !isCommentNoise(line));

    const fallbackLines = String(node.innerText || node.textContent || "")
      .split(/\n|(?<=\S)\s{2,}/)
      .map(cleanText)
      .filter(Boolean)
      .filter((line) => !blocked.has(line.toLowerCase()))
      .filter((line) => !isCommentNoise(line));

    const text = (lines.find((line) => line.length > 0) || fallbackLines.find((line) => line.length > 0) || "").slice(0, 3000);

    return {
      sender_name: sender,
      username: sender,
      text,
      date,
      likes
    };
  }

  async function collectConnections(profileUrl, type, limit) {
    const tabKey = type === "followers" ? "followers" : type === "following" ? "following" : "friends";
    const tab = discoverTabs(usernameFromUrl()).find((t) => t.key === tabKey || t.key === "friends");

    if (tab) {
      await navigateToTab(tab);
    } else {
      const targetUrl = `${profileUrl.replace(/\/$/, "")}/${tabKey}`;
      await navigateToUrl(targetUrl);
    }
    await delay(800);

    if (type === "followers" || type === "following") {
      const subTab = Array.from(document.querySelectorAll('a[href], [role="tab"], [role="link"]'))
        .filter(visible)
        .find((el) => {
          const text = cleanText(`${el.getAttribute("aria-label") || ""} ${el.textContent || ""}`).toLowerCase();
          const href = el.getAttribute("href") || "";
          return text === type || href.includes(`sk=${type}`) || href.includes(`/${type}`);
        });
      if (subTab) {
        safeClick(subTab);
        await delay(800);
      }
    }

    const results = [];
    const seen = new Set();
    let idle = 0;

    window.scrollTo({ top: 0, behavior: "instant" });
    await delay(600);
    for (let round = 0; round < 60 && results.length < limit; round += 1) {
      const before = results.length;
      for (const anchor of connectionAnchors()) {
        const url = normalizeProfileUrl(anchor.href);
        if (!url || sameProfile(url, profileUrl) || seen.has(url)) continue;
        const card = connectionCard(anchor);
        const name = connectionName(anchor, card);
        if (!isPersonName(name)) continue;
        const image = largestImage(card, 32, 32);
        seen.add(url);
        results.push({
          username: profileSlug(url),
          display_name: name,
          name,
          url,
          profile_url: url,
          avatar_url: image,
          relationship_type: type,
          source: "facebook"
        });
        if (results.length >= limit) break;
      }
      idle = results.length === before ? idle + 1 : 0;
      if (results.length >= limit || idle >= 8) break;
      scrollPage(1400);
      await delay(900);
    }
    await navigateToUrl(profileUrl);
    return results;
  }

  function connectionAnchors() {
    return Array.from((centerRoot() || document).querySelectorAll('a[href]'))
      .filter(visible)
      .filter((anchor) => normalizeProfileUrl(anchor.href));
  }

  function connectionCard(anchor) {
    const explicit = anchor.closest('[role="listitem"], [role="article"]');
    if (explicit) return explicit;
    let best = anchor;
    for (let node = anchor.parentElement; node && node !== document.body; node = node.parentElement) {
      const rect = node.getBoundingClientRect();
      if (!visible(node) || rect.width < 180 || rect.height < 35 || rect.height > 420) continue;
      best = node;
      if (node.querySelector("img") && cleanText(node.innerText || node.textContent).length > 2) break;
    }
    return best;
  }

  function connectionName(anchor, card) {
    const aria = cleanText(anchor.getAttribute("aria-label") || "")
      .replace(/^View\s+/i, "")
      .replace(/\s+(?:profile|page)$/i, "");
    if (isPersonName(aria)) return aria;
    const linkText = firstText([
      'span[aria-hidden="true"]',
      'strong',
      'h2',
      'h3'
    ], anchor);
    if (isPersonName(linkText)) return linkText;
    const lines = String(card?.innerText || card?.textContent || anchor.textContent || "")
      .split("\n")
      .map(cleanText)
      .filter(Boolean);
    return lines.find(isPersonName) || "";
  }

  function isHeaderOrCoverNode(node) {
    if (!node || typeof node.closest !== "function") return false;
    return Boolean(
      node.closest('[data-pagelet*="Cover" i], [data-pagelet*="Header" i], [aria-label*="cover photo" i], [aria-label*="profile header" i], [data-pagelet="ProfileTimelineHeader"]')
      || node.querySelector?.('img[data-imgperflogname="profileCoverPhoto"]')
      || (node.getAttribute?.("data-pagelet") && /cover|header/i.test(node.getAttribute("data-pagelet")))
    );
  }

  function isHeaderOrCoverUrl(url) {
    const s = String(url || "");
    return /set=ecnf\.|set=pcb\.|set=pb\.|set=pob\.|profile_cover|cover_photo/i.test(s);
  }

  function postCards() {
    const root = centerRoot() || document;
    const found = [];
    const add = (node) => {
      if (!node || found.includes(node) || !visible(node)) return;
      if (node === document.body || node === root && root === document) return;
      if (isHeaderOrCoverNode(node)) return;
      if (node.closest?.(COMMENT_SELECTOR) || node.matches?.(COMMENT_SELECTOR) || node.closest?.('[data-commentid], [aria-label^="Comment by" i], [aria-label^="Reply by" i]')) return;
      const text = cleanText(node.innerText || node.textContent || "");
      if (/^(?:comment|reply) by/i.test(cleanText(node.getAttribute("aria-label")))) return;
      if (!rankedPostLinks(node).length && !node.querySelector(`${MESSAGE_SELECTOR}, video, ${MEDIA_SELECTOR}`)) return;
      if (text.length > 6000 && rankedPostLinks(node).length > 4) return;
      found.push(node);
    };

    for (const node of root.querySelectorAll('[role="article"], [data-pagelet^="FeedUnit_"], [data-ft], [data-virtualized="false"]')) add(node);
    for (const link of root.querySelectorAll(POST_LINK_SELECTOR)) add(postContainer(link));
    for (const marker of root.querySelectorAll(`${MESSAGE_SELECTOR}, video, ${MEDIA_SELECTOR}`)) add(postContainer(marker));
    return found.sort((a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top);
  }

  function postContainer(node) {
    if (!node || isHeaderOrCoverNode(node) || node.closest?.(COMMENT_SELECTOR) || node.closest?.('[data-commentid], [aria-label^="Comment by" i], [aria-label^="Reply by" i]')) return null;
    const article = node.closest?.('[role="article"], [data-pagelet^="FeedUnit_"], [data-ft], [data-virtualized="false"]');
    if (article && visible(article) && !isHeaderOrCoverNode(article) && !article.closest(COMMENT_SELECTOR) && !/^(?:comment|reply) by/i.test(cleanText(article.getAttribute("aria-label")))) return article;

    let best = null;
    for (let current = node.parentElement; current && current !== document.body; current = current.parentElement) {
      if (isHeaderOrCoverNode(current) || current.closest?.(COMMENT_SELECTOR) || current.matches?.(COMMENT_SELECTOR)) break;
      const rect = current.getBoundingClientRect();
      if (!visible(current) || rect.width < 260 || rect.height < 80) continue;
      if (rect.height > Math.max(window.innerHeight * 2.2, 2200)) break;
      const links = rankedPostLinks(current).length;
      const hasContent = current.querySelector(`${MESSAGE_SELECTOR}, video, ${MEDIA_SELECTOR}`);
      if (links || hasContent) best = current;
      if (links && hasContent) break;
    }
    if (best && isHeaderOrCoverNode(best)) return null;
    return best;
  }

  function rankedPostLinks(root) {
    if (!root?.querySelectorAll) return [];
    const anchors = uniqueNodes([
      ...(root.matches?.(POST_LINK_SELECTOR) ? [root] : []),
      ...Array.from(root.querySelectorAll(POST_LINK_SELECTOR)),
      ...Array.from(root.querySelectorAll('a[href]')).filter((anchor) => looksLikePostUrl(anchor.getAttribute("href") || anchor.href))
    ]).filter((anchor) => !isHeaderOrCoverNode(anchor));

    return anchors.map((anchor) => {
      const url = normalizePostUrl(anchor.getAttribute("href") || anchor.href);
      return { anchor, url, score: postLinkScore(anchor, root, url) };
    }).filter((entry) => entry.url && looksLikePostUrl(entry.url) && !isHeaderOrCoverUrl(entry.url))
      .sort((a, b) => b.score - a.score);
  }

  function postLinkScore(anchor, root, url) {
    const href = anchor.getAttribute("href") || "";
    const label = cleanText(`${anchor.getAttribute("aria-label") || ""} ${anchor.textContent || ""}`).toLowerCase();
    let score = 0;
    if (/\/posts\/|\/permalink\/|story_fbid=|multi_permalinks=|permalink\.php/.test(href)) score += 120;
    if (/\/reel\/|\/videos\/|\/watch/.test(href)) score += 100;
    if (/\/events\/|\/marketplace\/item\//.test(href)) score += 90;
    if (/photo\.php|\/photos\/|fbid=/.test(href)) score += 70;
    if (/\/share\//.test(href)) score += 55;
    if (/\b(?:ago|today|yesterday|\d+[smhdwy])\b/.test(label)) score += 35;
    if (/comment_id|reply_comment_id|comment_tracking|notif_id/.test(href)) score -= 200;
    if (/comment|like|react|share this|send|copy link|open reactions/.test(label)) score -= 120;
    const ownerArticle = anchor.closest('[role="article"]');
    if (root.matches?.('[role="article"]') && ownerArticle && ownerArticle !== root) score -= 80;
    if (postId(url)) score += 20;
    return score;
  }

  function looksLikePostUrl(value) {
    const s = String(value || "");
    if (!s || /comment_id=|reply_comment_id=|comment_tracking=|notif_id=|set=pb\.|set=pob/i.test(s)) return false;
    // Must be a permalink with an ID, not just a profile tab like /username/posts or /username/reels
    return /\/posts\/[^/?#]+|\/reel\/[^/?#]+|\/videos\/[^/?#]+|\/share\/(?:v|p|r)\/[^/?#]+|story_fbid=|multi_permalinks=|permalink\.php|photo\.php\?fbid=|[?&]fbid=/i.test(s);
  }

  function readCaption(root) {
    const parts = [];
    for (const node of root.querySelectorAll(MESSAGE_SELECTOR)) {
      const text = cleanContent(node.innerText || node.textContent || "");
      if (text && !parts.includes(text)) parts.push(text);
    }
    if (!parts.length) {
      for (const node of root.querySelectorAll('div[dir="auto"], span[dir="auto"]')) {
        if (node.closest(COMMENT_SELECTOR) || node.closest('a[href], button, [role="button"]')) continue;
        const text = cleanContent(node.textContent || "");
        if (!isPostLine(text) || parts.includes(text)) continue;
        parts.push(text);
        if (parts.join("\n").length > 500) break;
      }
    }
    return parts.join("\n").slice(0, 3000);
  }

  function readAuthor(root) {
    return firstText([
      '[data-ad-rendering-role="profile_name"]',
      'h2 a[href]',
      'h3 a[href]',
      'strong a[href]',
      'a[role="link"] strong'
    ], root);
  }

  function readAuthorUrl(root) {
    const selectors = [
      '[data-ad-rendering-role="profile_name"] a[href]',
      '[data-ad-rendering-role="profile_name"][href]',
      'h2 a[href]',
      'h3 a[href]',
      'strong a[href]',
      'a[role="link"][href]'
    ];
    for (const selector of selectors) {
      for (const anchor of root.querySelectorAll(selector)) {
        if (!visible(anchor)) continue;
        const url = normalizeProfileUrl(anchor.href || anchor.getAttribute("href") || "");
        if (url) return url;
      }
    }
    return "";
  }

  function readAttachment(root) {
    const title = firstText(['[data-ad-rendering-role="title"]', 'h3', 'h2'], root);
    const description = firstText(['[data-ad-rendering-role="description"]'], root);
    return { title, description };
  }

  function readDate(root) {
    const values = [];
    for (const node of root.querySelectorAll(`time, abbr[title], ${POST_LINK_SELECTOR}`)) {
      values.push(node.getAttribute("datetime"), node.getAttribute("title"), node.getAttribute("aria-label"), node.textContent);
    }
    return values.map(cleanText).find((value) => /ago|today|yesterday|\d+[smhdwy]|\b\d{1,2}\s+[A-Za-z]{3}|[A-Za-z]{3}\s+\d{1,2}/i.test(value)) || "";
  }

  async function readMedia(root) {
    const images = [];
    for (const image of root.querySelectorAll(MEDIA_SELECTOR)) {
      if (!visible(image)) continue;
      const rect = image.getBoundingClientRect();
      if (rect.width < 110 || rect.height < 90) continue;
      const url = cleanAssetUrl(image.currentSrc || image.src || image.getAttribute("src") || "");
      if (!usableMedia(url) || images.includes(url)) continue;
      images.push(url);
    }

    let videoUrl = "";
    let thumbnail = "";
    let videoBlobs = 0;
    const video = Array.from(root.querySelectorAll("video")).find(visible);
    if (video) {
      const src = video.currentSrc || video.src || video.getAttribute("src") || "";
      if (/^https?:/i.test(src)) videoUrl = src;
      if (/^blob:/i.test(src)) videoBlobs += 1;
      thumbnail = cleanAssetUrl(video.poster || "") || images[0] || await captureFrame(video);
      if (thumbnail && !images.includes(thumbnail)) images.unshift(thumbnail);
    }

    const attachment_urls = unique(Array.from(root.querySelectorAll('a[href]'))
      .map((anchor) => absoluteUrl(anchor.getAttribute("href") || ""))
      .filter((url) => /^https?:/i.test(url) && !/facebook\.com|fbcdn\.net/i.test(url)));

    return { images: unique(images), video_url: videoUrl, video_blobs: videoBlobs, thumbnail, attachment_urls };
  }

  async function captureFrame(video) {
    try {
      if (video.readyState < 2 || !video.videoWidth || !video.videoHeight) return "";
      const width = Math.min(480, video.videoWidth);
      const height = Math.max(1, Math.round(width * video.videoHeight / video.videoWidth));
      const canvas = document.createElement("canvas");
      canvas.width = width;
      canvas.height = height;
      canvas.getContext("2d").drawImage(video, 0, 0, width, height);
      return canvas.toDataURL("image/jpeg", 0.62);
    } catch (_error) {
      return "";
    }
  }

  function readMetrics(root) {
    const values = Array.from(root.querySelectorAll('[aria-label], [role="button"], a, span, div'))
      .filter(visible)
      .map((node) => `${node.getAttribute("aria-label") || ""} ${node.textContent || ""}`)
      .join(" ");
    return {
      likes: countMatch(values, /([\d.,]+\s*[KMB]?)\s*(?:reactions?|likes?)/i),
      comments: countMatch(values, /([\d.,]+\s*[KMB]?)\s*comments?/i),
      shares: countMatch(values, /([\d.,]+\s*[KMB]?)\s*shares?/i),
      views: countMatch(values, /([\d.,]+\s*[KMB]?)\s*views?/i)
    };
  }

  function postType(url, root, media) {
    if (/\/reel\//i.test(url)) return "reel";
    if (/\/marketplace\/item\//i.test(url)) return "marketplace";
    if (/\/events\//i.test(url)) return "event";
    if (/\/watch\/|\/videos\//i.test(url) || root.querySelector("video")) return "video";
    if (/photo\.php|\/photos\//i.test(url) || media.images.length) return "photo";
    if (media.attachment_urls.length) return "link";
    return "post";
  }

  async function waitForPostRoot(id, url, timeoutMs) {
    const ok = await waitFor(() => {
      const root = activePostRoot(id, url);
      return root && (rankedPostLinks(root).length || readCaption(root) || root.querySelector(`video, ${MEDIA_SELECTOR}`));
    }, timeoutMs);
    return ok ? activePostRoot(id, url) : null;
  }

  function activePostRoot(id, url) {
    const dialogs = Array.from(document.querySelectorAll('div[role="dialog"]')).filter(visible);
    for (const dialog of dialogs.reverse()) {
      const exact = postCardsIn(dialog).find((card) => postMatches(card, id, url));
      if (exact) return exact;
      if (dialog.querySelector(`${MESSAGE_SELECTOR}, video, ${MEDIA_SELECTOR}`)) return dialog;
    }
    const root = centerRoot() || document;
    return postCardsIn(root).find((card) => postMatches(card, id, url))
      || (routeMatchesPost(location.href, url) ? root : null);
  }

  function postCardsIn(root) {
    return Array.from(root.querySelectorAll('[role="article"], [data-pagelet^="FeedUnit_"], [data-ft]')).filter(visible);
  }

  function postMatches(card, id, url) {
    const link = rankedPostLinks(card)[0]?.url || "";
    return Boolean((id && postId(link) === id) || (url && routeMatchesPost(link, url)));
  }

  function readProfile(username, profileUrl) {
    const main = centerRoot() || document;
    const body = cleanText(main.innerText || document.body?.innerText || "");
    const display = firstText([
      'main h1',
      '[role="main"] h1',
      'h1'
    ]) || cleanText(helpers.meta("og:title")).replace(/\s*\|\s*Facebook.*$/i, "") || username;
    const description = cleanContent(
      helpers.meta("og:description")
      || helpers.meta("description")
      || firstText(['[data-ad-rendering-role="profile_intro_card"]', '[aria-label*="Intro" i]'], main)
    );
    const avatar = firstUrl([
      ['meta[property="og:image"]', "content"],
      ['meta[name="twitter:image"]', "content"],
      ['main a[href*="/photo"] img', "src"],
      ['[role="main"] a[href*="/photo"] img', "src"],
      ['svg image', "href"]
    ]) || largestImage(main, 80, 80);
    const cover = firstUrl([
      ['img[data-imgperflogname="profileCoverPhoto"]', "src"],
      ['div[data-pagelet*="Cover"] img', "src"],
      ['div[aria-label*="Cover photo" i] img', "src"],
      ['img[alt*="cover photo" i]', "src"]
    ]);

    const followers = countMatch(body, /([\d.,]+\s*[KMB]?)\s*followers?/i);
    const following = countMatch(body, /([\d.,]+\s*[KMB]?)\s*following/i);
    const friends = countMatch(body, /([\d.,]+\s*[KMB]?)\s*friends?/i);
    return {
      username,
      display_name: display,
      bio: description,
      description,
      url: profileUrl,
      profile_url: profileUrl,
      avatar_url: avatar,
      cover_url: cover,
      followers_count: followers,
      total_followers: followers,
      following_count: following,
      total_following: following,
      friends_count: friends
    };
  }

  function buildResult(username, profileUrl, profile, state, job) {
    const images = collectImages(state.posts).slice(0, helpers.limit(job, "max_images", 25, 100));
    return {
      platform: "facebook",
      username,
      url: profileUrl,
      profile: {
        ...profile,
        friends_count: Math.max(Number(profile.friends_count) || 0, state.friends.length),
        followers_count: Math.max(Number(profile.followers_count) || 0, state.followers.length),
        following_count: Math.max(Number(profile.following_count) || 0, state.following.length),
        total_followers: Math.max(Number(profile.total_followers) || 0, state.followers.length),
        total_following: Math.max(Number(profile.total_following) || 0, state.following.length)
      },
      about: state.about || {},
      posts: state.posts,
      photos: state.photos || [],
      reels: state.reels || [],
      videos: state.videos_tab || [],
      shorts: state.reels || [],
      images: (state.photos || []).length ? state.photos : images,
      reviews: state.reviews || [],
      events: state.events || [],
      groups: state.groups || [],
      community: state.community || [],
      mentions: state.mentions || [],
      discovered_tabs: state.discovered_tabs || [],
      available_tabs: (state.tabs || []).map((t) => ({ key: t.key, label: t.label })),
      unparsed_tabs: (state.tabs || []).filter((t) => {
        const key = t.key;
        if (["posts","about","photos","reels","videos","reviews","events","groups","community","mentions","friends","followers","following"].includes(key)) return false;
        const found = (state.discovered_tabs || []).find((d) => d.key === key);
        return !found || !found.items || found.items.length === 0;
      }).map((t) => ({ key: t.key, label: t.label, message: "Selectors not found for this dynamic tab" })),
      friends: names(state.friends),
      followers: names(state.followers),
      following: names(state.following),
      friends_details: state.friends,
      followers_details: state.followers,
      following_details: state.following
    };
  }

  function collectImages(posts) {
    const output = [];
    const seen = new Set();
    for (const post of posts) {
      for (const url of unique([...(post.images || []), ...(post.image_urls || []), post.image_url, post.thumbnail])) {
        if (!usableMedia(url) || seen.has(url)) continue;
        seen.add(url);
        output.push({
          image_url: url,
          thumbnail: url,
          source_url: post.url || post.post_url || "",
          title: post.title || post.caption || "Facebook media",
          source: "facebook"
        });
      }
    }
    return output;
  }

  function mergePost(target, source) {
    for (const [key, value] of Object.entries(source || {})) {
      if (Array.isArray(value)) {
        target[key] = unique([...(target[key] || []), ...value]);
      } else if (value || !target[key]) {
        target[key] = value;
      }
    }
  }

  function centerRoot() {
    const main = Array.from(document.querySelectorAll('main, [role="main"]')).find(visible);
    if (!main) return null;
    return Array.from(main.querySelectorAll('[role="feed"], [data-pagelet^="ProfileTimeline"]')).find(visible) || main;
  }

  function visibleDialog() {
    return Array.from(document.querySelectorAll('div[role="dialog"]')).find(visible) || null;
  }

  function scrollComments(scope, amount) {
    const dialog = scope?.closest?.('div[role="dialog"]') || visibleOverlayOrDialog();
    if (dialog) {
      const scrollable = Array.from(dialog.querySelectorAll("div")).find((node) => {
        if (!visible(node) || node.scrollHeight <= node.clientHeight + 40) return false;
        return /auto|scroll|overlay/.test(getComputedStyle(node).overflowY);
      });
      if (scrollable) {
        scrollable.scrollBy({ top: amount, behavior: "instant" });
        return;
      }
    }
    if (scope && scope !== document && scope !== document.body) {
      scope.scrollIntoView?.({ block: "center", behavior: "instant" });
    } else {
      window.scrollBy({ top: Math.min(amount, 300), behavior: "instant" });
    }
  }

  function scrollPage(amount) {
    const root = centerRoot();
    const scrollable = root && Array.from(root.querySelectorAll("div")).find((node) => {
      if (!visible(node) || node.scrollHeight <= node.clientHeight + 80) return false;
      return /auto|scroll|overlay/.test(getComputedStyle(node).overflowY);
    });
    (scrollable || window).scrollBy({ top: amount, behavior: "instant" });
  }

  function clickLoadMorePosts() {
    const controls = Array.from((centerRoot() || document).querySelectorAll('button, [role="button"], span[role="button"], a[href]'));
    const button = controls.find((node) => {
      const label = cleanText(`${node.getAttribute("aria-label") || ""} ${node.textContent || ""}`).toLowerCase();
      return visible(node) && /^(?:see more|show more|load more|more posts)$/.test(label);
    });
    safeClick(button);
  }

  function expandVisibleText(scope, includeComments = false) {
    let clicked = 0;
    for (const node of scope.querySelectorAll('button, [role="button"], span[role="button"]')) {
      const label = cleanText(`${node.getAttribute("aria-label") || ""} ${node.textContent || ""}`).toLowerCase();
      if (!visible(node) || !/^(?:see more|show more|more)$/.test(label)) continue;
      if (!includeComments && node.closest(COMMENT_SELECTOR)) continue;
      safeClick(node);
      clicked += 1;
      if (clicked >= 30) break;
    }
  }

  function names(items) {
    const seen = new Set();
    const output = [];
    for (const item of Array.isArray(items) ? items : []) {
      const value = typeof item === "string" ? item : item?.display_name || item?.name || item?.username || "";
      const name = cleanText(value).replace(/^@+/, "");
      const key = name.toLowerCase();
      if (!isPersonName(name) || seen.has(key)) continue;
      seen.add(key);
      output.push(name);
    }
    return output;
  }

  function firstText(selectors, root = document) {
    for (const selector of selectors) {
      const value = cleanText(root.querySelector(selector)?.textContent || "");
      if (value) return value;
    }
    return "";
  }

  function firstUrl(entries, root = document) {
    for (const [selector, attribute] of entries) {
      const node = root.querySelector(selector);
      const value = cleanAssetUrl(node?.getAttribute(attribute) || node?.[attribute] || "");
      if (value) return value;
    }
    return "";
  }

  function largestImage(root, minWidth, minHeight) {
    return Array.from(root?.querySelectorAll?.("img") || [])
      .map((image) => {
        const rect = image.getBoundingClientRect();
        return {
          url: cleanAssetUrl(image.currentSrc || image.src || image.getAttribute("src") || ""),
          area: (rect.width || image.naturalWidth || 0) * (rect.height || image.naturalHeight || 0),
          width: rect.width || image.naturalWidth || 0,
          height: rect.height || image.naturalHeight || 0
        };
      })
      .filter((item) => item.url && item.width >= minWidth && item.height >= minHeight)
      .sort((a, b) => b.area - a.area)[0]?.url || "";
  }

  function profileUrlFor(username, value = "") {
    const cleaned = cleanUsername(username);
    if (cleaned) return `https://www.facebook.com/${encodeURIComponent(cleaned)}`;
    try {
      const url = new URL(String(value || ""), location.origin);
      if (url.pathname === "/profile.php" && url.searchParams.get("id")) {
        return `https://www.facebook.com/profile.php?id=${encodeURIComponent(url.searchParams.get("id"))}`;
      }
      const slug = url.pathname.split("/").filter(Boolean)[0] || "";
      if (!slug || PROFILE_BLOCKLIST.has(slug.toLowerCase())) return "";
      return `https://www.facebook.com/${encodeURIComponent(String(slug || "").replace(/^@/, ""))}`;
    } catch (_error) {
      return cleaned ? `https://www.facebook.com/${encodeURIComponent(cleaned)}` : "";
    }
  }

  function usernameFromUrl() {
    try {
      const url = new URL(location.href);
      return url.pathname === "/profile.php"
        ? url.searchParams.get("id") || ""
        : decodeURIComponent(url.pathname.split("/").filter(Boolean)[0] || "");
    } catch (_error) {
      return "";
    }
  }

  function cleanUsername(value) {
    const raw = String(value || "").trim().replace(/^@/, "");
    const match = raw.match(/facebook\.com\/(?:profile\.php\?id=)?([^/?#&]+)/i)?.[1];
    return decodeURIComponent(match || raw.split(/[/?#]/)[0]);
  }

  function normalizePostUrl(value) {
    try {
      let url = new URL(String(value || ""), location.origin);
      if (url.pathname === "/l.php" && url.searchParams.get("u")) {
        url = new URL(url.searchParams.get("u"), location.origin);
      }
      if (!/(^|\.)facebook\.com$/i.test(url.hostname)) return "";
      url.protocol = "https:";
      url.hostname = "www.facebook.com";
      url.hash = "";
      const keep = new Set(["story_fbid", "id", "fbid", "set", "v"]);
      for (const key of [...url.searchParams.keys()]) {
        if (!keep.has(key)) url.searchParams.delete(key);
      }
      return url.toString().replace(/\/$/, "");
    } catch (_error) {
      return "";
    }
  }

  function postId(value) {
    try {
      const url = new URL(normalizePostUrl(value));
      const path = url.pathname.replace(/\/$/, "");
      const id = path.match(/\/(?:posts|reel|videos|share|photo)\/([^/?#]+)/)?.[1]
        || url.searchParams.get("story_fbid")
        || url.searchParams.get("fbid")
        || url.searchParams.get("v");
      return id ? `post:${id}` : "";
    } catch (_error) {
      return "";
    }
  }

  function routeMatchesPost(left, right) {
    const a = postId(left);
    const b = postId(right);
    return Boolean(a && b && a === b);
  }

  function requestedPostId(job) {
    const raw = String(job?.cursor?.hash_id || job?.hash_id || "").trim();
    return raw.startsWith("post:") ? raw : postId(raw);
  }

  function existingPostIds(job) {
    const values = Array.isArray(job?.cursor?.existing_post_urls) ? job.cursor.existing_post_urls : [];
    return new Set(values.flatMap((value) => [String(value || ""), normalizePostUrl(value), postId(value)]).filter(Boolean));
  }

  function normalizeProfileUrl(value) {
    try {
      let url = new URL(String(value || ""), location.origin);
      if (url.pathname === "/l.php" && url.searchParams.get("u")) {
        url = new URL(url.searchParams.get("u"), location.origin);
      }
      if (!/(^|\.)facebook\.com$/i.test(url.hostname)) return "";
      if (url.pathname === "/profile.php" && url.searchParams.get("id")) {
        return `https://www.facebook.com/profile.php?id=${encodeURIComponent(url.searchParams.get("id"))}`;
      }
      const parts = url.pathname.split("/").filter(Boolean);
      if (parts[0]?.toLowerCase() === "people" && parts[2]) {
        return `https://www.facebook.com/profile.php?id=${encodeURIComponent(decodeURIComponent(parts[2]))}`;
      }
      const slug = decodeURIComponent(parts[0] || "");
      if (!slug || PROFILE_BLOCKLIST.has(slug.toLowerCase())) return "";
      if (looksLikePostUrl(url.href)) return "";
      return `https://www.facebook.com/${encodeURIComponent(slug)}`;
    } catch (_error) {
      return "";
    }
  }

  function ownerProfileFromPostUrl(value) {
    try {
      const url = new URL(normalizePostUrl(value));
      if (!/(^|\.)facebook\.com$/i.test(url.hostname)) return "";
      if (url.pathname === "/profile.php") {
        const id = url.searchParams.get("id");
        return id ? `https://www.facebook.com/profile.php?id=${encodeURIComponent(id)}` : "";
      }
      const parts = url.pathname.split("/").filter(Boolean);
      if (parts[0]?.toLowerCase() === "groups") return "";
      const owner = decodeURIComponent(parts[0] || "");
      if (!owner || PROFILE_BLOCKLIST.has(owner.toLowerCase())) return "";
      return `https://www.facebook.com/${encodeURIComponent(owner)}`;
    } catch (_error) {
      return "";
    }
  }

  function sameProfile(left, right) {
    return profileKey(left) && profileKey(left) === profileKey(right);
  }

  function profileKey(value) {
    try {
      const url = new URL(String(value || ""), location.origin);
      if (url.pathname === "/profile.php") return `id:${url.searchParams.get("id") || ""}`;
      return `slug:${decodeURIComponent(url.pathname.split("/").filter(Boolean)[0] || "").toLowerCase()}`;
    } catch (_error) {
      return "";
    }
  }

  function profileSlug(value) {
    return profileKey(value).replace(/^(?:slug|id):/, "");
  }

  function normalizeName(value) {
    return cleanText(value)
      .replace(/^@+/, "")
      .replace(/\s+\(\s*@?[^)]+\)\s*$/i, "")
      .toLowerCase();
  }

  function connectionLimit(job, type) {
    const key = type === "friends" ? "max_friends" : type === "following" ? "max_following" : "max_followers";
    return helpers.limit(job, key, 100, 500);
  }

  function countMatch(text, pattern) {
    const match = String(text || "").match(pattern);
    return match ? count(match[1]) : 0;
  }

  function count(value) {
    return Number(helpers.count(cleanText(value))) || 0;
  }

  function parseDateIso(value) {
    const text = cleanText(String(value || "").replace(/·/g, " ")).replace(/\s+at\s+\d{1,2}:\d{2}\s*(?:AM|PM)?/i, "");
    if (!text) return "";
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const iso = (date) => date.toISOString().slice(0, 10);
    const lowered = text.toLowerCase();
    if (/\btoday\b/.test(lowered) || /\b\d+\s*(?:h|hr|hrs|hour|hours|m|min|mins|minute|minutes)\b/i.test(text)) return iso(today);
    if (/\byesterday\b/.test(lowered)) return iso(new Date(today.getTime() - 86400000));
    let match = text.match(/\b(\d+)\s*(?:d|day|days)\b/i);
    if (match) return iso(new Date(today.getTime() - Number(match[1]) * 86400000));
    match = text.match(/\b(\d+)\s*(?:w|week|weeks)\b/i);
    if (match) return iso(new Date(today.getTime() - Number(match[1]) * 7 * 86400000));
    match = text.match(/\b(\d{4})-(\d{2})-(\d{2})\b/);
    if (match) return `${match[1]}-${match[2]}-${match[3]}`;
    const parsed = Date.parse(text);
    if (!Number.isFinite(parsed)) return "";
    const date = new Date(parsed);
    if (date.getFullYear() < 2004 || date.getFullYear() > now.getFullYear() + 1) return "";
    if (date > today) date.setFullYear(date.getFullYear() - 1);
    return iso(date);
  }

  function randomBetween(min, max) {
    return Math.floor(min + Math.random() * (max - min + 1));
  }

  function isPostLine(value) {
    const text = cleanText(value);
    if (text.length < 2) return false;
    if (/^(?:facebook|like|comment|share|reply|send|react|follow|following|message|see more|show more|see less|public|sponsored|m\.me|facebook\.com|www\.facebook\.com)$/i.test(text)) return false;
    if (/^\d[\d.,]*\s*[KMB]?\s*(?:comments?|shares?|views?|likes?|followers?|reactions?)$/i.test(text)) return false;
    if (/^(?:all reactions|most relevant|write a comment|top fan)$/i.test(text)) return false;
    if (/actions for this post|write a comment/i.test(text)) return false;
    if (parseDateIso(text)) return false;
    if (/^[a-z0-9_=-]{40,}$/i.test(text) && !/\s/.test(text)) return false;
    return true;
  }

  function isCommentNoise(value) {
    const text = cleanText(value).toLowerCase();
    return !text
      || /^(?:like|reply|share|edited|author|top fan|follow|see more|show more|view replies?|hide|send)$/i.test(text)
      || /^\d+[smhdwy]$/i.test(text)
      || /^\d+\s*(?:likes?|replies?|comments?)$/i.test(text)
      || /write a comment|comment as|most relevant|all comments/.test(text);
  }

  function cleanContent(value) {
    return unique(String(value || "").split(/\n+/).map(cleanText).filter(isPostLine)).join("\n");
  }

  function isPersonName(value) {
    const text = cleanText(value);
    return Boolean(text
      && text.length <= 120
      && !/^avatar_url/i.test(text)
      && !/https?:|profile_url|display_name|^\d/.test(text)
      && !/^(?:friends?|followers?|following|see all|add friend|message|follow|facebook|notifications|details|posts|photos|videos)$/i.test(text));
  }

  function cleanAssetUrl(value) {
    const match = String(value || "").match(/url\(["']?([^"')]+)["']?\)/);
    const raw = cleanText(match ? match[1] : value);
    if (!raw || raw.startsWith("data:") || /^(?:none|initial|inherit|unset)$/i.test(raw)) return "";
    return absoluteUrl(raw);
  }

  function usableMedia(value) {
    return /^(?:https?:|data:image\/)/i.test(String(value || ""))
      && !/static\.xx\.fbcdn\.net|emoji|rsrc\.php/i.test(String(value || ""));
  }

  function absoluteUrl(value) {
    try { return new URL(String(value || ""), location.origin).toString(); }
    catch (_error) { return ""; }
  }

  function visible(node) {
    if (!node?.getBoundingClientRect) return false;
    const rect = node.getBoundingClientRect();
    const style = getComputedStyle(node);
    return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden";
  }

  function safeClick(node) {
    try {
      node?.scrollIntoView?.({ block: "center", behavior: "instant" });
      node?.click?.();
    } catch (_error) {
      // Facebook replaces nodes frequently.
    }
  }

  async function waitFor(reader, timeoutMs) {
    const started = Date.now();
    while (Date.now() - started < timeoutMs) {
      if (reader()) return true;
      await delay(300);
    }
    return false;
  }

  async function delay(ms) {
    await helpers.delay(ms);
  }

  function cleanText(value) {
    return helpers.cleanText(String(value || ""));
  }

  function unique(values) {
    return [...new Set(values.filter(Boolean))];
  }

  function uniqueNodes(nodes) {
    const seen = new Set();
    return nodes.filter((node) => {
      if (!node || seen.has(node)) return false;
      seen.add(node);
      return true;
    });
  }

  // ═══════════════════════════════════════════════════════
  // TAB DISCOVERY & SPA NAVIGATION
  // ═══════════════════════════════════════════════════════

  function isProfileTabHref(href, slug) {
    if (!href) return false;
    const lower = href.toLowerCase();
    if (/help|privacy|terms|policy|footer|settings/i.test(lower)) return false;
    if (slug && lower.includes(slug.toLowerCase())) return true;
    if (/[?&]sk=/i.test(lower)) return true;
    if (/^\/(?:about|photos|reels|videos|reviews|events|groups|community|mentions|friends|followers|following|likes|music|sports|movies|books|map)(?:\/|[?&#]|$)/i.test(lower)) return true;
    return false;
  }

  function discoverTabs(username) {
    const slug = encodeURIComponent(String(username || "").replace(/^@/, ""));
    const main = document.querySelector('[role="main"], main') || document;
    const anchors = Array.from(main.querySelectorAll('a[href]')).filter(visible);
    const tabs = [];
    const seen = new Set();
    const TAB_PATTERNS = [
      { key: "posts", pattern: /\/posts\b|[?&]sk=posts/i },
      { key: "about", pattern: /\/about\b|[?&]sk=about/i },
      { key: "photos", pattern: /\/photos\b|[?&]sk=photos/i },
      { key: "reels", pattern: /\/reels\b|[?&]sk=reels/i },
      { key: "videos", pattern: /\/videos\b|[?&]sk=videos/i },
      { key: "reviews", pattern: /\/reviews\b|[?&]sk=reviews/i },
      { key: "events", pattern: /\/events\b|[?&]sk=events/i },
      { key: "groups", pattern: /\/groups\b|[?&]sk=groups/i },
      { key: "community", pattern: /\/community\b|[?&]sk=community/i },
      { key: "mentions", pattern: /\/mentions\b|[?&]sk=mentions/i },
      { key: "friends", pattern: /\/friends\b|[?&]sk=friends/i },
      { key: "followers", pattern: /\/followers\b|[?&]sk=followers/i },
      { key: "following", pattern: /\/following\b|[?&]sk=following/i },
      { key: "likes", pattern: /\/likes\b|[?&]sk=likes/i },
      { key: "music", pattern: /\/music\b|[?&]sk=music/i },
      { key: "sports", pattern: /\/sports\b|[?&]sk=sports/i },
      { key: "movies", pattern: /\/movies\b|[?&]sk=movies/i },
      { key: "books", pattern: /\/books\b|[?&]sk=books/i },
      { key: "check-ins", pattern: /\/map\b|\/check.?ins?\b|[?&]sk=map/i }
    ];
    for (const anchor of anchors) {
      const href = anchor.getAttribute("href") || "";
      if (!isProfileTabHref(href, slug)) continue;
      for (const { key, pattern } of TAB_PATTERNS) {
        if (seen.has(key)) continue;
        if (pattern.test(href)) {
          seen.add(key);
          tabs.push({ key, label: cleanText(anchor.textContent || key), anchor, href });
        }
      }
    }
    // Also detect tabs by text label for dynamic/unknown tabs
    const knownKeys = new Set(seen);
    for (const anchor of anchors) {
      const href = anchor.getAttribute("href") || "";
      if (!isProfileTabHref(href, slug)) continue;
      const label = cleanText(anchor.textContent || "").toLowerCase();
      if (!label || label.length > 30 || knownKeys.has(label)) continue;
      if (!/^[a-z\s&]+$/.test(label)) continue;
      const key = label.replace(/\s+/g, "_");
      if (!seen.has(key)) {
        seen.add(key);
        tabs.push({ key, label: cleanText(anchor.textContent), anchor, href });
      }
    }
    return tabs;
  }

  async function navigateToTab(tab) {
    if (!tab?.anchor) return false;
    const beforeUrl = location.href;
    safeClick(tab.anchor);
    await delay(1200);
    const changed = await waitFor(() => {
      const main = document.querySelector('[role="main"], main');
      return main && (location.href !== beforeUrl || main.querySelector('h2, h3, [role="feed"], img'));
    }, 8000);
    await delay(600);
    return changed;
  }

  async function navigateToUrl(url) {
    if (!url) return false;
    if (sameProfile(location.href, url) && !/\/about|\/photos|\/reels|\/videos|\/reviews|\/events|\/groups|\/community|\/mentions|\/friends|\/followers|\/following/i.test(location.href)) {
      return true;
    }
    // Find existing SPA link on the page (e.g. "Posts" tab or profile header link)
    const existingLinks = Array.from(document.querySelectorAll('a[role="tab"], [role="navigation"] a, a[href]'))
      .filter((a) => visible(a) && sameProfile(a.href || "", url));
    const targetLink = existingLinks.find((a) => /\/posts\b|[?&]sk=posts/i.test(a.href || ""))
      || existingLinks.find((a) => !/\/(?:about|photos|reels|videos|reviews|events|groups|community|mentions|friends|followers|following)\b/i.test(a.href || ""));
    if (targetLink) {
      safeClick(targetLink);
      await delay(1200);
      return true;
    }
    // Fallback: use History API and PopStateEvent to navigate in-place without page unload
    try {
      window.history.pushState({}, "", url);
      window.dispatchEvent(new PopStateEvent("popstate", { state: {} }));
      await delay(1000);
    } catch (_e) {}
    return true;
  }

  // ═══════════════════════════════════════════════════════
  // ABOUT SECTION
  // ═══════════════════════════════════════════════════════

  async function collectAbout(username, profileUrl) {
    const tab = discoverTabs(username).find((t) => t.key === "about");
    if (!tab) return {};
    await navigateToTab(tab);
    const main = document.querySelector('[role="main"], main') || document;
    const about = { sections: [] };

    // Discover about sub-tabs (Overview, Work, Places, Contact, etc.)
    const subLinks = Array.from(main.querySelectorAll('a[href]')).filter((a) => {
      const href = a.getAttribute("href") || "";
      if (!visible(a)) return false;
      const isAboutLink = /\/about(?:_[a-z_]+)?\b|[?&]sk=about(?:_[a-z_]+)?/i.test(href);
      return isAboutLink && !/help|privacy|terms|policy|footer/i.test(href);
    });
    const visitedSubs = new Set();

    // If no sub-links, just read current page
    if (subLinks.length <= 1) {
      about.sections.push({ name: "overview", items: readAboutItems(main) });
    } else {
      for (const link of subLinks) {
        const label = cleanText(link.textContent || "").toLowerCase().replace(/\s+/g, "_") || "overview";
        if (visitedSubs.has(label)) continue;
        visitedSubs.add(label);
        safeClick(link);
        await delay(1500);
        about.sections.push({ name: label, items: readAboutItems(main) });
      }
    }

    // Extract structured fields from all sections
    const allItems = about.sections.flatMap((s) => s.items);
    about.intro = findAboutValue(allItems, /intro|bio/i);
    about.category = findAboutValue(allItems, /categor/i);
    about.contact = findAboutValue(allItems, /contact|phone|email|mail/i);
    about.links = allItems.filter((i) => /https?:\/\//.test(i.value)).map((i) => i.value);
    about.locations = findAboutValues(allItems, /location|address|city|lives? in|from/i);
    about.hours = findAboutValue(allItems, /hours|open|close/i);
    about.privacy = findAboutValue(allItems, /privacy|audience/i);
    about.details = allItems;

    // Navigate back to profile
    await navigateToUrl(profileUrl);
    return about;
  }

  function readAboutItems(root) {
    const items = [];
    const seen = new Set();
    // Read from card-like containers
    const containers = Array.from(root.querySelectorAll(
      '[data-pagelet], [role="article"], [role="listitem"], li, [class]'
    )).filter((node) => {
      if (!visible(node)) return false;
      const rect = node.getBoundingClientRect();
      return rect.height > 20 && rect.height < 600 && rect.width > 150;
    });
    for (const container of containers) {
      const text = cleanText(container.innerText || container.textContent || "");
      if (!text || text.length < 3 || text.length > 2000 || seen.has(text)) continue;
      seen.add(text);
      const lines = text.split("\n").map(cleanText).filter(Boolean);
      const label = lines[0] || "";
      const value = lines.slice(1).join("\n") || lines[0] || "";
      if (isAboutNoise(label)) continue;
      items.push({ label, value, raw: text });
    }
    // Fallback: read all dir="auto" text blocks
    if (items.length < 3) {
      for (const node of root.querySelectorAll('div[dir="auto"], span[dir="auto"]')) {
        const text = cleanText(node.textContent || "");
        if (!text || text.length < 3 || seen.has(text) || isAboutNoise(text)) continue;
        seen.add(text);
        items.push({ label: "", value: text, raw: text });
      }
    }
    return items;
  }

  function isAboutNoise(text) {
    return /^(see more|show more|edit|add|save|cancel|close|back|facebook|log in|sign up)$/i.test(text)
      || /^(like|follow|share|message|send|poke)$/i.test(text);
  }

  function findAboutValue(items, pattern) {
    const match = items.find((i) => pattern.test(i.label) || pattern.test(i.value));
    return match?.value || "";
  }

  function findAboutValues(items, pattern) {
    return items.filter((i) => pattern.test(i.label) || pattern.test(i.value)).map((i) => i.value);
  }

  // ═══════════════════════════════════════════════════════
  // PHOTOS TAB
  // ═══════════════════════════════════════════════════════

  async function collectPhotosTab(username, profileUrl, limit) {
    const tab = discoverTabs(username).find((t) => t.key === "photos");
    if (!tab) return [];
    await navigateToTab(tab);
    const photos = await scrollAndCollectGrid(
      'a[href*="/photo"], a[href*="photo.php"], a[href*="fbid="]',
      limit,
      (anchor) => {
        const img = anchor.querySelector("img");
        const href = anchor.getAttribute("href") || anchor.href || "";
        const src = img ? cleanAssetUrl(img.currentSrc || img.src || "") : "";
        if (!src && !href) return null;
        return { url: absoluteUrl(href), image_url: src, type: "photo" };
      }
    );
    // Open each photo for comments (cap at limit)
    const commentLimit = Math.min(photos.length, limit);
    const deadline = Date.now() + 90000; // 90 seconds max for photo comment collection
    for (let i = 0; i < commentLimit; i++) {
      if (Date.now() > deadline) break;
      try {
        const photoComments = await openOverlayAndCollectComments(photos[i].url, 10);
        photos[i].comment_details = photoComments;
        photos[i].comment_items = photoComments.map((c) => c.text);
        photos[i].comments = String(photoComments.length);
      } catch (_e) { photos[i].comment_details = []; photos[i].comment_items = []; photos[i].comments = "0"; }
    }
    await navigateToUrl(profileUrl);
    return photos;
  }

  // ═══════════════════════════════════════════════════════
  // REELS TAB
  // ═══════════════════════════════════════════════════════

  async function collectReelsTab(username, profileUrl, limit) {
    const tab = discoverTabs(username).find((t) => t.key === "reels");
    if (!tab) return [];
    await navigateToTab(tab);
    const reels = await scrollAndCollectGrid(
      'a[href*="/reel/"]',
      limit,
      (anchor) => {
        const img = anchor.querySelector("img");
        const href = anchor.getAttribute("href") || anchor.href || "";
        const src = img ? cleanAssetUrl(img.currentSrc || img.src || "") : "";
        const card = anchor.closest('[role="article"], [role="listitem"], [data-pagelet]') || anchor.parentElement || anchor;
        const ariaLabel = cleanText(anchor.getAttribute("aria-label") || img?.getAttribute("alt") || "");
        let title = ariaLabel;
        if (!title || title.length < 3) {
          const textNodes = Array.from(card.querySelectorAll('span[dir="auto"], div[dir="auto"], strong, h3, h4'))
            .map((el) => cleanText(el.textContent || ""))
            .filter((t) => t.length > 2 && !/^\d+[\d:.]*$/i.test(t) && !/^\d+\s*(?:views?|likes?|comments?)$/i.test(t) && !/^(?:video|reel|watch)$/i.test(t));
          title = textNodes[0] || cleanText(card.innerText || card.textContent || "").split("\n")[0] || "";
        }
        const url = absoluteUrl(href);
        const reelId = postId(url);
        return {
          id: reelId,
          hash_id: reelId,
          title: title.slice(0, 300) || "Facebook reel",
          caption: title.slice(0, 1000),
          text: title.slice(0, 1000),
          url,
          post_url: url,
          thumbnail: src,
          image_url: src,
          media_url: src,
          media_type: "reel",
          type: "reel",
          source: "facebook"
        };
      }
    );
    const commentLimit = Math.min(reels.length, limit);
    const deadline = Date.now() + 90000; // 90 seconds max for reel comment collection
    for (let i = 0; i < commentLimit; i++) {
      if (Date.now() > deadline) break;
      try {
        const reelComments = await collectReelComments(reels[i].url, 10);
        reels[i].comment_details = reelComments;
        reels[i].comment_items = reelComments.map((c) => c.text);
        reels[i].comments = String(reelComments.length);
      } catch (_e) { reels[i].comment_details = []; reels[i].comment_items = []; reels[i].comments = "0"; }
    }
    await navigateToUrl(profileUrl);
    return reels;
  }

  // ═══════════════════════════════════════════════════════
  // VIDEOS TAB
  // ═══════════════════════════════════════════════════════

  async function collectVideosTab(username, profileUrl, limit) {
    const tab = discoverTabs(username).find((t) => t.key === "videos");
    if (!tab) return [];
    await navigateToTab(tab);
    const videos = await scrollAndCollectGrid(
      'a[href*="/videos/"], a[href*="/watch/"], a[href*="/reel/"]',
      limit,
      (anchor) => {
        const img = anchor.querySelector("img");
        const href = anchor.getAttribute("href") || anchor.href || "";
        const src = img ? cleanAssetUrl(img.currentSrc || img.src || "") : "";
        const card = anchor.closest('[role="article"], [role="listitem"], [data-pagelet]') || anchor.parentElement || anchor;
        const ariaLabel = cleanText(anchor.getAttribute("aria-label") || img?.getAttribute("alt") || "");
        let title = ariaLabel;
        if (!title || title.length < 3) {
          const textNodes = Array.from(card.querySelectorAll('span[dir="auto"], div[dir="auto"], strong, h3, h4'))
            .map((el) => cleanText(el.textContent || ""))
            .filter((t) => t.length > 2 && !/^\d+[\d:.]*$/i.test(t) && !/^\d+\s*(?:views?|likes?|comments?)$/i.test(t) && !/^(?:video|reel|watch)$/i.test(t));
          title = textNodes[0] || cleanText(card.innerText || card.textContent || "").split("\n")[0] || "";
        }
        const url = absoluteUrl(href);
        const videoId = postId(url);
        return {
          id: videoId,
          hash_id: videoId,
          title: title.slice(0, 300) || "Facebook video",
          caption: title.slice(0, 1000),
          text: title.slice(0, 1000),
          url,
          post_url: url,
          thumbnail: src,
          image_url: src,
          media_url: src,
          media_type: "video",
          type: "video",
          source: "facebook"
        };
      }
    );
    const commentLimit = Math.min(videos.length, limit);
    for (let i = 0; i < commentLimit; i++) {
      try {
        const videoComments = await openOverlayAndCollectComments(videos[i].url, 10);
        videos[i].comment_details = videoComments;
        videos[i].comment_items = videoComments.map((c) => c.text);
        videos[i].comments = String(videoComments.length);
      } catch (_e) { videos[i].comment_details = []; videos[i].comment_items = []; videos[i].comments = "0"; }
    }
    await navigateToUrl(profileUrl);
    return videos;
  }

  // ═══════════════════════════════════════════════════════
  // REVIEWS
  // ═══════════════════════════════════════════════════════

  async function collectReviews(username, profileUrl, limit) {
    const tab = discoverTabs(username).find((t) => t.key === "reviews");
    if (!tab) return [];
    await navigateToTab(tab);
    const reviews = [];
    const seen = new Set();
    for (let round = 0; round < 30 && reviews.length < limit; round++) {
      const root = document.querySelector('[role="main"], main') || document;
      for (const node of root.querySelectorAll('[role="article"], [data-ft], [data-pagelet]')) {
        if (!visible(node)) continue;
        const text = cleanText(node.innerText || node.textContent || "");
        if (!text || text.length < 10 || seen.has(text)) continue;
        seen.add(text);
        const stars = (text.match(/★/g) || []).length
          || Number(node.querySelector('[aria-label*="star" i]')?.getAttribute("aria-label")?.match(/(\d)/)?.[1] || 0);
        const author = firstText(['a[role="link"] strong', 'strong', 'h3', 'h4'], node);
        const date = firstText(['abbr', 'time', 'a[href*="comment"]'], node);
        const lines = text.split("\n").map(cleanText).filter((l) => l.length > 10 && !isCommentNoise(l));
        reviews.push({ author, stars, text: lines.join("\n"), date, raw: text });
        if (reviews.length >= limit) break;
      }
      if (reviews.length >= limit) break;
      scrollPage(2000);
      await delay(1000);
    }
    await navigateToUrl(profileUrl);
    return reviews;
  }

  // ═══════════════════════════════════════════════════════
  // GENERIC TAB COLLECTOR (Events, Groups, Community, Mentions, etc.)
  // ═══════════════════════════════════════════════════════

  async function collectGenericTab(username, profileUrl, tabKey, limit) {
    const tab = discoverTabs(username).find((t) => t.key === tabKey);
    if (!tab) return [];
    await navigateToTab(tab);
    const items = [];
    const seen = new Set();
    for (let round = 0; round < 20 && items.length < limit; round++) {
      const root = document.querySelector('[role="main"], main') || document;
      for (const node of root.querySelectorAll('[role="article"], [role="listitem"], a[href], [data-pagelet]')) {
        if (!visible(node)) continue;
        const text = cleanText(node.innerText || node.textContent || "");
        if (!text || text.length < 5 || text.length > 3000 || seen.has(text)) continue;
        seen.add(text);
        const href = node.getAttribute?.("href") || node.querySelector?.("a[href]")?.getAttribute("href") || "";
        const img = node.querySelector?.("img");
        const imgSrc = img ? cleanAssetUrl(img.currentSrc || img.src || "") : "";
        items.push({
          title: text.split("\n")[0]?.slice(0, 200) || "",
          text: text.slice(0, 1000),
          url: href ? absoluteUrl(href) : "",
          image_url: imgSrc,
          tab: tabKey
        });
        if (items.length >= limit) break;
      }
      if (items.length >= limit) break;
      scrollPage(2000);
      await delay(1000);
    }
    await navigateToUrl(profileUrl);
    return items;
  }

  // ═══════════════════════════════════════════════════════
  // GRID SCROLL + COLLECT (shared by Photos, Reels, Videos)
  // ═══════════════════════════════════════════════════════

  async function scrollAndCollectGrid(selector, limit, parser) {
    const items = [];
    const seen = new Set();
    let idle = 0;
    for (let round = 0; round < 40 && items.length < limit; round++) {
      const before = items.length;
      const root = document.querySelector('[role="main"], main') || document;
      for (const anchor of root.querySelectorAll(selector)) {
        if (!visible(anchor)) continue;
        const href = anchor.getAttribute("href") || anchor.href || "";
        if (seen.has(href)) continue;
        seen.add(href);
        const item = parser(anchor);
        if (!item || !item.url) continue;
        if (seen.has(item.url) || items.some((i) => i.url === item.url || (item.id && i.id === item.id))) continue;
        seen.add(item.url);
        items.push(item);
        if (items.length >= limit) break;
      }
      idle = items.length === before ? idle + 1 : 0;
      if (items.length >= limit || idle >= 6) break;
      scrollPage(2200);
      await delay(1000);
    }
    return items;
  }

  // ═══════════════════════════════════════════════════════
  // OVERLAY COMMENTS (for Photos, Reels, Videos)
  // ═══════════════════════════════════════════════════════

  function visibleOverlayOrDialog() {
    const dialog = Array.from(document.querySelectorAll('div[role="dialog"]')).find(visible);
    if (dialog) return dialog;
    if (/\/reel\//i.test(location.href) || location.pathname.includes("/reel/")) {
      const reelContainer = Array.from(document.querySelectorAll('[data-pagelet*="Reel" i], [role="main"], main')).find(visible);
      if (reelContainer) return reelContainer;
    }
    const mediaContainer = Array.from(document.querySelectorAll('[aria-label*="Media" i], [aria-label*="Reel" i], [data-pagelet*="Photo" i], [data-pagelet*="Media" i]')).find(visible);
    return mediaContainer || null;
  }

  async function closeAnyOpenDialog() {
    let dialog = visibleOverlayOrDialog();
    if (!dialog) return;
    const closeBtn = dialog.querySelector('[aria-label="Close" i], [aria-label="close" i], [aria-label="Back" i], [role="button"][aria-label*="Close" i]');
    if (closeBtn) {
      safeClick(closeBtn);
      await delay(400);
    }
    if (location.href.includes("/reel/")) {
      window.history.back();
      await delay(500);
      return;
    }
    dialog = visibleOverlayOrDialog();
    if (dialog) {
      document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
      await delay(400);
    }
  }

  async function openReelCommentsPanel(scope) {
    const root = scope || visibleOverlayOrDialog() || document;
    const btns = Array.from(root.querySelectorAll('div[role="button"], button, a[role="button"], [aria-label]'))
      .filter(visible)
      .filter((el) => {
        const aria = cleanText(el.getAttribute("aria-label") || el.getAttribute("title") || "").toLowerCase();
        return /\bcomments?\b/i.test(aria) && !/write a comment|add a comment/i.test(aria);
      });
    if (btns.length > 0) {
      safeClick(btns[0]);
      await delay(600);
    }
  }

  async function collectReelComments(reelUrl, limit = 10) {
    if (!reelUrl) return [];
    const pathSeg = extractPathSegment(reelUrl);
    if (!pathSeg) return [];

    await closeAnyOpenDialog();

    const anchor = Array.from(document.querySelectorAll('a[href]'))
      .find((a) => (a.getAttribute("href") || "").includes(pathSeg));

    if (anchor && visible(anchor)) {
      anchor.scrollIntoView?.({ block: "center", behavior: "instant" });
      await delay(300);
      safeClick(anchor);
    } else {
      await navigateToUrl(reelUrl);
    }

    await waitFor(() => location.href.includes(pathSeg) || visibleOverlayOrDialog(), 5000);
    await delay(800);

    const root = visibleOverlayOrDialog() || document.querySelector('[role="main"], main') || document;

    await openReelCommentsPanel(root);
    await openComments(root);
    await selectAllComments(root);

    const scope = commentScope(root);
    await waitFor(() => commentNodes(scope).length > 0, 5000);

    const comments = await collectComments(scope, 0, limit);

    if (location.href.includes("/reel/")) {
      window.history.back();
      await delay(800);
    } else {
      await closeAnyOpenDialog();
    }

    return comments;
  }

  async function openOverlayAndCollectComments(url, limit) {
    if (!url) return [];
    const pathSeg = extractPathSegment(url);
    if (!pathSeg) return [];

    await closeAnyOpenDialog();

    const anchor = document.querySelector(`a[href*="${pathSeg}"]`);
    if (!anchor) return [];

    anchor.scrollIntoView?.({ block: "center", behavior: "instant" });
    await delay(300);
    safeClick(anchor);

    const opened = await waitFor(() => visibleOverlayOrDialog(), 4000);
    if (!opened) return [];
    await delay(600);

    const dialog = visibleOverlayOrDialog();
    if (!dialog) return [];

    await openReelCommentsPanel(dialog);
    await openComments(dialog);
    await selectAllComments(dialog);

    const scope = commentScope(dialog);
    await waitFor(() => commentNodes(scope).length > 0, 5000);

    const comments = await collectComments(dialog, 0, limit);

    await closeAnyOpenDialog();
    return comments;
  }

  function extractPathSegment(url) {
    try {
      const path = new URL(url, location.origin).pathname;
      const parts = path.split("/").filter(Boolean);
      return parts[parts.length - 1] || parts[parts.length - 2] || "";
    } catch (_e) { return ""; }
  }
})();

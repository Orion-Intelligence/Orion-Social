(function () {
  const helpers = {
    text(selector, root = document) {
      const node = root.querySelector(selector);
      return helpers.cleanText(node?.textContent || "");
    },

    attr(selector, attribute, root = document) {
      const node = root.querySelector(selector);
      return node?.getAttribute(attribute) || "";
    },

    cleanText(value) {
      return String(value || "").replace(/\s+/g, " ").trim();
    },

    absoluteUrl(value) {
      if (!value) {
        return "";
      }
      try {
        return new URL(value, window.location.href).toString();
      } catch (_error) {
        return String(value);
      }
    },

    unique(items, keyFn) {
      const seen = new Set();
      return items.filter((item) => {
        const key = keyFn(item);
        if (!key || seen.has(key)) {
          return false;
        }
        seen.add(key);
        return true;
      });
    },

    command(job) {
      return String(job?.command || job?.social_data_type || "profile").trim().toLowerCase();
    },

    limit(job, key, fallback, maximum = 5000) {
      const raw = Number(job?.limits?.[key] ?? job?.[key] ?? fallback);
      return Number.isFinite(raw) ? Math.max(0, Math.min(Math.trunc(raw), maximum)) : fallback;
    },

    count(value) {
      const match = String(value || "").replace(/,/g, "").match(/([\d.]+)\s*([KMB])?/i);
      if (!match) {
        return "";
      }
      const multiplier = { K: 1e3, M: 1e6, B: 1e9 }[String(match[2] || "").toUpperCase()] || 1;
      return Math.round(Number(match[1]) * multiplier);
    },

    usernameFromHref(value, patterns) {
      try {
        const url = new URL(value, window.location.href);
        for (const pattern of patterns) {
          const match = url.pathname.match(pattern);
          if (match?.[1]) {
            return decodeURIComponent(match[1]).replace(/^@/, "");
          }
        }
      } catch (_error) {
        // Ignore malformed links.
      }
      return "";
    },

    async collectWhileScrolling(collector, limit, options = {}) {
      const results = [];
      const seen = new Set();
      const keyFn = options.keyFn || ((item) => item?.url || item?.id || JSON.stringify(item));
      const maxScrolls = Math.max(0, Number(options.maxScrolls ?? 12));
      let idle = 0;
      for (let index = 0; index <= maxScrolls && results.length < limit; index += 1) {
        const before = results.length;
        for (const item of await collector() || []) {
          const key = keyFn(item);
          if (!key || seen.has(key)) continue;
          seen.add(key);
          results.push(item);
          if (results.length >= limit) break;
        }
        idle = results.length === before ? idle + 1 : 0;
        if (results.length >= limit || idle >= 3 || index === maxScrolls) break;
        window.scrollBy({ top: Math.max(800, Math.floor(window.innerHeight * 0.9)), behavior: "instant" });
        await helpers.delay(Number(options.delayMs ?? 850));
      }
      return results.slice(0, limit);
    },

    meta(name) {
      return document.querySelector(`meta[property="${name}"], meta[name="${name}"]`)?.content || "";
    },

    async delay(ms) {
      await new Promise((resolve) => setTimeout(resolve, ms));
    },

    async waitForAny(selectors, timeoutMs = 12000) {
      const startedAt = Date.now();
      while (Date.now() - startedAt < timeoutMs) {
        if (selectors.some((selector) => document.querySelector(selector))) {
          return true;
        }
        await helpers.delay(350);
      }
      return false;
    },

    async settlePage(selectors = []) {
      await helpers.waitForAny(selectors, 12000);
      for (let index = 0; index < 3; index += 1) {
        window.scrollBy({ top: Math.max(500, Math.floor(window.innerHeight * 0.8)), behavior: "instant" });
        await helpers.delay(900);
      }
      window.scrollTo({ top: 0, behavior: "instant" });
      await helpers.delay(700);
    }
  };

  window.OrionScraperHelpers = helpers;
  window.OrionScrapers = window.OrionScrapers || {};
})();

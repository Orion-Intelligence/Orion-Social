(function () {
  const helpers = window.OrionScraperHelpers;

  window.OrionScrapers = window.OrionScrapers || {};
  window.OrionScrapers.reddit = {
    selectors: ["shreddit-post", "article", "[data-testid='post-container']", "h1"],
    async run(job) {
      const username = job.username || usernameFromUrl();
      const command = helpers.command(job);
      const posts = ["followers", "following"].includes(command) ? [] : await collectPosts(job);
      const stats = parseStats();
      const profile = {
        display_name: helpers.meta("og:title").replace(/\s+-\s+Reddit$/, "") || username,
        username,
        bio: helpers.meta("description"),
        url: window.location.href,
        avatar_url: findAvatar(),
        cover_url: helpers.meta("og:image"),
        followers_count: stats.followers,
        total_followers: stats.followers
      };

      return {
        platform: "reddit",
        username,
        url: window.location.href,
        profile,
        posts,
        images: collectImages(posts),
        followers: [],
        following: []
      };
    }
  };

  function usernameFromUrl() {
    const match = window.location.pathname.match(/\/user\/([^/]+)/i);
    return match ? decodeURIComponent(match[1]) : "";
  }

  async function collectPosts(job) {
    const limit = helpers.limit(job, "max_posts", 25, 100);
    const posts = await helpers.collectWhileScrolling(() => collectVisiblePosts(job), limit, { maxScrolls: helpers.limit(job, "max_scrolls", 12, 50), keyFn: (post) => post.url || post.id });
    const maxComments = helpers.limit(job, "max_comments", 10, 100);
    for (const post of posts) {
      if (!post.url || post.comment_items.length >= maxComments) continue;
      post.comment_details = await fetchPostComments(post.url, maxComments);
      post.comment_items = post.comment_details.map((comment) => comment.text);
      if (!post.comments_count) post.comments_count = post.comment_items.length;
    }
    return posts;
  }

  function collectVisiblePosts(job) {
    const maxComments = helpers.limit(job, "max_comments", 10, 100);
    const candidates = Array.from(document.querySelectorAll("shreddit-post, article, [data-testid='post-container']"));
    const posts = candidates.map((node) => {
      const title = helpers.cleanText(node.getAttribute("post-title") || node.querySelector("h1, h2, h3, a[slot='title']")?.textContent || "");
      const linkNode = node.querySelector("a[href*='/comments/'], a[slot='title'], a[href]");
      const imageNode = node.querySelector("img[src]");
      return {
        id: node.getAttribute("id") || node.getAttribute("post-id") || "",
        title,
        text: helpers.cleanText(node.querySelector("[slot='text-body'], div[slot='text-body'], p")?.textContent || ""),
        url: helpers.absoluteUrl(linkNode?.getAttribute("href") || window.location.href),
        created_at: node.getAttribute("created-timestamp") || node.querySelector("time")?.getAttribute("datetime") || "",
        score: node.getAttribute("score") || "",
        comments_count: node.getAttribute("comment-count") || "",
        image_url: helpers.absoluteUrl(imageNode?.getAttribute("src") || ""),
        comment_items: collectComments(node).slice(0, maxComments).map((comment) => comment.text),
        comment_details: collectComments(node).slice(0, maxComments)
      };
    });

    return helpers.unique(posts, (post) => post.url || post.title);
  }

  function collectComments(root) {
    return Array.from(root.querySelectorAll("shreddit-comment, [data-testid='comment'], [id^='t1_']")).map((node) => ({
      username: helpers.cleanText(node.getAttribute("author") || node.querySelector("a[href*='/user/'], a[href*='/u/']")?.textContent || "").replace(/^u\//i, ""),
      text: helpers.cleanText(node.getAttribute("body") || node.querySelector("[slot='comment'], p")?.textContent || ""),
      date: node.querySelector("time")?.getAttribute("datetime") || node.querySelector("faceplate-timeago")?.getAttribute("ts") || "",
      likes: helpers.cleanText(node.getAttribute("score") || "")
    })).filter((item) => item.text);
  }

  async function fetchPostComments(url, limit) {
    try {
      const response = await fetch(url, { credentials: "include", headers: { Accept: "text/html" } });
      if (!response.ok) return [];
      return collectComments(new DOMParser().parseFromString(await response.text(), "text/html")).slice(0, limit);
    } catch (_error) { return []; }
  }

  function parseStats() {
    const text = helpers.cleanText(document.querySelector("main, shreddit-app")?.textContent || "");
    return { followers: helpers.count(text.match(/[\d,.KMB]+\s+(?:followers|members|karma)/i)?.[0]) };
  }

  function collectImages(posts) {
    return helpers.unique(
      posts.filter((post) => post.image_url).map((post) => ({
        image_url: post.image_url,
        source_url: post.url,
        title: post.title,
        source: "reddit"
      })),
      (image) => image.image_url
    );
  }

  function findAvatar() {
    const selectors = [
      "img[alt*='Avatar']",
      "img[src*='styles.redditmedia.com']",
      "img[src*='redditstatic.com/avatars']"
    ];
    for (const selector of selectors) {
      const value = document.querySelector(selector)?.getAttribute("src");
      if (value) {
        return helpers.absoluteUrl(value);
      }
    }
    return "";
  }
})();

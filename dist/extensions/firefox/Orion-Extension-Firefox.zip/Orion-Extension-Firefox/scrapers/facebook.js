(function () {
  const helpers = window.OrionScraperHelpers;

  if (!helpers) {
    throw new Error("window.OrionScraperHelpers must be loaded before facebook.js");
  }

  // Selectors are centralized here and mirror the merged Playwright scraper.
  const POST_URL_SELECTORS = [
    "a[href*='/groups/'][href*='/posts/']",
    "a[href*='/posts/']",
    "a[href*='/permalink/']",
    "a[href*='/reel/']",
    "a[href*='/videos/']",
    "a[href*='/watch/']",
    "a[href*='/photo.php']",
    "a[href*='/photos/']",
    "a[href*='/events/']",
    "a[href*='/marketplace/item/']",
    "a[href*='story_fbid=']"
  ];

  const POST_MARKER_SELECTORS = [
    "[aria-label='Actions for this post']",
    "[data-ad-rendering-role='profile_name']",
    "[data-ad-rendering-role='story_message']",
    "[data-ad-rendering-role='like_button']",
    "[data-ad-rendering-role='comment_button']",
    "[data-ad-rendering-role='share_button']",
    "[data-ad-rendering-role='meta']",
    "[data-ad-rendering-role='title']",
    "[data-ad-rendering-role='description']",
    "img[data-imgperflogname='feedImage']",
    "video",
    ...POST_URL_SELECTORS
  ];

  const CONTENT_SELECTORS = [
    "[data-ad-rendering-role='story_message']",
    "[data-ad-comet-preview='message']",
    "[data-ad-preview='message']",
    "[data-testid='post_message']",
    "div[dir='auto'][style*='text-align']"
  ];

  const ATTACHMENT_TEXT_SELECTORS = [
    "[data-ad-rendering-role='title']",
    "[data-ad-rendering-role='description']",
    "[data-ad-rendering-role='meta']"
  ];

  const DATE_SELECTORS = [
    "time",
    "abbr[title]",
    ...POST_URL_SELECTORS
  ];

  const POST_ROOT_SELECTORS = [
    "[data-fb-scraper-post-root]",
    "div[role='article']"
  ];

  const POST_CONTAINER_SELECTOR =
    "[data-virtualized='false']:has([data-ad-rendering-role='story_message'])";

  const PROFILE_TITLE_SELECTORS = [
    "h1",
    "h2",
    "div[role='main'] strong"
  ];

  const PROFILE_IMAGE_SELECTORS = [
    "div[role='main'] a[href*='/photo'] img",
    "div[role='main'] image",
    "svg image",
    "img[alt*='profile' i]"
  ];

  const COVER_IMAGE_SELECTORS = [
    "img[data-imgperflogname='profileCoverPhoto']",
    "div[data-pagelet*='Cover'] img",
    "div[aria-label*='Cover photo' i] img",
    "img[alt*='cover photo' i]"
  ];

  const COVER_BACKGROUND_SELECTORS = [
    "div[data-pagelet*='Cover']",
    "div[aria-label*='Cover photo' i]",
    "div[style*='background-image']"
  ];

  const REACTION_SELECTORS = [
    "[aria-label^='All reactions']",
    "span[aria-label*='reaction']",
    "span[aria-label*='Reactions']",
    "[aria-label*=' people']"
  ];

  const COMMENT_ROOT_SELECTORS = [
    "[aria-label^='Comment by']",
    "[aria-label^='Reply by']",
    "[data-commentid]",
    "div[role='article']"
  ];

  const COMMENT_SELECTORS = COMMENT_ROOT_SELECTORS.join(", ");

  const COMMENT_AUTHOR_SELECTOR =
    "a[role='link'] strong, strong, h3, h4";

  const COMMENT_TIME_SELECTOR =
    "a[href*='comment_id'], a[aria-label*='Reply'], abbr, time";

  const COMMENT_LIKE_SELECTOR =
    "[aria-label*='Like'], [aria-label*='like']";

  window.OrionScrapers = window.OrionScrapers || {};
  window.OrionScrapers.facebook = {
    selectors: [
      ...PROFILE_TITLE_SELECTORS,
      ...POST_ROOT_SELECTORS,
      "[data-pagelet*='FeedUnit']",
      ...POST_MARKER_SELECTORS,
      "[role='main']"
    ],
    async run(job) {
      const username = job.username || usernameFromUrl();
      assertCanScrape(username);
      expandVisibleTruncations();

      const profile = collectProfile(username);
      const followers = shouldCollectFollowers(job) ? await collectConnectionList(job, "followers", username) : [];
      const following = shouldCollectFollowing(job) ? await collectConnectionList(job, "following", username) : [];
      const posts = shouldCollectPosts(job) ? await collectPosts(job, profile) : [];

      return {
        platform: "facebook",
        username,
        url: window.location.href,
        profile,
        posts,
        images: collectImages(posts, profile),
        followers,
        following
      };
    }
  };

  function usernameFromUrl() {
    if (/\/profile\.php$/i.test(window.location.pathname)) {
      return new URLSearchParams(window.location.search).get("id") || "";
    }
    const parts = window.location.pathname.split("/").filter(Boolean);
    const reserved = new Set(["groups", "events", "watch", "marketplace", "pages", "people", "login", "recover", "checkpoint"]);
    return parts.find((part) => !reserved.has(part.toLowerCase())) || "";
  }

  function shouldCollectPosts(job) {
    const command = String(job?.command || job?.social_data_type || "profile").toLowerCase();
    return !["followers", "following"].includes(command);
  }

  function shouldCollectFollowers(job) {
    const command = String(job?.command || job?.social_data_type || "profile").toLowerCase();
    return ["profile", "profile_info", "followers"].includes(command);
  }

  function shouldCollectFollowing(job) {
    const command = String(job?.command || job?.social_data_type || "profile").toLowerCase();
    return ["profile", "profile_info", "following"].includes(command);
  }

  function collectProfile(username) {
    const metaTitle = usefulTitle(helpers.meta("og:title") || helpers.meta("twitter:title") || "");
    const headingTitle = usefulTitle(firstText(["[role='main'] h1", ...PROFILE_TITLE_SELECTORS]));
    const fallbackTitle = splitUsername(username);
    const displayName = headingTitle || metaTitle || fallbackTitle || username;
    const stats = parseProfileStats();
    const description = cleanDescription(helpers.meta("description") || helpers.meta("og:description"));
    const bio = collectBio(description);

    const profile = {
      username,
      display_name: displayName,
      bio,
      description,
      avatar_url: findAvatar(),
      cover_url: findCover(),
      followers_count: stats.followers,
      following_count: stats.following,
      likes_count: stats.likes,
      total_followers: stats.followers,
      total_following: stats.following
    };

    if (!profile.bio && isUsefulProfileText(description)) {
      profile.bio = description;
    }
    return profile;
  }

  function usefulTitle(value) {
    const title = cleanFacebookTitle(value);
    if (!title || /^facebook$/i.test(title) || /^log in/i.test(title)) {
      return "";
    }
    return title;
  }

  function splitUsername(username) {
    return String(username || "")
      .replace(/[_\-.]+/g, " ")
      .replace(/([a-z])([A-Z])/g, "$1 $2")
      .replace(/\s+/g, " ")
      .trim();
  }

  function collectBio(description) {
    const roots = [
      document.querySelector("[data-pagelet='ProfileTilesFeed']"),
      document.querySelector("[data-pagelet*='ProfileTilesFeed']"),
      ...Array.from(document.querySelectorAll("[role='main'] [aria-label*='Intro' i], [role='main'] [aria-label*='About' i]"))
    ].filter(Boolean);

    for (const root of roots) {
      const text = cleanContentText(root.innerText || root.textContent || "");
      if (isUsefulProfileText(text)) {
        return text.slice(0, 800);
      }
    }

    return isUsefulProfileText(description) ? description.slice(0, 800) : "";
  }

  function isUsefulProfileText(text) {
    if (!text || text.length < 3) {
      return false;
    }
    if (/\b(log in|sign up|create new account|forgot password|like\s*reply|reply|comment)\b/i.test(text)) {
      return false;
    }
    return !/^facebook$/i.test(text);
  }

  function cleanDescription(value) {
    const text = helpers.cleanText(value)
      .replace(/\s*\|\s*Facebook\s*$/i, "")
      .replace(/\s*is on Facebook\..*$/i, "")
      .trim();
    return /^facebook$/i.test(text) ? "" : text;
  }

  function cleanFacebookTitle(value) {
    return helpers.cleanText(value)
      .replace(/\s*\|\s*Facebook\s*$/i, "")
      .replace(/\s*\(\d+\)\s*$/i, "")
      .trim();
  }

  function firstText(selectors, root = document) {
    for (const selector of selectors) {
      const value = helpers.cleanText(root.querySelector(selector)?.innerText || root.querySelector(selector)?.textContent || "");
      if (value) {
        return value;
      }
    }
    return "";
  }

  function parseProfileStats() {
    const text = helpers.cleanText((document.querySelector("[role='main']") || document.body)?.innerText || "");
    return {
      followers: findCount(text, "followers"),
      following: findCount(text, "following"),
      likes: findCount(text, "likes")
    };
  }

  function findCount(text, label) {
    const match = text.match(new RegExp(`([\\d.,]+\\s*[KMB]?)\\s+${label}\\b`, "i"));
    return match ? countToInt(match[1]) : "";
  }

  async function collectConnectionList(job, type, username) {
    const limitKey = type === "followers" ? "max_followers" : "max_following";
    const limit = Number(job?.limits?.[limitKey] || job?.[limitKey] || 500);
    const originalUrl = window.location.href;
    if (!username || limit <= 0) {
      return [];
    }

    try {
      const trigger = buildConnectionRouteLink(type, username) || findConnectionLink(type, username);
      if (!trigger) {
        return [];
      }
      const root = await openConnectionSurface(trigger, type);
      if (!root) {
        return [];
      }
      const users = await collectConnectionUsers(root, username, limit);
      await closeConnectionSurface(originalUrl);
      return users;
    } catch (_error) {
      await closeConnectionSurface(originalUrl);
      return [];
    }
  }

  function findConnectionLink(type, username) {
    const connectionPaths = facebookConnectionPaths(type, username);
    const candidates = Array.from(document.querySelectorAll("a[href]"));
    return candidates.find((node) => {
      const href = node.getAttribute?.("href") || "";
      const path = pathFromHref(href);
      return connectionPaths.includes(path) || path.endsWith(`/${type}`) || (type === "following" && path.endsWith("/followings"));
    }) || null;
  }

  function buildConnectionRouteLink(type, username) {
    if (/^\d+$/.test(String(username || ""))) {
      return null;
    }
    const anchor = document.createElement("a");
    anchor.href = `https://www.facebook.com/${encodeURIComponent(String(username).replace(/^\/+|\/+$/g, ""))}/${connectionRouteSegment(type)}`;
    anchor.style.position = "fixed";
    anchor.style.left = "-9999px";
    anchor.style.top = "0";
    anchor.textContent = type;
    document.documentElement.appendChild(anchor);
    return anchor;
  }

  function facebookConnectionPaths(type, username) {
    const base = String(username || "").replace(/^\/+|\/+$/g, "").toLowerCase();
    return type === "following"
      ? [`${base}/following`, `${base}/followings`]
      : [`${base}/followers`];
  }

  function connectionRouteSegment(type) {
    return type === "following" ? "following" : "followers";
  }

  function pathFromHref(href) {
    if (!href) {
      return "";
    }
    try {
      return new URL(href, window.location.href).pathname.replace(/^\/+|\/+$/g, "").toLowerCase();
    } catch (_error) {
      return String(href).split("?")[0].replace(/^\/+|\/+$/g, "").toLowerCase();
    }
  }

  async function openConnectionSurface(trigger, type) {
    const clickable = trigger.closest?.("a, button, [role='link'], [role='button']") || trigger;
    clickable.scrollIntoView?.({ block: "center", inline: "center", behavior: "auto" });
    await helpers.delay?.(500);
    clickElement(clickable);
    return waitForConnectionRoot(type, 7000);
  }

  async function waitForConnectionRoot(type, timeoutMs) {
    const startedAt = Date.now();
    while (Date.now() - startedAt < timeoutMs) {
      assertCanScrape(usernameFromUrl());
      const dialog = Array.from(document.querySelectorAll("div[role='dialog'], div[aria-modal='true']"))
        .find((node) => {
          const text = helpers.cleanText(node.textContent || "");
          return new RegExp(type, "i").test(text) || extractConnectionUsers(node, "", 5).length > 0;
        });
      if (dialog) {
        return dialog;
      }
      if (new RegExp(`/${type}/?$`, "i").test(window.location.pathname)) {
        return document.querySelector("main") || document;
      }
      await helpers.delay?.(300);
    }
    return null;
  }

  async function collectConnectionUsers(root, username, limit) {
    const users = [];
    const seen = new Set();
    const addUsers = (items) => {
      for (const item of items) {
        const key = String(item || "").toLowerCase();
        if (!key || seen.has(key) || users.length >= limit) {
          continue;
        }
        seen.add(key);
        users.push(item);
      }
    };

    addUsers(extractConnectionUsers(root, username, limit));
    let previousCount = users.length;
    let stalled = 0;
    for (let index = 0; index < 26 && users.length < limit; index += 1) {
      clickConnectionControls(root);
      for (let step = 0; step < 3; step += 1) {
        scrollConnectionContainer(root);
        await helpers.delay?.(700);
      }
      addUsers(extractConnectionUsers(root, username, limit));
      if (users.length <= previousCount) {
        stalled += 1;
      } else {
        stalled = 0;
      }
      previousCount = users.length;
      if (stalled >= 5) {
        break;
      }
    }

    return users.slice(0, limit);
  }

  function extractConnectionUsers(root, currentUsername, limit) {
    const reserved = new Set(["friends", "followers", "following", "photos", "videos", "reels", "posts", "about", "groups", "events"]);
    const users = [];
    const seen = new Set();
    for (const anchor of Array.from(root.querySelectorAll("a[href]"))) {
      const profile = userFromFacebookProfileAnchor(anchor);
      if (!profile.username || reserved.has(profile.username.toLowerCase())) {
        continue;
      }
      if (currentUsername && profile.username.toLowerCase() === String(currentUsername).toLowerCase()) {
        continue;
      }
      const key = profile.username.toLowerCase();
      if (seen.has(key)) {
        continue;
      }
      seen.add(key);
      users.push(profile.username);
      if (users.length >= limit) {
        break;
      }
    }
    return users;
  }

  function userFromFacebookProfileAnchor(anchor) {
    const href = anchor.getAttribute("href") || "";
    const profileUrl = cleanFacebookUrl(href);
    const username = usernameFromFacebookProfileUrl(profileUrl);
    if (!username || !isLikelyConnectionProfileUrl(profileUrl, username)) {
      return { username: "" };
    }
    const image = anchor.querySelector("img[src]");
    const displayName = helpers.cleanText(
      anchor.getAttribute("aria-label")
      || anchor.innerText
      || anchor.textContent
      || image?.getAttribute("alt")
      || username
    ).split("\n")[0];
    return {
      username,
      display_name: displayName || username,
      profile_url: profileUrl,
      avatar_url: cleanImageUrl(image?.currentSrc || image?.src || image?.getAttribute("src") || "")
    };
  }

  function isLikelyConnectionProfileUrl(profileUrl, username) {
    if (!profileUrl || !username) {
      return false;
    }
    try {
      const url = new URL(profileUrl, window.location.href);
      if (!url.hostname.includes("facebook.com")) {
        return false;
      }
      if (/\/profile\.php$/i.test(url.pathname)) {
        return !!url.searchParams.get("id");
      }
      const path = url.pathname.toLowerCase();
      if (/\/(?:posts|photos|videos|reel|story|stories|hashtag|groups|pages|events|marketplace|watch|permalink|privacy|policies|help|business|photo\.php)\b/i.test(path)) {
        return false;
      }
      return path === `/${username.toLowerCase()}` || path.startsWith(`/${username.toLowerCase()}/`);
    } catch (_error) {
      return false;
    }
  }

  function usernameFromFacebookProfileUrl(value) {
    if (!value) {
      return "";
    }
    try {
      const url = new URL(value, window.location.href);
      if (!url.hostname.includes("facebook.com")) {
        return "";
      }
      if (/\/profile\.php$/i.test(url.pathname)) {
        return url.searchParams.get("id") || "";
      }
      const parts = url.pathname.split("/").filter(Boolean);
      const reserved = new Set(["people", "groups", "pages", "events", "watch", "marketplace", "photo.php", "photos", "posts", "reel", "videos", "permalink", "hashtag", "stories", "story", "privacy", "policies", "business", "help", "l.php"]);
      return parts.find((part) => !reserved.has(part.toLowerCase())) || "";
    } catch (_error) {
      return "";
    }
  }

  function clickConnectionControls(root) {
    for (const control of Array.from(root.querySelectorAll("button, div[role='button'], span[role='button']"))
      .filter((node) => /see all|show more|load more|more/i.test(helpers.cleanText(node.textContent || node.getAttribute("aria-label") || "")))
      .slice(0, 5)) {
      try {
        control.scrollIntoView({ block: "center", inline: "nearest", behavior: "auto" });
        clickElement(control);
      } catch (_error) {
        // Ignore blocked controls.
      }
    }
  }

  function scrollConnectionContainer(root) {
    const target = findConnectionScrollContainer(root);
    const delta = Math.max(700, Math.floor((target?.clientHeight || window.innerHeight) * 0.9));
    if (target) {
      target.scrollTop = Math.min(target.scrollTop + delta, Math.max(0, target.scrollHeight - target.clientHeight));
      target.scrollBy?.({ top: delta, behavior: "instant" });
      target.dispatchEvent(new WheelEvent("wheel", { bubbles: true, cancelable: true, deltaY: delta }));
      return;
    }
    wheelAtElementCenter(root, delta);
  }

  function findConnectionScrollContainer(root) {
    const candidates = [
      root,
      root?.parentElement,
      ...Array.from(root.querySelectorAll("div, ul, section"))
    ].filter(Boolean);
    return candidates
      .filter((node) => node.scrollHeight > node.clientHeight + 20 && node.querySelector("a[href]"))
      .sort((left, right) => (right.scrollHeight - right.clientHeight) - (left.scrollHeight - left.clientHeight))[0] || null;
  }

  async function closeConnectionSurface(originalUrl) {
    tryClosePostOverlay();
    if (window.location.href !== originalUrl) {
      window.history.back();
      await helpers.delay?.(900);
    }
  }

  function findAvatar() {
    const metaImage = cleanImageUrl(helpers.meta("og:image") || helpers.meta("twitter:image"));
    if (metaImage && !isDefaultAvatar(metaImage)) {
      return metaImage;
    }

    for (const selector of PROFILE_IMAGE_SELECTORS) {
      const node = document.querySelector(selector);
      const value = cleanImageUrl(
        node?.getAttribute("href")
        || node?.getAttribute("xlink:href")
        || node?.getAttribute("src")
        || ""
      );
      if (value && !isLikelyCover(value) && !isDefaultAvatar(value) && !isSmallImage(node)) {
        return value;
      }
    }

    const imageCandidates = Array.from(document.images)
      .map((image) => {
        const rect = image.getBoundingClientRect();
        return {
          src: cleanImageUrl(image.currentSrc || image.src || image.getAttribute("src") || ""),
          width: rect.width || image.naturalWidth || image.width || 0,
          height: rect.height || image.naturalHeight || image.height || 0
        };
      })
      .filter((image) => image.src && !isDefaultAvatar(image.src));

    return imageCandidates.find((image) =>
      image.width >= 80
      && image.width <= 260
      && image.height >= 80
      && image.height <= 260
    )?.src || "";
  }

  function findCover() {
    for (const selector of COVER_IMAGE_SELECTORS) {
      const node = document.querySelector(selector);
      const value = cleanImageUrl(
        node?.getAttribute("src")
        || node?.getAttribute("href")
        || node?.getAttribute("xlink:href")
        || ""
      );
      if (value && !isDefaultAvatar(value)) {
        return value;
      }
    }

    for (const selector of COVER_BACKGROUND_SELECTORS) {
      const node = document.querySelector(selector);
      if (!node) {
        continue;
      }
      const value = backgroundImageUrl(node);
      if (value && !isDefaultAvatar(value)) {
        return value;
      }
    }

    const avatar = findAvatar();
    return Array.from(document.images)
      .map((image) => {
        const rect = image.getBoundingClientRect();
        return {
          src: cleanImageUrl(image.currentSrc || image.src || image.getAttribute("src") || ""),
          width: rect.width || image.naturalWidth || image.width || 0,
          height: rect.height || image.naturalHeight || image.height || 0,
          top: rect.top
        };
      })
      .find((image) =>
        image.src
        && image.src !== avatar
        && image.width > 320
        && image.height > 90
        && image.top < 700
      )?.src || "";
  }

  function backgroundImageUrl(node) {
    const raw = window.getComputedStyle(node).backgroundImage || "";
    const match = raw.match(/url\(["']?([^"')]+)["']?\)/i);
    return cleanImageUrl(match?.[1] || "");
  }

  function cleanImageUrl(value) {
    const absolute = helpers.absoluteUrl(value);
    if (!absolute || absolute.startsWith("data:") || /static\.xx\.fbcdn\.net/i.test(absolute)) {
      return "";
    }
    return absolute;
  }

  function isLikelyCover(value) {
    return /cover|profileCoverPhoto/i.test(String(value || ""));
  }

  function isDefaultAvatar(value) {
    return /\/v\/t1\.30497-1\//i.test(String(value || ""));
  }

  function isSmallImage(node) {
    if (!node) {
      return false;
    }
    const rect = node.getBoundingClientRect?.() || {};
    const width = rect.width || node.naturalWidth || node.width || 0;
    const height = rect.height || node.naturalHeight || node.height || 0;
    return width > 0 && height > 0 && (width < 80 || height < 80);
  }

  async function collectPosts(job, profile) {
    const limit = Number(job?.limits?.max_posts || job?.max_posts || 10);
    const maxScrolls = Number(job?.limits?.max_scrolls || job?.max_scrolls || 12);
    const targets = await collectPostTargets(profile, limit, maxScrolls);
    return processPostTargets(targets, limit);
  }

  async function collectPostTargets(profile, limit, maxScrolls) {
    const targets = [];
    const seen = new Set();
    let idleScrolls = 0;

    for (let scrollIndex = 0; targets.length < limit && scrollIndex <= maxScrolls; scrollIndex += 1) {
      const targetsBeforeScroll = targets.length;
      const visiblePostsBeforeScroll = postContainerSignature();
      expandVisibleTruncations();
      await helpers.delay?.(250);

      for (const node of getPostContainers()) {
        if (targets.length >= limit) {
          break;
        }
        try {
          if (!isPostContainer(node)) {
            continue;
          }
          if (expandVisibleTruncations(node)) {
            await helpers.delay?.(100);
          }
          const post = postFromNode(node, profile);
          if (!hasPostPayload(post) || !post.url) {
            continue;
          }
          const key = post.url;
          if (seen.has(key)) {
            continue;
          }
          seen.add(key);
          targets.push({
            url: key,
            post,
            node,
            link: findPostLink(node)
          });
        } catch (_error) {
          continue;
        }
      }

      idleScrolls = targets.length === targetsBeforeScroll ? idleScrolls + 1 : 0;
      if (targets.length >= limit || scrollIndex === maxScrolls) {
        break;
      }
      if (idleScrolls >= 5) {
        break;
      }
      scrollPosts(scrollIndex);
      await waitForPostContainersToChange(visiblePostsBeforeScroll);
    }

    return targets;
  }

  async function processPostTargets(targets, limit) {
    const posts = [];
    const seen = new Set();
    for (const target of targets.slice(0, limit)) {
      const post = { ...target.post };
      try {
        await enrichPostFromPopup(post, target, isReelPost(post) ? 3500 : 6500);
      } catch (_error) {
        // Keep the feed snapshot if Facebook blocks the popup or rerenders the node.
      }
      const key = stablePostKey(post);
      if (key && seen.has(key)) {
        continue;
      }
      if (key) {
        seen.add(key);
      }
      posts.push(post);
      await helpers.delay?.(250);
    }
    return posts;
  }

  function stablePostKey(post) {
    const id = postIdFromUrl(post?.url || "");
    if (id) {
      return `id:${id}`;
    }
    const url = cleanFacebookUrl(post?.url || "");
    if (url) {
      return `url:${url}`;
    }
    const text = helpers.cleanText(`${post?.title || ""} ${post?.created_at || ""} ${post?.text || ""}`).slice(0, 240);
    return text ? `text:${text}` : "";
  }

  function getPostContainers() {
    markPostRoots();
    const containers = [];
    const seen = new Set();
    const candidates = [
      ...POST_ROOT_SELECTORS.flatMap((selector) => Array.from(document.querySelectorAll(selector))),
      ...Array.from(document.querySelectorAll(POST_CONTAINER_SELECTOR)),
      ...POST_MARKER_SELECTORS.flatMap((selector) => Array.from(document.querySelectorAll(selector)))
        .map((marker) => bestPostContainerForMarker(marker))
        .filter(Boolean)
    ];

    for (const node of candidates) {
      const key = node.dataset?.fbScraperContainerKey || assignContainerKey(node);
      if (seen.has(key)) {
        continue;
      }
      seen.add(key);
      containers.push(node);
    }
    return containers.sort((left, right) => {
      const leftTop = left.getBoundingClientRect?.().top ?? 0;
      const rightTop = right.getBoundingClientRect?.().top ?? 0;
      return leftTop - rightTop;
    });
  }

  function markPostRoots() {
    let index = Number(document.documentElement.dataset.fbScraperPostSeq || "0");
    const markers = document.querySelectorAll(POST_MARKER_SELECTORS.join(","));
    for (const marker of markers) {
      const root = bestPostContainerForMarker(marker);
      if (root && !root.dataset.fbScraperPostRoot) {
        index += 1;
        root.dataset.fbScraperPostRoot = String(index);
      }
    }
    document.documentElement.dataset.fbScraperPostSeq = String(index);
  }

  function assignContainerKey(node) {
    const key = `fb-post-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    try {
      node.dataset.fbScraperContainerKey = key;
    } catch (_error) {
      // Dataset writes can fail on unusual DOM nodes; use geometry fallback.
    }
    return key;
  }

  function bestPostContainerForStory(story) {
    return bestPostContainerForMarker(story);
  }

  function bestPostContainerForMarker(marker) {
    const candidates = [];
    const article = marker.closest?.("div[role='article']");
    if (article) {
      candidates.push(article);
    }
    for (let node = marker; node && node !== document.body; node = node.parentElement) {
      if (node.matches?.("[data-virtualized='false']") && node.querySelector("[data-ad-rendering-role='story_message']")) {
        candidates.push(node);
      }
      const hasProfile = !!node.querySelector("[data-ad-rendering-role='profile_name']");
      const hasBody = !!node.querySelector(POST_MARKER_SELECTORS.join(","));
      if (hasProfile && hasBody) {
        candidates.push(node);
      }
      if (candidates.length >= 8) {
        break;
      }
    }
    if (!candidates.length) {
      return null;
    }
    return candidates
      .map((node) => ({ node, score: postContainerScore(node) }))
      .sort((left, right) => right.score - left.score)[0]?.node || candidates[0];
  }

  function postContainerScore(node) {
    const storyCount = node.querySelectorAll("[data-ad-rendering-role='story_message']").length;
    const rect = node.getBoundingClientRect?.() || {};
    let score = 0;
    if (findPostLink(node)) score += 80;
    if (node.querySelector("[data-ad-rendering-role='profile_name']")) score += 20;
    if (node.querySelector("[data-ad-rendering-role='like_button']")) score += 10;
    if (node.querySelector("[data-ad-rendering-role='comment_button']")) score += 10;
    if (node.querySelector("[data-ad-rendering-role='share_button']")) score += 10;
    if (node.querySelector("[data-ad-rendering-role='title']")) score += 8;
    if (node.querySelector("[data-ad-rendering-role='description']")) score += 8;
    if (node.querySelector("img[data-imgperflogname='feedImage']")) score += 25;
    if (node.querySelector("video")) score += 25;
    if (rect.height > 120) score += 5;
    if (storyCount === 1) score += 20;
    if (storyCount > 3) score -= storyCount * 25;
    return score;
  }

  function postContainerSignature() {
    return getPostContainers()
      .slice(0, 8)
      .map((node) => {
        const link = findPostLink(node);
        const url = cleanFacebookUrl(link?.getAttribute("href") || "");
        const text = helpers.cleanText(node.querySelector("[data-ad-rendering-role='story_message']")?.innerText || node.textContent || "");
        const rect = node.getBoundingClientRect?.() || {};
        return `${url}|${text.slice(0, 120)}|${Math.round(rect.top || 0)}`;
      })
      .join("||");
  }

  function scrollPosts(scrollIndex) {
    const amount = Math.max(900, Math.floor(window.innerHeight * (1.05 + Math.min(scrollIndex, 4) * 0.08)));
    const target = getScrollTarget();
    const containers = getPostContainers();
    const lastPost = containers[containers.length - 1];

    if (lastPost?.scrollIntoView) {
      lastPost.scrollIntoView({ block: "end", inline: "nearest", behavior: "auto" });
    }
    if (target && target !== document.documentElement && target !== document.body) {
      target.scrollBy({ top: amount, behavior: "auto" });
      target.scrollTop += amount;
      target.dispatchEvent(new WheelEvent("wheel", { deltaY: amount, bubbles: true, cancelable: true }));
    }
    window.scrollBy({ top: amount, behavior: "auto" });
    window.dispatchEvent(new WheelEvent("wheel", { deltaY: amount, bubbles: true, cancelable: true }));
    document.dispatchEvent(new KeyboardEvent("keydown", { key: "PageDown", code: "PageDown", bubbles: true }));
  }

  function getScrollTarget() {
    const candidates = [
      ...Array.from(document.querySelectorAll("div[role='feed'], div[role='main'], div[aria-label*='Feed' i]")),
      document.querySelector("[role='main']"),
      document.scrollingElement,
      document.documentElement,
      document.body
    ].filter(Boolean);

    return candidates.find((node) => {
      if (node === document.scrollingElement || node === document.documentElement || node === document.body) {
        return true;
      }
      const style = window.getComputedStyle(node);
      const canScroll = /(auto|scroll)/i.test(`${style.overflowY} ${style.overflow}`);
      return canScroll && node.scrollHeight > node.clientHeight + 50;
    }) || document.scrollingElement || document.documentElement;
  }

  async function waitForPostContainersToChange(previousSignature) {
    const startedAt = Date.now();
    while (Date.now() - startedAt < 2800) {
      await helpers.delay?.(250);
      const nextSignature = postContainerSignature();
      if (nextSignature && nextSignature !== previousSignature) {
        return true;
      }
    }
    await helpers.delay?.(700);
    return false;
  }

  function isPostContainer(node) {
    const aria = helpers.cleanText(node.getAttribute("aria-label") || "").toLowerCase();
    if (aria.startsWith("comment by") || aria.startsWith("reply by")) {
      return false;
    }
    if (node.matches(`[data-commentid], ${COMMENT_SELECTORS}`) || node.closest("[data-commentid]")) {
      return false;
    }
    if (looksLikeStandaloneComment(node)) {
      return false;
    }

    const hasPostRole = !!node.querySelector([
      "[data-ad-rendering-role='profile_name']",
      "[data-ad-rendering-role='story_message']",
      "[data-ad-comet-preview='message']",
      "[data-ad-preview='message']",
      "[data-testid='post_message']",
      "[data-ad-rendering-role='like_button']",
      "[data-ad-rendering-role='comment_button']",
      "[data-ad-rendering-role='share_button']",
      "[data-ad-rendering-role='title']",
      "[data-ad-rendering-role='description']",
      "img[data-imgperflogname='feedImage']",
      "video"
    ].join(","));
    return hasPostRole || !!findPostLink(node);
  }

  function looksLikeStandaloneComment(node) {
    const text = normalizeText(node.innerText || node.textContent || "");
    if (!text) {
      return true;
    }
    const hasPostMarker = !!node.querySelector([
      "[data-ad-rendering-role='profile_name']",
      "[data-ad-rendering-role='story_message']",
      "[data-ad-comet-preview='message']",
      "[data-ad-preview='message']",
      "[data-ad-rendering-role='like_button']",
      "[data-ad-rendering-role='comment_button']",
      "[data-ad-rendering-role='share_button']",
      "[data-ad-rendering-role='title']",
      "[data-ad-rendering-role='description']",
      "img[data-imgperflogname='feedImage']",
      "video"
    ].join(","));
    if (/Like\s*Reply/i.test(text) && !hasPostMarker) {
      return true;
    }
    return /^(comment|reply) by\b/i.test(helpers.cleanText(node.getAttribute("aria-label") || ""));
  }

  function postFromNode(node, profile) {
    const rawText = node.innerText || node.textContent || "";
    const link = findPostLink(node);
    const url = cleanFacebookUrl(link?.getAttribute("href") || "");
    const media = extractMedia(node);
    const content = extractContent(node, rawText);
    const date = extractPostDate(node, rawText, link);

    return {
      id: postIdFromUrl(url),
      title: extractPostTitle(node) || profile.display_name || "Facebook post",
      text: content,
      url,
      created_at: date,
      likes_count: extractLikes(node, rawText),
      comments_count: extractComments(node, rawText),
      shares_count: extractShares(node, rawText),
      loaded_comments: extractLoadedComments(node),
      type: detectPostType(url, media, rawText, node),
      image_url: media.images[0] || "",
      images: media.images,
      videos: media.videos,
      video_blobs: media.video_blobs,
      attachment_urls: media.attachment_urls,
      source: "facebook"
    };
  }

  function hasPostPayload(post) {
    return !!(post.url || post.text || post.image_url || post.videos.length || post.video_blobs || post.attachment_urls.length);
  }

  async function enrichPostDetails(post, node, timeoutMs = 6000) {
    const maxComments = 50;
    const scrollState = captureScrollState();
    const deadlineAt = Date.now() + timeoutMs;
    try {
      if (isPastDeadline(deadlineAt)) {
        return;
      }
      const opened = await openPostComments(node, post);
      if (isPastDeadline(deadlineAt)) {
        return;
      }
      await expandVisibleComments(node);
      if (isPastDeadline(deadlineAt)) {
        return;
      }
      if (opened && hasOpenPostOverlay()) {
        await expandVisibleComments(document, deadlineAt);
      }
      const containerComments = extractLoadedComments(node);
      const pageComments = extractLoadedComments(document);
      post.loaded_comments = uniqueStrings([...containerComments, ...pageComments]).slice(0, maxComments);
      if (!post.comments_count) {
        post.comments_count = extractComments(node, node.innerText || node.textContent || "");
      }
    } catch (_error) {
      // Keep the feed post even when Facebook refuses to open comment UI.
    } finally {
      tryClosePostOverlay();
      closeReelOverlay();
      restoreScrollState(scrollState);
      await helpers.delay?.(200);
    }
  }

  async function enrichPostFromPopup(post, target, timeoutMs = 6500) {
    const maxComments = 50;
    const scrollState = captureScrollState();
    const deadlineAt = Date.now() + timeoutMs;
    let opened = false;
    try {
      opened = await openPostPopup(target, deadlineAt);
      if (!opened || isPastDeadline(deadlineAt)) {
        return;
      }

      const popup = findOpenPostPopup();
      const detailRoot = popup || document;
      await expandVisibleTruncations(detailRoot);
      await loadPopupComments(detailRoot, maxComments, deadlineAt);

      const rawText = detailRoot.innerText || detailRoot.textContent || "";
      const media = extractMedia(detailRoot);
      const content = extractContent(detailRoot, rawText);
      const link = findPostLink(detailRoot);
      const detailUrl = chooseBestPostUrl(post.url || target.url, link?.getAttribute("href") || "");

      post.url = detailUrl || post.url || target.url;
      post.id = postIdFromUrl(post.url) || post.id;
      post.title = extractPostTitle(detailRoot) || post.title;
      post.text = content || post.text;
      post.created_at = extractPostDate(detailRoot, rawText, link) || post.created_at;
      post.likes_count = extractLikes(detailRoot, rawText) || post.likes_count;
      post.comments_count = extractComments(detailRoot, rawText) || post.comments_count;
      post.shares_count = extractShares(detailRoot, rawText) || post.shares_count;
      post.loaded_comments = uniqueStrings([
        ...(post.loaded_comments || []),
        ...extractLoadedComments(detailRoot)
      ]).slice(0, maxComments);
      post.images = uniqueStrings([...(post.images || []), ...media.images]);
      post.image_url = post.images[0] || post.image_url || "";
      post.videos = uniqueStrings([...(post.videos || []), ...media.videos]);
      post.video_blobs = Math.max(Number(post.video_blobs || 0), Number(media.video_blobs || 0));
      post.attachment_urls = uniqueStrings([...(post.attachment_urls || []), ...media.attachment_urls]);
      post.type = detectPostType(post.url, media, rawText, detailRoot) || post.type;
    } catch (_error) {
      // Keep the collected feed snapshot when popup extraction fails.
    } finally {
      if (opened) {
        tryClosePostOverlay();
        closeReelOverlay();
      }
      restoreScrollState(scrollState);
      await helpers.delay?.(250);
    }
  }

  async function openPostPopup(target, deadlineAt) {
    const link = findLivePostLink(target);
    if (!link || isPastDeadline(deadlineAt)) {
      return false;
    }

    link.scrollIntoView?.({ block: "center", inline: "nearest", behavior: "auto" });
    await helpers.delay?.(250);
    const beforeHref = window.location.href;
    clickElement(link);

    while (!isPastDeadline(deadlineAt)) {
      await helpers.delay?.(250);
      if (findOpenPostPopup()) {
        return true;
      }
      if (window.location.href !== beforeHref) {
        window.history.back();
        await helpers.delay?.(700);
        return false;
      }
    }
    return false;
  }

  function findLivePostLink(target) {
    const url = cleanFacebookUrl(target?.url || target?.post?.url || "");
    const existing = target?.link;
    if (existing?.isConnected && cleanFacebookUrl(existing.getAttribute("href") || "") === url) {
      return existing;
    }
    if (target?.node?.isConnected) {
      const link = findPostLink(target.node);
      if (link && cleanFacebookUrl(link.getAttribute("href") || "") === url) {
        return link;
      }
    }
    return Array.from(document.querySelectorAll(POST_URL_SELECTORS.join(",")))
      .find((link) => cleanFacebookUrl(link.getAttribute("href") || "") === url) || null;
  }

  function findOpenPostPopup() {
    return Array.from(document.querySelectorAll("div[role='dialog'], div[aria-modal='true']"))
      .find((dialog) => {
        const rect = dialog.getBoundingClientRect?.() || {};
        if (!rect.width || !rect.height) {
          return false;
        }
        return !!dialog.querySelector([
          "[data-ad-rendering-role='story_message']",
          "[data-ad-rendering-role='comment_button']",
          "[data-commentid]",
          "[aria-label^='Comment by']",
          "[aria-label^='Reply by']",
          "a[href*='/posts/']",
          "a[href*='/reel/']",
          "a[href*='story_fbid=']"
        ].join(","));
      }) || null;
  }

  async function openPostComments(node, post) {
    const commentButton = node.querySelector("[data-ad-rendering-role='comment_button']");
    if (commentButton) {
      clickElement(commentButton);
      await helpers.delay?.(900);
      return true;
    }

    return false;
  }

  function isReelPost(post) {
    return String(post?.type || "").toLowerCase() === "reel" || /\/reel\//i.test(String(post?.url || ""));
  }

  function isPastDeadline(deadlineAt) {
    return Number.isFinite(deadlineAt) && Date.now() >= deadlineAt;
  }

  async function expandVisibleComments(root = document, deadlineAt = 0) {
    for (let pass = 0; pass < 4; pass += 1) {
      if (isPastDeadline(deadlineAt)) {
        break;
      }
      let clicked = 0;
      for (const element of root.querySelectorAll("div[role='button'], span[role='button'], a[role='link'], a[href], span")) {
        if (isPastDeadline(deadlineAt)) {
          break;
        }
        const text = helpers.cleanText(element.innerText || element.textContent || "");
        if (!/^(view|see|show)\s+(more|previous|all)?\s*(comments?|replies?)|more comments?|view previous replies$/i.test(text)) {
          continue;
        }
        const rect = element.getBoundingClientRect?.() || {};
        if (!rect.width || !rect.height) {
          continue;
        }
        clickElement(element);
        clicked += 1;
        if (clicked >= 8) {
          break;
        }
      }
      if (!clicked) {
        break;
      }
      await helpers.delay?.(900);
    }
  }

  async function scrollPopupForComments(root, deadlineAt = 0) {
    const popup = root?.matches?.("div[role='dialog'], div[aria-modal='true']")
      ? root
      : findOpenPostPopup();
    if (!popup) {
      return;
    }

    for (let pass = 0; pass < 5; pass += 1) {
      if (isPastDeadline(deadlineAt)) {
        break;
      }
      wheelAtElementCenter(popup, 850 + pass * 180);
      await helpers.delay?.(650);
      await expandVisibleComments(popup, deadlineAt);
    }
  }

  async function loadPopupComments(root, maxComments, deadlineAt = 0) {
    let previousCount = 0;
    let stalled = 0;
    for (let pass = 0; pass < 12; pass += 1) {
      if (isPastDeadline(deadlineAt)) {
        break;
      }

      await expandVisibleComments(root, deadlineAt);
      await scrollPopupForComments(root, deadlineAt);
      const currentCount = extractLoadedComments(root).length;

      if (currentCount >= maxComments) {
        break;
      }
      if (currentCount <= previousCount) {
        stalled += 1;
      } else {
        stalled = 0;
      }
      previousCount = currentCount;
      if (stalled >= 3) {
        break;
      }
      await helpers.delay?.(550);
    }
  }

  function wheelAtElementCenter(element, deltaY) {
    const rect = element.getBoundingClientRect?.() || {};
    if (!rect.width || !rect.height) {
      return;
    }
    const clientX = Math.floor(rect.left + rect.width / 2);
    const clientY = Math.floor(rect.top + rect.height / 2);
    const target = document.elementFromPoint(clientX, clientY) || element;
    try {
      target.dispatchEvent(new WheelEvent("wheel", {
        bubbles: true,
        cancelable: true,
        clientX,
        clientY,
        deltaY,
        view: window
      }));
      const scrollTarget = nearestScrollable(target, element);
      if (scrollTarget) {
        scrollTarget.scrollTop += deltaY;
      }
    } catch (_error) {
      // Ignore blocked synthetic wheel events.
    }
  }

  function nearestScrollable(start, boundary) {
    for (let node = start; node && node !== document.body; node = node.parentElement) {
      const style = window.getComputedStyle(node);
      const canScroll = /(auto|scroll)/i.test(`${style.overflowY} ${style.overflow}`);
      if (canScroll && node.scrollHeight > node.clientHeight + 20) {
        return node;
      }
      if (node === boundary) {
        break;
      }
    }
    return boundary?.scrollHeight > boundary?.clientHeight + 20 ? boundary : null;
  }

  function clickElement(element) {
    try {
      element.dispatchEvent(new MouseEvent("mouseover", { bubbles: true, cancelable: true, view: window }));
      element.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true, view: window }));
      element.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true, view: window }));
      element.click();
    } catch (_error) {
      // Ignore blocked synthetic interactions.
    }
  }

  function tryClosePostOverlay() {
    const closeButton = Array.from(document.querySelectorAll(
      "div[aria-label='Close'][role='button'], div[aria-label='Close'], div[aria-label='Close dialog'][role='button'], div[aria-label='Back'][role='button']"
    ))
      .find((button) => {
        const rect = button.getBoundingClientRect?.() || {};
        return rect.width && rect.height;
      });
    if (closeButton) {
      clickElement(closeButton);
    }
  }

  function closeReelOverlay() {
    if (!hasOpenPostOverlay()) {
      return;
    }
    try {
      document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", bubbles: true }));
      window.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", bubbles: true }));
    } catch (_error) {
      // Ignore blocked synthetic key events.
    }
  }

  function hasOpenPostOverlay() {
    return !!document.querySelector(
      "div[role='dialog'], div[aria-modal='true'], div[aria-label='Reels viewer'], div[aria-label*='reel' i]"
    );
  }

  function captureScrollState() {
    const target = getScrollTarget();
    return {
      target,
      targetTop: target?.scrollTop || 0,
      windowX: window.scrollX,
      windowY: window.scrollY
    };
  }

  function restoreScrollState(state) {
    if (!state) {
      return;
    }
    try {
      if (state.target && state.target !== document.documentElement && state.target !== document.body) {
        state.target.scrollTop = state.targetTop;
      }
      window.scrollTo({ left: state.windowX, top: state.windowY, behavior: "auto" });
    } catch (_error) {
      // Ignore scroll restoration failures after Facebook rerenders.
    }
  }

  function uniqueStrings(values) {
    const seen = new Set();
    return values.filter((value) => {
      const key = helpers.cleanText(value);
      if (!key || seen.has(key)) {
        return false;
      }
      seen.add(key);
      return true;
    });
  }

  function extractPostTitle(node) {
    const profileName = firstText(["[data-ad-rendering-role='profile_name']", "h2 strong", "h3 strong", "strong"], node);
    if (profileName && !isNoiseLine(profileName)) {
      return profileName;
    }
    const labelledLink = Array.from(node.querySelectorAll("a[aria-label]"))
      .map((link) => helpers.cleanText(link.getAttribute("aria-label") || ""))
      .find((label) => label && !isIgnoredLinkLabel(label) && !isNoiseLine(label));
    return labelledLink || "";
  }

  function findPostLink(node) {
    for (const root of postLinkSearchRoots(node)) {
      const link = firstPostLinkInRoot(root);
      if (link) {
        return link;
      }
    }
    return null;
  }

  function postLinkSearchRoots(node) {
    const roots = [];
    const seen = new Set();
    for (let current = node; current && current !== document.body; current = current.parentElement) {
      if (!seen.has(current)) {
        seen.add(current);
        roots.push(current);
      }
      if (roots.length >= 8) {
        break;
      }
    }
    return roots;
  }

  function firstPostLinkInRoot(root) {
    for (const selector of POST_URL_SELECTORS) {
      for (const link of root.querySelectorAll(selector)) {
        if (isUsablePostLink(link)) {
          return link;
        }
      }
    }
    return null;
  }

  function isUsablePostLink(link) {
    const label = helpers.cleanText(link.getAttribute("aria-label") || "").toLowerCase();
    if (isIgnoredLinkLabel(label)) {
      return false;
    }
    const href = link.getAttribute("href") || "";
    if (!href || isCommentPermalink(href)) {
      return false;
    }
    return isSpecificFacebookPostUrl(cleanFacebookUrl(href));
  }

  function isSpecificFacebookPostUrl(value) {
    if (!value) {
      return false;
    }
    try {
      const url = new URL(value, window.location.href);
      if (!url.hostname.includes("facebook.com")) {
        return false;
      }
      if (postIdFromUrl(url.href)) {
        return true;
      }
      if (/\/(?:reel|watch|videos?|posts|photos?|permalink)\/?$/i.test(url.pathname)) {
        return false;
      }
      return url.searchParams.has("story_fbid") || url.searchParams.has("fbid");
    } catch (_error) {
      return false;
    }
  }

  function isIgnoredLinkLabel(label) {
    return ["enlarge", "comment", "like", "share", "react", "play", "mute", "reply"].includes(String(label || "").trim().toLowerCase());
  }

  function isCommentPermalink(value) {
    try {
      const url = new URL(value, window.location.href);
      return url.searchParams.has("comment_id") || /comment_id=/i.test(url.href);
    } catch (_error) {
      return /comment_id=/i.test(String(value || ""));
    }
  }

  function extractContent(node, rawText) {
    const contentParts = [];
    for (const selector of CONTENT_SELECTORS) {
      for (const element of node.querySelectorAll(selector)) {
        appendUnique(contentParts, cleanContentText(element.innerText || element.textContent || ""));
      }
    }
    if (contentParts.length) {
      return contentParts.join("\n").trim().slice(0, 4000);
    }

    const attachmentParts = [];
    for (const selector of ATTACHMENT_TEXT_SELECTORS) {
      for (const element of node.querySelectorAll(selector)) {
        appendUnique(attachmentParts, cleanContentText(element.innerText || element.textContent || ""));
      }
    }
    if (attachmentParts.length) {
      return attachmentParts.join("\n").trim().slice(0, 4000);
    }

    const lines = cleanContentText(rawText).split("\n");
    if (lines.length > 1 && lines[0].split(/\s+/).length <= 5) {
      lines.shift();
    }
    return lines.join("\n").trim().slice(0, 4000);
  }

  function appendUnique(parts, rawText) {
    for (const line of normalizeText(rawText).split("\n")) {
      if (line && !parts.includes(line)) {
        parts.push(line);
      }
    }
  }

  function normalizeText(rawText) {
    return String(rawText || "")
      .replace(/\r/g, "\n")
      .split("\n")
      .map((line) => line.replace(/\s+/g, " ").trim())
      .filter(Boolean)
      .join("\n")
      .trim();
  }

  function cleanContentText(rawText) {
    const cleaned = [];
    for (const line of normalizeText(rawText).split("\n")) {
      if (!isNoiseLine(line) && !cleaned.includes(line)) {
        cleaned.push(line);
      }
    }
    return cleaned.join("\n").trim();
  }

  function isNoiseLine(line) {
    const low = String(line || "").trim().toLowerCase();
    if (!low) {
      return true;
    }
    const skipWords = new Set([
      "facebook",
      "like",
      "comment",
      "share",
      "reply",
      "send",
      "react",
      "follow",
      "all reactions:",
      "see more",
      "show more",
      "view more comments",
      "write a comment...",
      "write a comment…",
      "shared with public",
      "public",
      "m.me",
      "facebook.com",
      "www.facebook.com"
    ]);
    if (skipWords.has(low)) {
      return true;
    }
    if (/\b(actions for this post|write a comment|like\s*reply|see original)\b/i.test(low)) {
      return true;
    }
    if (/\b(like|comment|share|send|react|reply)\b/i.test(low) && low.split(/\s+/).length <= 8) {
      return true;
    }
    if (/\b\d+(?:\.\d+)?[km]?\s*(views?|shares?|comments?|reactions?|likes?|followers?|following|members?)\b/i.test(low)) {
      return true;
    }
    if (/^\d+(?:\.\d+)?[km]?$/.test(low)) {
      return true;
    }
    if (/\.com$/.test(low) && !/\s/.test(low)) {
      return true;
    }
    if (low.length >= 40 && !/\s/.test(low) && /^[a-z0-9_=-]+$/i.test(low)) {
      return true;
    }
    return isDateLike(line);
  }

  function extractPostDate(node, rawText, link) {
    const candidates = [];
    for (const selector of DATE_SELECTORS) {
      for (const element of node.querySelectorAll(selector)) {
        for (const attr of ["datetime", "title", "aria-label"]) {
          const value = element.getAttribute(attr);
          if (value && !/reply|comment/i.test(value)) {
            candidates.push(value);
          }
        }
        const visible = helpers.cleanText(element.innerText || element.textContent || "");
        if (visible) {
          candidates.push(visible);
        }
      }
    }
    for (const attr of ["datetime", "title", "aria-label"]) {
      const value = link?.getAttribute(attr);
      if (value) {
        candidates.unshift(value);
      }
    }
    candidates.push(rawText);

    for (const candidate of candidates) {
      const parsed = parseDateText(candidate);
      if (parsed) {
        return parsed;
      }
    }
    return "";
  }

  function isDateLike(value) {
    return !!parseDateText(value);
  }

  function parseDateText(value) {
    const text = helpers.cleanText(String(value || "").replace(/·/g, " "));
    if (!text) {
      return "";
    }
    const patterns = [
      /\b\d{1,2}\s+[A-Za-z]{3,9}\s+\d{4}\b/,
      /\b[A-Za-z]{3,9}\s+\d{1,2},\s*\d{4}\b/,
      /\b\d{4}-\d{2}-\d{2}\b/,
      /\b(today|yesterday)\b/i,
      /\b\d+\s*(h|hr|hrs|hour|hours|m|min|mins|minute|minutes|d|day|days|w|week|weeks)\b/i,
      /\b\d{1,2}\s+[A-Za-z]{3,9}\b/,
      /\b[A-Za-z]{3,9}\s+\d{1,2}\b/
    ];
    const matched = patterns.map((pattern) => text.match(pattern)?.[0]).find(Boolean);
    return matched || "";
  }

  function extractLikes(node, rawText) {
    const text = helpers.cleanText(rawText);
    const reactionText = helpers.cleanText(
      node.querySelector("[data-ad-rendering-role='like_button']")?.innerText || ""
    );

    const directMatch =
      reactionText.match(/([0-9.,kKmMbB]+)/i)
      || text.match(/all reactions:\s*([0-9.,kKmMbB]+)/i)
      || text.match(/([0-9.,kKmMbB]+)\s*(reactions?|likes?)\b/i);

    if (directMatch) {
      return countToInt(directMatch[1]);
    }

    let reactionTotal = 0;
    const reactionLabels = Array.from(node.querySelectorAll("[aria-label*=' people']"))
      .map((element) => element.getAttribute("aria-label") || "")
      .filter((label) => /^(like|love|care|haha|wow|sad|angry):/i.test(label));

    for (const label of reactionLabels) {
      const count = countToInt(label);
      if (count !== "") {
        reactionTotal += count;
      }
    }
    if (reactionTotal) {
      return reactionTotal;
    }

    for (const selector of REACTION_SELECTORS) {
      const element = node.querySelector(selector);
      if (!element) {
        continue;
      }
      const value = helpers.cleanText(
        element.getAttribute("aria-label")
        || element.innerText
        || element.textContent
        || ""
      );
      const count = countToInt(value);
      if (count !== "") {
        return count;
      }
    }

    return "";
  }

  function extractComments(node, rawText) {
    const candidates = [
      node.querySelector("[data-ad-rendering-role='comment_button']")?.innerText || "",
      ...Array.from(node.querySelectorAll("a[href*='comment_id'], a[href*='/comment/'], a[href*='comments']"))
        .flatMap((element) => [
          element.getAttribute("aria-label") || "",
          element.innerText || "",
          element.textContent || ""
        ]),
      rawText
    ].map((value) => helpers.cleanText(value));

    return firstCount(candidates, [
      /([0-9.,kKmMbB]+)\s*(?:comments?|replies?)\b/i,
      /(?:comments?|replies?)\s*[:·]?\s*([0-9.,kKmMbB]+)/i,
      /view\s+(?:all\s+)?([0-9.,kKmMbB]+)\s*(?:comments?|replies?)/i
    ]);
  }

  function extractShares(node, rawText) {
    const candidates = [
      node.querySelector("[data-ad-rendering-role='share_button']")?.innerText || "",
      ...Array.from(node.querySelectorAll("[aria-label*='share' i], a[href*='share']"))
        .flatMap((element) => [
          element.getAttribute("aria-label") || "",
          element.innerText || "",
          element.textContent || ""
        ]),
      rawText
    ].map((value) => helpers.cleanText(value));

    return firstCount(candidates, [
      /([0-9.,kKmMbB]+)\s*shares?\b/i,
      /shares?\s*[:·]?\s*([0-9.,kKmMbB]+)/i
    ]);
  }

  function firstCount(candidates, patterns) {
    for (const text of candidates) {
      if (!text) {
        continue;
      }
      for (const pattern of patterns) {
        const match = text.match(pattern);
        if (!match) {
          continue;
        }
        const count = countToInt(match[1]);
        if (count !== "") {
          return count;
        }
      }
    }
    return "";
  }

  function extractLoadedComments(node) {
    const roots = Array.from(node.querySelectorAll(COMMENT_SELECTORS))
      .filter((root) => {
        const text = helpers.cleanText(root.innerText || root.textContent || "");
        return text && !/write a comment|view more comments|most relevant/i.test(text);
      });

    return uniqueStrings(roots.map((root) => {
      const label = helpers.cleanText(root.getAttribute("aria-label") || "");
      const labelMatch = label.match(/^(?:Comment|Reply) by\s+(.+?)(?:\s+\d|$)/i);
      const username = labelMatch?.[1]
        || helpers.cleanText(root.querySelector(COMMENT_AUTHOR_SELECTOR)?.innerText || "");

      const time = helpers.cleanText(
        root.querySelector(COMMENT_TIME_SELECTOR)?.innerText || ""
      );

      const likes = countToInt(
        root.querySelector(COMMENT_LIKE_SELECTOR)?.getAttribute("aria-label") || ""
      );

      const lines = String(root.innerText || root.textContent || "")
        .split(/(?<=\S)\s{2,}|\n/)
        .map((line) => helpers.cleanText(line))
        .filter(Boolean)
        .filter((line) => {
          const low = line.toLowerCase();
          if (!line || line === username) return false;
          if (["like", "reply", "share", "edited", "author"].includes(low)) return false;
          if (/^\d+[smhdw]$/.test(low)) return false;
          if (/^\d+\s*(like|likes|reply|replies)$/i.test(line)) return false;
          return true;
        });

      const text = cleanContentText(
        lines.find((line) => line.length > 2 && line !== username) || ""
      );

      if (!text) {
        return "";
      }

      const metadata = [
        username,
        time,
        likes !== "" ? `${likes} likes` : ""
      ].filter(Boolean).join(" | ");

      return metadata ? `${metadata}\n${text}` : text;
    })).slice(0, 50);
  }

  function countToInt(value) {
    const match = String(value || "").replace(/,/g, "").trim().match(/(\d+(?:\.\d+)?)\s*([KMB]?)/i);
    if (!match) {
      return "";
    }
    const multiplier = { K: 1000, M: 1000000, B: 1000000000 }[match[2].toUpperCase()] || 1;
    const parsed = parseFloat(match[1]);
    return Number.isFinite(parsed) ? Math.round(parsed * multiplier) : "";
  }

  function extractMedia(node) {
    const media = {
      images: [],
      videos: [],
      video_blobs: 0,
      attachment_urls: []
    };

    const images = Array.from(
      node.querySelectorAll("img[data-imgperflogname='feedImage'], img[src*='scontent']")
    );

    for (const image of images) {
      const src = cleanImageUrl(image.currentSrc || image.getAttribute("src") || "");
      if (!src || isExcludedPostImage(image, src)) {
        continue;
      }
      if (!media.images.includes(src)) {
        media.images.push(src);
      }
    }

    for (const video of node.querySelectorAll("video")) {
      const src = helpers.absoluteUrl(video.currentSrc || video.getAttribute("src") || "");
      if (src?.startsWith("blob:")) {
        media.video_blobs += 1;
      } else if (src && !media.videos.includes(src)) {
        media.videos.push(src);
      }

      const poster = cleanImageUrl(video.getAttribute("poster") || "");
      if (poster && !media.images.includes(poster)) {
        media.images.push(poster);
      }
    }

    for (const link of node.querySelectorAll("a[href]")) {
      const clean = cleanFacebookUrl(link.getAttribute("href") || "");
      if (!clean) {
        continue;
      }
      try {
        if (new URL(clean).hostname.includes("facebook.com")) {
          continue;
        }
      } catch (_error) {
        continue;
      }
      if (!media.attachment_urls.includes(clean)) {
        media.attachment_urls.push(clean);
      }
    }

    return media;
  }

  function isExcludedPostImage(image, src) {
    if (isDefaultAvatar(src) || /emoji|static\.xx\.fbcdn\.net|rsrc\.php|safe_image\.php/i.test(src)) {
      return true;
    }
    if (/_s(?:16|24|32|40|48|56|64|80)x(?:16|24|32|40|48|56|64|80)/i.test(src)) {
      return true;
    }
    const alt = String(image.getAttribute("alt") || "").toLowerCase();
    if (/\b(profile picture|emoji|icon|avatar)\b/.test(alt)) {
      return true;
    }
    const role = String(image.getAttribute("role") || "").toLowerCase();
    if (role === "presentation") {
      return true;
    }
    return isSmallImage(image);
  }

  function detectPostType(url, media, rawText, node) {
    const lowUrl = String(url || "").toLowerCase();
    const lowText = String(rawText || "").toLowerCase();
    if (lowUrl.includes("/marketplace/item/")) {
      return "marketplace";
    }
    if (lowUrl.includes("/events/")) {
      return "event";
    }
    if (lowUrl.includes("/reel/")) {
      return "reel";
    }
    if (lowUrl.includes("/watch/") || lowUrl.includes("/videos/") || media.videos.length || media.video_blobs || node.querySelector("video")) {
      return "video";
    }
    if (lowUrl.includes("/photo") || media.images.length) {
      return "photo";
    }
    if (lowText.includes(" was live") || lowText.includes(" live ")) {
      return "live";
    }
    if (media.attachment_urls.length || node.querySelector("[data-ad-rendering-role='title'], [data-ad-rendering-role='description']")) {
      return "link_or_share";
    }
    return "post";
  }

  function cleanFacebookUrl(value) {
    const absolute = helpers.absoluteUrl(value);
    if (!absolute) {
      return "";
    }
    try {
      const url = new URL(absolute);
      if (!url.hostname.includes("facebook.com")) {
        return url.toString();
      }
      const keepParams = new Set(["story_fbid", "id", "fbid"]);
      for (const key of Array.from(url.searchParams.keys())) {
        if (!keepParams.has(key)) {
          url.searchParams.delete(key);
        }
      }
      url.hash = "";
      return url.toString();
    } catch (_error) {
      return absolute;
    }
  }

  function chooseBestPostUrl(originalValue, candidateValue) {
    const originalUrl = cleanFacebookUrl(originalValue || "");
    const candidateUrl = cleanFacebookUrl(candidateValue || "");
    if (!originalUrl) {
      return candidateUrl;
    }
    if (!candidateUrl) {
      return originalUrl;
    }

    const originalId = postIdFromUrl(originalUrl);
    const candidateId = postIdFromUrl(candidateUrl);
    if (originalId && candidateId && originalId === candidateId) {
      return candidateUrl;
    }
    return originalUrl;
  }

  function postIdFromUrl(value) {
    if (!value) {
      return "";
    }
    try {
      const url = new URL(value);
      return url.searchParams.get("story_fbid")
        || url.searchParams.get("fbid")
        || (url.pathname.match(/\/groups\/[^/]+\/posts\/([^/?#]+)/i) || [])[1]
        || (url.pathname.match(/\/(?:posts|videos|reel|photos|permalink|events)\/([^/?#]+)/i) || [])[1]
        || (url.pathname.match(/\/marketplace\/item\/([^/?#]+)/i) || [])[1]
        || "";
    } catch (_error) {
      return "";
    }
  }

  function collectImages(posts, profile) {
    return helpers.unique(posts.flatMap((post) => (post.images?.length ? post.images : [post.image_url]).filter(Boolean).map((imageUrl) => ({
      image_url: imageUrl,
      source_url: post.url,
      title: post.title,
      source: "facebook"
    }))), (image) => image.image_url).slice(0, 30);
  }

  function expandVisibleTruncations(root = document) {
    const labels = new Set(["See more", "Show more"]);
    let clicked = 0;
    for (const element of root.querySelectorAll("div[role='button'], span[role='button'], a[role='link'], span")) {
      const text = helpers.cleanText(element.innerText || element.textContent || "");
      if (!labels.has(text)) {
        continue;
      }
      const rect = element.getBoundingClientRect();
      if (!rect.width || !rect.height) {
        continue;
      }
      try {
        element.click();
        clicked += 1;
      } catch (_error) {
        // Ignore inaccessible UI affordances.
      }
      if (clicked >= 25) {
        break;
      }
    }
    return clicked;
  }

  function assertCanScrape(username) {
    const authState = detectAuthRequired(username);
    if (authState.required) {
      throw createAuthRequiredError(authState);
    }
  }

  function detectAuthRequired(username) {
    const path = window.location.pathname.toLowerCase();
    const bodyText = helpers.cleanText(document.body?.innerText || document.body?.textContent || "");
    const hasLoginRoute = /\/(?:login|recover|checkpoint)\b/i.test(path);
    const hasCredentialForm = !!document.querySelector("input[name='email'], input[name='pass'], form[action*='/login']");
    const hasProfileSignals = hasFacebookProfileSignals(username);
    const hasLoginCopy = /\b(log in|sign up|create new account|forgot password)\b/i.test(bodyText);

    return {
      required: hasLoginRoute || (hasCredentialForm && !hasProfileSignals) || (!hasProfileSignals && hasLoginCopy),
      platform: "facebook",
      login_url: buildFacebookLoginUrl()
    };
  }

  function hasFacebookProfileSignals(username) {
    const mainText = helpers.cleanText(document.querySelector("[role='main']")?.innerText || "");
    if (document.querySelector("[role='main'] h1, [data-ad-rendering-role='profile_name'], [data-ad-rendering-role='story_message'], [data-pagelet*='FeedUnit']")) {
      return true;
    }
    return !!username && mainText.toLowerCase().includes(String(username).toLowerCase());
  }

  function buildFacebookLoginUrl() {
    return `https://www.facebook.com/login/?next=${encodeURIComponent(window.location.href)}`;
  }

  function createAuthRequiredError(authState) {
    const error = new Error("Facebook login required in this browser.");
    error.code = "AUTH_REQUIRED";
    error.error_code = "AUTH_REQUIRED";
    error.platform = authState.platform || "facebook";
    error.login_url = authState.login_url || buildFacebookLoginUrl();
    return error;
  }
})();

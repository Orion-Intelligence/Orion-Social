(function () {
  const helpers = window.OrionScraperHelpers;
  const ARTICLE_SELECTOR = 'article[data-tweet-id], article[data-testid="tweet"], article, div[data-testid="tweet"]';

  window.OrionScrapers = window.OrionScrapers || {};
  const scraper = {
    selectors: ['[data-testid="UserName"]', 'article[data-testid="tweet"]', 'div[data-testid="tweetText"]'],
    async run(job) {
      const username = job.username || usernameFromUrl();
      const command = helpers.command(job);
      const profile = collectProfile(username);
      const collected = ["followers", "following"].includes(command) ? [] : await collectPosts(job, username, command);
      const posts = ["videos", "shorts"].includes(command) ? [] : collected;
      const followers = ["profile", "profile_info", "followers"].includes(command) ? await collectConnections(job, "followers", username) : [];
      const following = ["profile", "profile_info", "following"].includes(command) ? await collectConnections(job, "following", username) : [];
      return { platform: "x", username, url: `https://x.com/${username}`, profile, posts, videos: [], shorts: [], images: collectImages(collected), followers, following };
    }
  };
  window.OrionScrapers.x = scraper;
  window.OrionScrapers.twitter = scraper;

  function usernameFromUrl() { return window.location.pathname.match(/^\/([^/?#]+)/)?.[1] || ""; }
  function collectProfile(username) {
    const handle = username.toLowerCase();
    const followers = countLink(handle, "followers");
    const following = countLink(handle, "following");
    return { username, display_name: firstText(['[data-testid="UserName"] div[dir="auto"] span span', '[data-testid="UserName"] div[dir="auto"] span', 'h1[role="heading"]']) || username, bio: firstText(['[data-testid="UserDescription"]']), location: firstText(['[data-testid="UserLocation"]']), website: helpers.absoluteUrl(document.querySelector('[data-testid="UserUrl"] a')?.getAttribute("href") || ""), avatar_url: profileImage(username, "photo", ['main [data-testid^="UserAvatar-Container"] img', '[data-testid^="UserAvatar-Container"] img', 'img[src*="profile_images"]']), cover_url: profileImage(username, "header_photo", ['main img[src*="profile_banners"]', 'img[src*="profile_banners"]']), followers_count: followers, following_count: following, total_followers: followers, total_following: following };
  }
  async function collectPosts(job, username, command) {
    const requestedImages = helpers.limit(job, "max_images", 25, 100);
    const limit = command === "images" ? Math.max(1, Math.min(100, requestedImages * 3)) : Math.max(1, helpers.limit(job, "max_posts", 20, 100));
    const existingUrls = new Set((Array.isArray(job?.cursor?.existing_post_urls) ? job.cursor.existing_post_urls : []).map(normalizeStatusUrl).filter(Boolean));
    let skipRemaining = existingUrls.size ? 0 : helpers.limit(job, "post_offset", 0, 5000);
    const requestedScrolls = helpers.limit(job, "max_scrolls", 50, 100);
    const maxScrolls = Math.min(100, Math.max(requestedScrolls, Math.ceil((existingUrls.size + skipRemaining + limit) / 2) + 5));
    const posts = [], seen = new Set();
    let empty = 0;
    window.scrollTo({ top: 0, behavior: "instant" });
    await helpers.delay(500);
    for (let scroll = 0; posts.length < limit && scroll <= maxScrolls; scroll += 1) {
      const seenBefore = seen.size;
      for (const article of getTweetArticles()) {
        const post = extractTweet(article, username);
        if (!post?.id || !post.text || seen.has(post.id)) continue;
        seen.add(post.id);
        if (existingUrls.has(normalizeStatusUrl(post.url))) continue;
        if (skipRemaining > 0) { skipRemaining -= 1; continue; }
        posts.push(post);
        if (posts.length >= limit || (command === "images" && imageCount(posts) >= requestedImages)) break;
      }
      empty = seen.size === seenBefore ? empty + 1 : 0;
      if (posts.length >= limit || (command === "images" && imageCount(posts) >= requestedImages) || empty >= 20) break;
      const previous = getTweetArticles().length;
      window.scrollBy({ top: 3000, behavior: "instant" });
      await waitForMoreArticles(previous, 2000);
    }
    const maxComments = helpers.limit(job, "max_comments", 25, 100);
    for (const post of command === "images" ? [] : posts) {
      const comments = maxComments ? await collectCommentsForPost(post, username, maxComments, maxScrolls) : [];
      post.comment_items = comments.map((comment) => comment.text);
      post.comment_details = comments;
      if (!post.comments_count && comments.length) post.comments_count = comments.length;
    }
    return posts;
  }
  function getTweetArticles() { return Array.from(document.querySelectorAll(ARTICLE_SELECTOR)); }
  function extractTweet(article, username) {
    const href = statusHref(article), id = article.getAttribute("data-tweet-id") || statusId(href), text = tweetText(article, username);
    if (!id || !text) return null;
    const media = helpers.unique(Array.from(article.querySelectorAll('img[src*="pbs.twimg.com/media"], img[src*="/media/"]')).map((image) => helpers.absoluteUrl(image.currentSrc || image.getAttribute("src") || "")).filter(Boolean), (value) => value);
    const poster = helpers.absoluteUrl(article.querySelector("video[poster]")?.getAttribute("poster") || article.querySelector('[data-testid="videoPlayer"] img[src], [data-testid="videoComponent"] img[src]')?.getAttribute("src") || "");
    const imageUrls = helpers.unique([...media, poster].filter(Boolean), (value) => value), thumbnail = imageUrls[0] || "";
    return { id, title: text.slice(0, 80), text, url: href.startsWith("http") ? href : `https://x.com${href}`, created_at: article.querySelector("time")?.getAttribute("datetime") || "", likes_count: elementCount(article, ['button[data-testid="like"]']), comments_count: elementCount(article, ['button[data-testid="reply"]']), retweets: elementCount(article, ['button[data-testid="retweet"]']), views_count: elementCount(article, ['a[href*="/analytics"]', 'a[aria-label*="views"]', 'a[aria-label*="Views"]']), media_type: thumbnail ? "image" : "", media_url: thumbnail, image_url: thumbnail, image_urls: imageUrls, thumbnail, comment_items: [], comment_details: [], source: "x" };
  }
  function statusHref(article) {
    const tweetId = article.getAttribute("data-tweet-id"), anchors = Array.from(article.querySelectorAll('a[href*="/status/"]'));
    const exact = tweetId ? anchors.find((a) => (a.getAttribute("href") || "").includes(`/status/${tweetId}`)) : null;
    const timed = anchors.find((a) => a.querySelector("time") && /\/status\/\d+/.test(a.getAttribute("href") || ""));
    return String((exact || timed || anchors.find((a) => /\/status\/\d+/.test(a.getAttribute("href") || "")))?.getAttribute("href") || "").split("?")[0];
  }
  function statusId(href) { return String(href || "").match(/\/status\/(\d+)/)?.[1] || ""; }
  function normalizeStatusUrl(value) { try { const match = new URL(String(value || ""), "https://x.com").pathname.match(/\/status\/(\d+)/); return match ? `https://x.com/status/${match[1]}` : ""; } catch (_error) { return ""; } }
  function tweetText(article, username) {
    const primary = Array.from(article.querySelectorAll('div[data-testid="tweetText"]'));
    const nodes = primary.length ? primary : Array.from(article.querySelectorAll("div[lang]"));
    const text = nodes.map((node) => helpers.cleanText(node.innerText || node.textContent || "")).filter(Boolean).join(" ");
    if (text) return text;
    const lines = String(article.innerText || "").split("\n").map((line) => line.trim()).filter(Boolean);
    let start = lines.findIndex((line) => line.toLowerCase() === `@${username}`.toLowerCase());
    start = start < 0 ? 0 : start + 1;
    return lines.slice(start).join(" ");
  }
  function elementCount(root, selectors) {
    for (const selector of selectors) {
      const element = root.querySelector(selector);
      if (!element) continue;
      const transition = element.querySelector('span[data-testid="app-text-transition-container"] span');
      for (const value of [transition?.textContent, element.getAttribute("aria-label"), element.textContent]) {
        const count = helpers.count(value || "");
        if (count !== "") return count;
      }
    }
    return 0;
  }
  async function collectCommentsForPost(post, profileUsername, limit, searchScrolls) {
    const link = await findPostLink(post.id, searchScrolls);
    if (!link) return [];
    link.scrollIntoView({ block: "center", behavior: "instant" }); link.click();
    await waitForPath(`/status/${post.id}`, 7000); await helpers.delay(900);
    const comments = [], seen = new Set();
    let idle = 0;
    for (let scroll = 0; scroll < 30 && comments.length < limit && idle < 5; scroll += 1) {
      expandReplyButtons();
      const before = comments.length;
      for (const article of getTweetArticles()) {
        const rowId = article.getAttribute("data-tweet-id") || statusId(statusHref(article));
        if (rowId === post.id) continue;
        const text = Array.from(article.querySelectorAll('div[data-testid="tweetText"], div[lang]')).map((node) => helpers.cleanText(node.innerText || node.textContent || "")).filter(Boolean).join(" ");
        if (!text) continue;
        const item = { sender_name: handleFromArticle(article), date: article.querySelector("time")?.getAttribute("datetime") || article.querySelector("time")?.textContent || "", likes: elementCount(article, ['button[data-testid="like"]']), text };
        const key = `${item.sender_name}|${item.date}|${item.text}`;
        if (!seen.has(key)) { seen.add(key); comments.push(item); }
        if (comments.length >= limit) break;
      }
      idle = comments.length === before ? idle + 1 : 0;
      if (comments.length < limit) { window.scrollBy({ top: 3500, behavior: "instant" }); await helpers.delay(750); }
    }
    window.history.back(); await waitForProfilePath(profileUsername, 7000); await helpers.delay(900);
    return comments.slice(0, limit);
  }
  async function findPostLink(id, maxScrolls) {
    window.scrollTo({ top: 0, behavior: "instant" }); await helpers.delay(350);
    for (let i = 0; i <= maxScrolls; i += 1) {
      const links = Array.from(document.querySelectorAll(`a[href*="/status/${id}"]`));
      const link = links.find((node) => node.querySelector("time")) || links[0];
      if (link) return link;
      window.scrollBy({ top: 3000, behavior: "instant" }); await helpers.delay(650);
    }
    return null;
  }
  function expandReplyButtons() { for (const button of document.querySelectorAll('button, div[role="button"]')) { const text = helpers.cleanText(button.innerText || button.textContent || "").toLowerCase(); if ((text.includes("show") || text.includes("more")) && (text.includes("reply") || text.includes("replies"))) button.click(); } }
  function handleFromArticle(article) { for (const link of article.querySelectorAll('a[href^="/"], a[href^="https://x.com/"]')) { const value = helpers.usernameFromHref(link.getAttribute("href") || "", [/^\/([A-Za-z0-9_]{1,15})\/?$/]); if (value && !["i", "home", "search", "explore", "settings"].includes(value.toLowerCase())) return `@${value}`; } return ""; }
  async function waitForMoreArticles(previous, timeout) { const start = Date.now(); while (Date.now() - start < timeout) { if (getTweetArticles().length > previous) return; await helpers.delay(200); } }
  async function waitForPath(fragment, timeout) { const start = Date.now(); while (Date.now() - start < timeout) { if (window.location.pathname.toLowerCase().includes(fragment.toLowerCase())) return true; await helpers.delay(200); } return false; }
  async function waitForProfilePath(username, timeout) { const expected = `/${String(username || "").toLowerCase()}`, start = Date.now(); while (Date.now() - start < timeout) { if (window.location.pathname.replace(/\/+$/, "").toLowerCase() === expected) return true; await helpers.delay(200); } return false; }
  function firstText(selectors) { for (const selector of selectors) { const value = helpers.cleanText(document.querySelector(selector)?.innerText || document.querySelector(selector)?.textContent || ""); if (value) return value; } return ""; }
  function profileImage(username, suffix, selectors) {
    const handle = username.toLowerCase();
    for (const link of document.querySelectorAll("a[href]")) { try { const parts = new URL(link.getAttribute("href") || "", window.location.href).pathname.split("/").filter(Boolean).map((part) => decodeURIComponent(part).toLowerCase()); if (parts[0] === handle && parts[1] === suffix) { const value = imageUrl(link.querySelector("img")); if (value) return value; } } catch (_error) {} }
    for (const selector of selectors) { const value = imageUrl(document.querySelector(selector)); if (value) return value; }
    return "";
  }
  function imageUrl(image) { if (!image) return ""; const srcset = image.getAttribute("srcset") || ""; const candidate = srcset ? srcset.split(",").map((part) => part.trim().split(/\s+/)[0]).filter(Boolean).pop() : ""; return helpers.absoluteUrl(candidate || image.currentSrc || image.getAttribute("src") || ""); }
  function countLink(handle, label) { for (const link of document.querySelectorAll("a[href]")) { const text = helpers.cleanText(link.innerText || link.textContent || ""); if (!text.toLowerCase().includes(label)) continue; try { const parts = new URL(link.getAttribute("href") || "", window.location.href).pathname.split("/").filter(Boolean).map((part) => decodeURIComponent(part).toLowerCase()); if (parts[0] === handle) return helpers.count(text); } catch (_error) {} } return ""; }
  function collectImages(posts) { return helpers.unique(posts.flatMap((post) => (Array.isArray(post.image_urls) && post.image_urls.length ? post.image_urls : [post.image_url]).filter(Boolean).map((imageUrl) => ({ image_url: imageUrl, source_url: post.url, title: post.title || "X media", source: "x" }))), (image) => image.image_url); }
  function imageCount(posts) { return helpers.unique(posts.flatMap((post) => post.image_urls || []), (value) => value).length; }
  async function collectConnections(job, type, username) {
    const limit = helpers.limit(job, type === "followers" ? "max_followers" : "max_following", 100, 5000), link = document.querySelector(`a[href$="/${type}"], a[href$="/verified_${type}"]`);
    if (!link || !limit) return [];
    link.click();
    await helpers.waitForAny(['[data-testid="UserCell"]'], 8000);
    const users = await helpers.collectWhileScrolling(() => Array.from(document.querySelectorAll('[data-testid="UserCell"] a[href]')).map((node) => helpers.usernameFromHref(node.getAttribute("href") || "", [/^\/([^/?#]+)/])).filter((value) => value && value.toLowerCase() !== username.toLowerCase()), limit, { maxScrolls: helpers.limit(job, "max_scrolls", 60, 100), keyFn: (value) => value });
    if (window.location.pathname.replace(/\/+$/, "").toLowerCase() !== `/${username}`.toLowerCase()) { window.history.back(); await waitForProfilePath(username, 7000); await helpers.delay(700); }
    return users;
  }
})();

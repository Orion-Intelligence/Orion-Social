(function () {
  const helpers = window.OrionScraperHelpers;

  window.OrionScrapers = window.OrionScrapers || {};
  window.OrionScrapers.github = {
    selectors: [".vcard-fullname", ".avatar-user", "[itemprop='owns']", "main"],
    async run(job) {
      const username = job.username || usernameFromUrl();
      const command = helpers.command(job);
      const profile = collectProfile(username);
      const posts = ["followers", "following"].includes(command) ? [] : await collectRepositories(job, username);
      const followers = ["profile", "profile_info", "followers"].includes(command)
        ? await collectConnections(username, "followers", helpers.limit(job, "max_followers", 100, 5000)) : [];
      const following = ["profile", "profile_info", "following"].includes(command)
        ? await collectConnections(username, "following", helpers.limit(job, "max_following", 100, 5000)) : [];
      return { platform: "github", username, url: window.location.href, profile, posts, images: [], followers, following };
    }
  };

  function usernameFromUrl() { return helpers.usernameFromHref(window.location.href, [/^\/([^/?#]+)/]); }

  function collectProfile(username) {
    const statsText = helpers.cleanText(document.querySelector(".vcard-details, main")?.textContent || "");
    const followersText = helpers.text("a[href$='?tab=followers'] .text-bold, a[href*='tab=followers'] span");
    const followingText = helpers.text("a[href$='?tab=following'] .text-bold, a[href*='tab=following'] span");
    return {
      username, display_name: helpers.text(".vcard-fullname") || username, bio: helpers.text(".user-profile-bio"),
      avatar_url: helpers.absoluteUrl(document.querySelector(".avatar-user")?.getAttribute("src") || ""),
      company: helpers.text(".p-org"), location: helpers.text(".p-label"),
      website: helpers.absoluteUrl(document.querySelector("[data-test-selector='profile-website-url'], .vcard-detail a[rel='nofollow me']")?.getAttribute("href") || ""),
      followers_count: helpers.count(followersText || statsText.match(/[\d,.KMB]+\s+followers/i)?.[0]),
      following_count: helpers.count(followingText || statsText.match(/[\d,.KMB]+\s+following/i)?.[0]),
      total_followers: helpers.count(followersText || statsText.match(/[\d,.KMB]+\s+followers/i)?.[0]),
      total_following: helpers.count(followingText || statsText.match(/[\d,.KMB]+\s+following/i)?.[0])
    };
  }

  async function collectRepositories(job, username) {
    const limit = helpers.limit(job, "max_posts", 25, 100);
    let root = document;
    if (!document.querySelector("[itemprop='owns'], [data-testid='user-repositories-list']")) root = await fetchDocument(`https://github.com/${encodeURIComponent(username)}?tab=repositories`) || document;
    const nodes = Array.from(root.querySelectorAll("[itemprop='owns'] [itemprop='name codeRepository'], [data-testid='user-repositories-list'] li, .pinned-item-list-item"));
    return helpers.unique(nodes.map((node) => {
      const link = node.matches("a") ? node : node.querySelector("a[itemprop='name codeRepository'], a[href]");
      return { id: helpers.cleanText(link?.getAttribute("href") || "").split("/").filter(Boolean).pop() || "", title: helpers.cleanText(link?.textContent || ""), text: helpers.cleanText(node.querySelector("[itemprop='description'], p")?.textContent || ""), url: helpers.absoluteUrl(link?.getAttribute("href") || ""), created_at: node.querySelector("relative-time")?.getAttribute("datetime") || "", source: "github" };
    }).filter((item) => item.url && item.title), (item) => item.url).slice(0, limit);
  }

  async function collectConnections(username, type, limit) {
    if (!limit) return [];
    const users = [];
    let page = 1;
    while (users.length < limit && page <= 20) {
      const root = await fetchDocument(`https://github.com/${encodeURIComponent(username)}?page=${page}&tab=${type}`);
      if (!root) break;
      const batch = Array.from(root.querySelectorAll("[data-testid='followers-list'] a[data-hovercard-type='user'], .d-table a[data-hovercard-type='user'], a[href][data-hovercard-type='user']")).map((link) => helpers.usernameFromHref(link.getAttribute("href") || "", [/^\/([^/?#]+)/])).filter((value) => value && value.toLowerCase() !== username.toLowerCase());
      const before = users.length;
      for (const value of batch) if (!users.some((item) => item.toLowerCase() === value.toLowerCase())) users.push(value);
      if (!batch.length || users.length === before || !root.querySelector("a.next_page")) break;
      page += 1;
    }
    return users.slice(0, limit);
  }

  async function fetchDocument(url) {
    try {
      const response = await fetch(url, { credentials: "include", headers: { Accept: "text/html" } });
      if (!response.ok) return null;
      return new DOMParser().parseFromString(await response.text(), "text/html");
    } catch (_error) { return null; }
  }
})();

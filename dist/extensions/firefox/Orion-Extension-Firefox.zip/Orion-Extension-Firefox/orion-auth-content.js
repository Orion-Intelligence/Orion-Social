// Website-to-extension auth sync is intentionally disabled.
// Users must authenticate the Orion extension from the extension popup.

# Orion Social Scraper Extension

Phase 2 browser extension scaffold for Orion social scraping.

## What It Does

- connects to the Orion Social backend over WebSocket
- announces supported platform capabilities
- stores the backend-assigned extension ID after registration
- receives scraping jobs
- opens a browser tab for the target URL
- injects shared helpers, a platform scraper, and the content runner
- sends progress and JSON results back to the backend

The popup shows `registering` while the WebSocket is open but backend registration has not completed. It shows `online` only after the backend returns `extension_registered`.

## Install for Development

1. Open Firefox.
2. Go to `about:debugging#/runtime/this-firefox`.
3. Click `Load Temporary Add-on`.
4. Select `manifest.json` from this folder.
5. Open the extension popup and configure the backend URL if needed.

Temporary add-ons are only for development. They are removed when Firefox restarts.

## Self-Distributed Firefox Release

Firefox release/beta does not permanently install unsigned local extension ZIPs. For user installs, sign the Firefox extension as an unlisted add-on and serve the signed `.xpi`.

Prerequisites:

1. Create an addons.mozilla.org developer account.
2. Create API credentials in the AMO developer tools.
3. Keep the existing `browser_specific_settings.gecko.id` stable:

```json
"id": "orion-social-scraper@orion.local"
```

Sign the extension:

```bash
cd Orion-Social
AMO_JWT_ISSUER="your-amo-api-key" \
AMO_JWT_SECRET="your-amo-api-secret" \
npm run extension:firefox:sign
```

The script also accepts Mozilla `web-ext` names: `WEB_EXT_API_KEY` and `WEB_EXT_API_SECRET`.

The signed install file is written to:

```text
dist/extensions/firefox/orion-social-scraper-firefox.xpi
```

The backend serves that signed XPI from:

```text
GET http://127.0.0.1:8020/extensions/download/firefox
```

If the XPI is stored somewhere else in production, set:

```text
ORION_FIREFOX_EXTENSION_XPI=/absolute/path/to/orion-social-scraper-firefox.xpi
```

Keep the manifest `version` unique for every signed upload to AMO.

Default backend URL:

```text
ws://127.0.0.1:8020/extensions/ws
```

Backend connection status:

```text
GET http://127.0.0.1:8020/extensions/status
```

The status response includes connected extensions, capabilities, active job ID, and `status: online`.

## Job Message

The background worker accepts messages shaped like:

```json
{
  "type": "job",
  "job": {
    "job_id": "reddit-profile-test",
    "command": "profile",
    "platform": "reddit",
    "username": "example",
    "url": "https://www.reddit.com/user/example/",
    "social_data_type": "profile_info",
    "limits": {
      "max_posts": 25
    }
  }
}
```

## Result Message

Results are returned as:

```json
{
  "type": "job_result",
  "job_id": "reddit-profile-test",
  "status": "done",
  "success": true,
  "data": {},
  "error": null
}
```

## Scraper Status

`reddit.js`, `github.js`, `linkedin.js`, `x.js`, `instagram.js`, and `facebook.js` return normalized profile, post, and image payloads from the live DOM where the page exposes those fields to the browser session.
